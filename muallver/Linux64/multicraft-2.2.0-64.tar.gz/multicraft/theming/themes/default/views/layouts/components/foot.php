
</div>
<script src="<?php echo Theme::js('bootstrap.min.js') ?>"></script>
<script src="<?php echo Theme::js('multicraft.js') ?>"></script>
</body>
<!--  C o p y r i g h t   (c)   2 0 1 0 - 2 0 1 6   b y   x h o s t . c h   G m b H .   A l l   r i g h t s   r e s e r v e d .  -->
</html>
