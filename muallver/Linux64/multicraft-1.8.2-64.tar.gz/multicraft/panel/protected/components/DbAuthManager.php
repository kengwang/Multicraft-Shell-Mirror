<?php
/**
 *
 *   Copyright © 2010-2012 by xhost.ch GmbH
 *
 *   All rights reserved.
 *
 **/


class DbAuthManager extends CDbAuthManager
{

    
}
