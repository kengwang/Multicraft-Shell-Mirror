<?php
/**
 *
 *   Copyright © 2010-2016 by xhost.ch GmbH
 *
 *   All rights reserved.
 *
 **/


class DbAuthManager extends CDbAuthManager
{

    
}
