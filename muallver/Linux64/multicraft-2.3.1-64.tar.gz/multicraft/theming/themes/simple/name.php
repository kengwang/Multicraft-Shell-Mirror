<?php

return 'Simple Theme';
