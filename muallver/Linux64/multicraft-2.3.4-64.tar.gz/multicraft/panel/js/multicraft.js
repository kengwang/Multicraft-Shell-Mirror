multicraft = {}; // Globally scoped object for talking to other inline Yii Js

$(document).ready(function() {
	$('[data-focus]').focus();
});
