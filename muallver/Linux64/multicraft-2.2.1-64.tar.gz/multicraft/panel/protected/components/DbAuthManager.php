<?php
/**
 *
 *   Copyright © 2010-2017 by xhost.ch GmbH
 *
 *   All rights reserved.
 *
 **/


class DbAuthManager extends CDbAuthManager
{

    
}
