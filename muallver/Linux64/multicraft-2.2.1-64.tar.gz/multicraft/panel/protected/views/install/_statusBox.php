<?php
/**
 *
 *   Copyright © 2010-2017 by xhost.ch GmbH
 *
 *   All rights reserved.
 *
 **/
?>
<?php include dirname(__FILE__).'/../daemon/_statusBox.php';
