<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/mc/newdir1.template.php begin -->
<?php	echo __("The new directories will be created in <b>%1\$s</b>.", $net2ftp_globals["printdirectory"]); ?><br /><br />
<?php echo __("New directory name:"); ?> <input type="text" class="input form-control" name="newNames[1]" /><br /><br />
<!-- Template /skins/mc/newdir1.template.php end -->
