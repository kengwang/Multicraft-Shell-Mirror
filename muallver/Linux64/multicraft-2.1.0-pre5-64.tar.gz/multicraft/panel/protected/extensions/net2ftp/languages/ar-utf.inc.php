<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2013 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | For credits, see the credits.txt file                                         |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a été copié vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |      if ($net2ftp_globals["state2"] == "rename") {           // <-- PHP code  |
//  |          $net2ftp_messages["Rename file"] = "Rename file";   // <-- message   |
//  |      }                                                       // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------


// -------------------------------------------------------------------------
// Language settings
// -------------------------------------------------------------------------

// HTML lang attribute
$net2ftp_messages["en"] = "ar";

// HTML dir attribute: left-to-right (LTR) or right-to-left (RTL)
$net2ftp_messages["ltr"] = "rtl";

// CSS style: align left or right (use in combination with LTR or RTL)
$net2ftp_messages["left"] = "right";
$net2ftp_messages["right"] = "left";

// Encoding
$net2ftp_messages["iso-8859-1"] = "UTF-8";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------

// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox

$net2ftp_messages["Connecting to the FTP server"] = "Ø§ÙØ§ØªØµØ§Ù Ø¨Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Logging into the FTP server"] = "Ø§ÙØ¯Ø®ÙÙ Ø¥ÙÙ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Setting the passive mode"] = "Ø¥Ø¹Ø¯Ø§Ø¯Ø§Øª Ø§ÙÙØ¶Ø¹ Ø§ÙØ®Ø§ÙÙ";
$net2ftp_messages["Getting the FTP system type"] = "Ø§ÙØ¯Ø®ÙÙ ÙÙ ÙÙØ· ÙØ¸Ø§Ù FTP";
$net2ftp_messages["Changing the directory"] = "ØªØºÙÙØ± Ø§ÙØ¯ÙÙÙ";
$net2ftp_messages["Getting the current directory"] = "Ø§ÙØ­ØµÙÙ Ø¹ÙÙ Ø§ÙØ¯ÙÙÙ Ø§ÙØ­Ø§ÙÙ";
$net2ftp_messages["Getting the list of directories and files"] = "Ø§ÙØ­ØµÙÙ Ø¹ÙÙ ÙØ§Ø¦ÙØ© Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Parsing the list of directories and files"] = "ØªØ­ÙÙÙ ÙØ§Ø¦ÙØ© Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Logging out of the FTP server"] = "ØªØ³Ø¬ÙÙ Ø§ÙØ®Ø±ÙØ¬ ÙÙ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Getting the list of directories and files"] = "Ø§ÙØ­ØµÙÙ Ø¹ÙÙ ÙØ§Ø¦ÙØ© Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Printing the list of directories and files"] = "Ø·Ø¨Ø§Ø¹Ø© ÙØ§Ø¦ÙØ© Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Processing the entries"] = "ÙØ¹Ø§ÙØ¬Ø© Ø§ÙØ¹ÙØ§ØµØ±";
$net2ftp_messages["Processing entry %1\$s"] = "ÙØ¹Ø§ÙØ¬Ø© Ø§ÙØ¹ÙØµØ± %1\$s";
$net2ftp_messages["Checking files"] = "ØªÙØ­Øµ Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Transferring files to the FTP server"] = "ØªØ±Ø­ÙÙ Ø§ÙÙÙÙØ§Øª Ø¥ÙÙ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Decompressing archives and transferring files"] = "ÙÙ Ø¶ØºØ· Ø§ÙØ£Ø±Ø´ÙÙ Ù ØªØ±Ø­ÙÙ Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Searching the files..."] = "Ø¬Ø§Ø±Ù Ø§ÙØ¨Ø­Ø« Ø¹Ù Ø§ÙÙÙÙØ§Øª ...";
$net2ftp_messages["Uploading new file"] = "Ø¬Ø§Ø±Ù Ø±ÙØ¹ Ø§ÙÙÙÙ Ø§ÙØ¬Ø¯ÙØ¯";
$net2ftp_messages["Reading the file"] = "ÙØ±Ø§Ø¡Ø© Ø§ÙÙÙÙ";
$net2ftp_messages["Parsing the file"] = "ØªØ­ÙÙÙ Ø§ÙÙÙÙ";
$net2ftp_messages["Reading the new file"] = "ÙØ±Ø§Ø¡Ø© Ø§ÙÙÙÙ Ø§ÙØ¬Ø¯ÙØ¯";
$net2ftp_messages["Reading the old file"] = "ÙØ±Ø§Ø¡Ø© Ø§ÙÙÙÙ Ø§ÙÙØ¯ÙÙ";
$net2ftp_messages["Comparing the 2 files"] = "ÙÙØ§Ø±ÙØ© Ø§ÙÙÙÙÙÙ";
$net2ftp_messages["Printing the comparison"] = "Ø·Ø¨Ø§Ø¹Ø© Ø§ÙÙÙØ§Ø±ÙØ©";
$net2ftp_messages["Sending FTP command %1\$s of %2\$s"] = "Ø¥Ø±Ø³Ø§Ù Ø£ÙØ± FTP %1\$s ÙÙ %2\$s";
$net2ftp_messages["Getting archive %1\$s of %2\$s from the FTP server"] = "Ø¬ÙØ¨ Ø£Ø±Ø´ÙÙ %1\$s ÙÙ %2\$s ÙÙ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Creating a temporary directory on the FTP server"] = "Ø¥ÙØ´Ø§Ø¡ Ø¯ÙÙÙ ÙØ¤ÙØª Ø¹ÙÙ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Setting the permissions of the temporary directory"] = "Ø¥Ø¹Ø¯Ø§Ø¯ ØªØµØ§Ø±ÙØ­ Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ¤ÙØª";
$net2ftp_messages["Copying the net2ftp installer script to the FTP server"] = "ÙØ³Ø® ÙØ¹Ø§ÙØ¬ net2ftp Ø¥ÙÙ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Script finished in %1\$s seconds"] = "Ø§ÙÙÙØª Ø§ÙÙØ³ØªØºØ±Ù %1\$s Ø«Ø§ÙÙØ©";
$net2ftp_messages["Script halted"] = "ØªØ¹Ø«Ø± Ø§ÙÙØ¹Ø§ÙØ¬";

// Used on various screens
$net2ftp_messages["Please wait..."] = "ÙØ±Ø¬Ù Ø§ÙØ§ÙØªØ¸Ø§Ø± ...";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unexpected state string: %1\$s. Exiting."] = "Ø­Ø§ÙØ© ØºÙØ± ÙÙØ¨ÙÙØ© Â» %1\$s . ÙÙØ¬ÙØ¯ .";
$net2ftp_messages["This beta function is not activated on this server."] = "ÙØ¸ÙÙØ© Ø§ÙØ§Ø®ØªØ¨Ø§Ø± ØºÙØ± ÙØ´Ø·Ø© Ø¹ÙÙ ÙØ°Ø§ Ø§ÙØ³Ø±ÙØ± .";
$net2ftp_messages["This function has been disabled by the Administrator of this website."] = "ÙØ°Ù Ø§ÙÙØ¸ÙÙØ© ØªÙ ØªØ¹Ø·ÙÙÙØ§ ÙÙ ÙØ¨Ù Ø¥Ø¯Ø§Ø±Ø© ÙØ°Ø§ Ø§ÙÙÙÙØ¹ .";


// -------------------------------------------------------------------------
// /includes/browse.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the directory <b>%2\$s</b> is shown instead."] = "Ø§ÙØ¯ÙÙÙ <b>%1\$s</b> ØºÙØ± ÙÙØ¬ÙØ¯ Ø£Ù ÙØ§ ÙÙÙÙ ØªØ­Ø¯ÙØ¯Ù , ÙØ°Ø§ ÙØ§ ÙÙÙÙ Ø¹Ø±Ø¶ Ø§ÙØ¯ÙÙÙ <b>%2\$s</b> Ø¨Ø¯ÙØ§Ù ÙÙÙ .";
$net2ftp_messages["Your root directory <b>%1\$s</b> does not exist or could not be selected."] = "Ø§ÙØ¯ÙÙÙ Ø§ÙØ¬Ø±Ø² root <b>%1\$s</b> ØºÙØ± ÙÙØ¬ÙØ¯ Ø£Ù ÙØ§ ÙÙÙÙ ØªØ­Ø¯ÙØ¯Ù .";
$net2ftp_messages["The directory <b>%1\$s</b> could not be selected - you may not have sufficient rights to view this directory, or it may not exist."] = "Ø§ÙØ¯ÙÙÙ <b>%1\$s</b> ÙØ§ ÙÙÙÙ ØªØ­Ø¯ÙØ¯Ù - Ø±Ø¨ÙØ§ ÙØ§ØªÙØªÙÙ ØªØ®ÙÙÙ ÙØ§Ù ÙØ¹Ø±Ø¶ ÙØ°Ø§ Ø§ÙØ¯ÙÙÙ , Ø£Ù Ø±Ø¨ÙØ§ ÙÙÙÙ ØºÙØ± ÙÙØ¬ÙØ¯ .";
$net2ftp_messages["Entries which contain banned keywords can't be managed using net2ftp. This is to avoid Paypal or Ebay scams from being uploaded through net2ftp."] = "Ø§ÙØ¥Ø¯Ø®Ø§ÙØ§Øª Ø§ÙØªÙ ØªØ­ØªÙÙ Ø¹ÙÙ ÙÙÙØ§Øª ÙÙØªØ§Ø­ÙØ© ÙØ­Ø¸ÙØ±Ø© ÙØ§ ÙÙÙÙ Ø¥Ø¯Ø§Ø±ØªÙØ§ Ø¨ÙØ§Ø³Ø·Ø© net2ftp .  Ø°ÙÙ ÙØ­ÙØ§ÙØ© Paypal Ø£Ù Ebay ÙÙ Ø§ÙØºØ´ Ù Ø§ÙØªÙØ§Ø¹Ø¨ .";
$net2ftp_messages["Files which are too big can't be downloaded, uploaded, copied, moved, searched, zipped, unzipped, viewed or edited; they can only be renamed, chmodded or deleted."] = "Ø§ÙÙÙÙØ§Øª Ø§ÙÙØ¨ÙØ±Ø© Ø¬Ø¯Ø§Ù ÙØ§ ÙÙÙÙ ØªØ­ÙÙÙÙØ§ Ø Ø±ÙØ¹ÙØ§ Ø ÙØ³Ø®ÙØ§ Ø ÙÙÙÙØ§ Ø Ø§ÙØ¨Ø­Ø« ÙÙÙØ§ Ø Ø¶ØºØ·ÙØ§ Ø ÙÙ Ø¶ØºØ·ÙØ§ Ø Ø¹Ø±Ø¶ÙØ§ Ø£Ù ØªØ­Ø±ÙØ±ÙØ§ Ø  ÙÙØ· ÙÙÙÙ ØªØºÙÙØ± Ø§ÙØ§Ø³Ù Ø Ø§ÙØªØµØ§Ø±ÙØ­ Ø£Ù Ø§ÙØ­Ø°Ù .";
$net2ftp_messages["Execute %1\$s in a new window"] = "ØªÙÙÙØ° %1\$s ÙÙ ÙØ§ÙØ°Ø© Ø¬Ø¯ÙØ¯Ø©";


// -------------------------------------------------------------------------
// /includes/main.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Please select at least one directory or file!"] = "ÙØ±Ø¬Ù ØªØ­Ø¯ÙØ¯ ÙØ¬ÙØ¯ Ø£Ù ÙÙÙ ÙØ§Ø­Ø¯ Ø¹ÙÙ Ø§ÙØ£ÙÙ !";


// -------------------------------------------------------------------------
// /includes/authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$net2ftp_messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "Ø³Ø±ÙØ± FTP <b>%1\$s</b> ØºÙØ± ÙÙØ¬ÙØ¯ ÙÙ ÙØ§Ø¦ÙØ© Ø³Ø±ÙØ±Ø§Øª FTP Ø§ÙÙØ³ÙÙØ­ Ø¨ÙØ§ .";
$net2ftp_messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "Ø§ÙØ³Ø±ÙØ± FTP <b>%1\$s</b> ÙÙØ¬ÙØ¯ ÙÙ ÙØ§Ø¦ÙØ© Ø³Ø±ÙØ±Ø§Øª FTP Ø§ÙÙØ­Ø¸ÙØ±Ø© .";
$net2ftp_messages["The FTP server port %1\$s may not be used."] = "ÙÙÙØ° Ø³Ø±ÙØ± FTP %1\$s ÙØ§ ÙÙÙÙ Ø§Ø³ØªØ®Ø¯Ø§ÙÙ .";
$net2ftp_messages["Your IP address (%1\$s) is not in the list of allowed IP addresses."] = "Ø¹ÙÙØ§Ù IP  Ø§ÙØ®Ø§Øµ Ø¨Ù (%1\$s) ØºÙØ± ÙÙØ¬ÙØ¯ ÙÙ ÙØ§Ø¦ÙØ© Ø¹ÙØ§ÙÙÙ IP Ø§ÙÙØ³ÙÙØ­ Ø¨ÙØ§ .";
$net2ftp_messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Ø¹ÙÙØ§Ù IP Ø§ÙØ®Ø§Øµ Ø¨Ù (%1\$s) ÙÙØ¬ÙØ¯ ÙÙ ÙØ§Ø¦ÙØ© Ø¹ÙØ§ÙÙÙ IP Ø§ÙÙØ­Ø¸ÙØ±Ø© .";

// isAuthorizedDirectory()
$net2ftp_messages["Table net2ftp_users contains duplicate rows."] = "Ø§ÙØ¬Ø¯ÙÙ net2ftp_users ÙØ­ØªÙÙ Ø¹ÙÙ ØµÙÙÙ ÙÙØ±Ø±Ø© .";

// checkAdminUsernamePassword()
$net2ftp_messages["You did not enter your Administrator username or password."] = "ÙÙ ØªÙÙ Ø¨Ø¥Ø¯Ø®Ø§Ù Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù ÙÙØ¥Ø¯Ø§Ø±Ø© Ø£Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± !";
$net2ftp_messages["Wrong username or password. Please try again."] = "Ø®Ø·Ø£ ÙÙ Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù Ø£Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± . ÙØ±Ø¬Ù Ø§ÙÙØ­Ø§ÙÙØ© ÙÙ Ø¬Ø¯ÙØ¯ !";

// -------------------------------------------------------------------------
// /includes/consumption.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unable to determine your IP address."] = "ØªØ¹Ø°Ø± ØªØ­Ø¯ÙØ¯ Ø¹ÙÙØ§Ù IP Ø§ÙØ®Ø§Øµ Ø¨Ù .";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress contains duplicate rows."] = "Ø§ÙØ¬Ø¯ÙÙ net2ftp_log_consumption_ipaddress ÙØ­ØªÙÙ Ø¹ÙÙ ØµÙÙÙ ÙÙØ±Ø±Ø© .";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver contains duplicate rows."] = "Ø§ÙØ¬Ø¯ÙÙ net2ftp_log_consumption_ftpserver ÙØ­ØªÙÙ Ø¹ÙÙ ØµÙÙÙ ÙÙØ±Ø±Ø© .";
$net2ftp_messages["The variable <b>consumption_ipaddress_datatransfer</b> is not numeric."] = "Ø§ÙÙØªØºÙØ± <b>consumption_ipaddress_datatransfer</b> ÙÙØ³ Ø¹Ø¯Ø¯Ù .";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress could not be updated."] = "ÙØ§ ÙÙÙÙ ØªØ­Ø¯ÙØ« Ø§ÙØ¬Ø¯ÙÙ net2ftp_log_consumption_ipaddress .";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress contains duplicate entries."] = "Ø§ÙØ¬Ø¯ÙÙ net2ftp_log_consumption_ipaddress ÙØ­ØªÙÙ Ø¹ÙÙ Ø¹ÙØ§ØµØ± ÙÙØ±Ø±Ø© .";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver could not be updated."] = "ÙØ§ ÙÙÙÙ ØªØ­Ø¯ÙØ« Ø§ÙØ¬Ø¯ÙÙ net2ftp_log_consumption_ftpserver .";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver contains duplicate entries."] = "Ø§ÙØ¬Ø¯ÙÙ net2ftp_log_consumption_ftpserver ÙØ­ØªÙÙ Ø¹ÙÙ Ø¹ÙØ§ØµØ± ÙÙØ±Ø±Ø© .";
$net2ftp_messages["Table net2ftp_log_access could not be updated."] = "ÙØ§ ÙÙÙÙ ØªØ­Ø¯ÙØ« Ø§ÙØ¬Ø¯ÙÙ net2ftp_log_access .";
$net2ftp_messages["Table net2ftp_log_access contains duplicate entries."] = "ÙØªØ¶ÙÙ Ø§ÙØ¬Ø¯ÙÙ net2ftp_log_access ÙØ¯Ø®ÙØ§Øª ÙØªÙØ±Ø±Ø© .";


// -------------------------------------------------------------------------
// /includes/database.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unable to connect to the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php."] = "ØªØ¹Ø°Ø± Ø§ÙØ§ØªØµØ§Ù Ø¨ÙØ§Ø¹Ø¯Ø© Ø§ÙØ¨ÙØ§ÙØ§Øª MySQL . ÙØ±Ø¬Ù Ø§ÙØªØ£ÙØ¯ ÙÙ ØµØ­Ø© ÙØ¹ÙÙÙØ§ØªÙ Ø§ÙÙØ¯Ø®ÙØ© ÙÙ Ø§ÙÙÙÙ settings.inc.php.";
$net2ftp_messages["Unable to select the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php."] = "ØªØ¹Ø°Ø± ØªØ­Ø¯ÙØ¯ ÙØ§Ø¹Ø¯Ø© Ø§ÙØ¨ÙØ§ÙØ§Øª MySQL . ÙØ±Ø¬Ù Ø§ÙØªØ£ÙØ¯ ÙÙ ØµØ­Ø© ÙØ¹ÙÙÙØ§ØªÙ Ø§ÙÙØ¯Ø®ÙØ© ÙÙ Ø§ÙÙÙÙ settings.inc.php.";


// -------------------------------------------------------------------------
// /includes/errorhandling.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["An error has occured"] = "Ø­Ø¯Ø« Ø®Ø·Ø£";
$net2ftp_messages["Go back"] = "Ø§ÙØ¹ÙØ¯Ø© ÙÙØ®ÙÙ";
$net2ftp_messages["Go to the login page"] = "Ø§ÙØ°ÙØ§Ø¨ Ø¥ÙÙ ØµÙØ­Ø© Ø§ÙØ¯Ø®ÙÙ";


// -------------------------------------------------------------------------
// /includes/filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">php.net</a><br />"] = "The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">php.net</a><br />";
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/function.ftp-ssl-connect.php\" target=\"_blank\">FTP and/or OpenSSL modules of PHP</a> is not installed.<br /><br /> The administrator of this website should install these modules. Installation instructions are given on php.net: <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">here for FTP</a>, and <a href=\"http://www.php.net/manual/en/openssl.installation.php\" target=\"_blank\">here for OpenSSL</a><br />"] = "The <a href=\"http://www.php.net/manual/en/function.ftp-ssl-connect.php\" target=\"_blank\">FTP and/or OpenSSL modules of PHP</a> is not installed.<br /><br /> The administrator of this website should install these modules. Installation instructions are given on php.net: <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">here for FTP</a>, and <a href=\"http://www.php.net/manual/en/openssl.installation.php\" target=\"_blank\">here for OpenSSL</a><br />";
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/function.ssh2-sftp.php\" target=\"_blank\">SSH2 module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ssh2.installation.php\" target=\"_blank\">php.net</a><br />"] = "The <a href=\"http://www.php.net/manual/en/function.ssh2-sftp.php\" target=\"_blank\">SSH2 module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ssh2.installation.php\" target=\"_blank\">php.net</a><br />";
$net2ftp_messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "ØªØ¹Ø°Ø± Ø§ÙØ§ØªØµØ§Ù Ø¨Ø³Ø±ÙØ± FTP <b>%1\$s</b> Ø¹ÙÙ Ø§ÙÙÙÙØ° <b>%2\$s</b>.<br /><br />ÙÙ Ø£ÙØª ÙØªØ£ÙØ¯ ÙÙ ØµØ­Ø© Ø¹ÙÙØ§Ù Ø³Ø±ÙØ± FTP Ø ÙØ°Ø§ ÙØ­ØµÙ ÙØ£Ø³Ø¨Ø§Ø¨ ÙØ®ØªÙÙØ© ÙÙ Ø³Ø±ÙØ± HTTP (ÙÙØ¨) . ÙØ±Ø¬Ù Ø§ÙØ§ØªØµØ§Ù Ø¨ÙØ®Ø¯Ù ISP Ø£Ù ÙØ¯ÙØ± Ø§ÙÙØ¸Ø§Ù ÙÙÙØ³Ø§Ø¹Ø¯Ø© .<br />";
$net2ftp_messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "ØªØ¹Ø°Ø± Ø§ÙØ¯Ø®ÙÙ Ø¥ÙÙ Ø³Ø±ÙØ± FTP <b>%1\$s</b> Ø¨ÙØ§Ø³Ø·Ø© Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù <b>%2\$s</b>.<br /><br />ÙÙ Ø§ÙØª ÙØªØ£ÙØ¯ ÙÙ ØµØ­Ø© Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± Ø ÙØ±Ø¬Ù Ø§ÙØ§ØªØµØ§Ù Ø¨ÙØ®Ø¯Ù ISP Ø£Ù ÙØ¯ÙØ± Ø§ÙÙØ¸Ø§Ù ÙÙÙØ³Ø§Ø¹Ø¯Ø© .<br />";
$net2ftp_messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "ØªØ¹Ø°Ø± Ø§ÙØªØ¨Ø¯ÙÙ Ø¥ÙÙ Ø§ÙÙÙØ· Ø§ÙØ®Ø§ÙÙ passive Ø¹ÙÙ Ø³Ø±ÙØ± FTP <b>%1\$s</b>.";

// ftp_openconnection2()
$net2ftp_messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "ØªØ¹Ø°Ø± Ø§ÙØ§ØªØµØ§Ù Ø¨Ø³Ø±ÙØ± FTP Ø§ÙØ«Ø§ÙÙ (Ø§ÙÙØ¯Ù) <b>%1\$s</b> Ø¹ÙÙ Ø§ÙÙÙÙØ° <b>%2\$s</b>.<br /><br />ÙÙ Ø§ÙØª ÙØªØ£ÙØ¯ ÙÙ ØµØ­Ø© Ø¹ÙÙØ§Ù Ø³Ø±ÙØ± FTP Ø§ÙØ«Ø§ÙÙ (Ø§ÙÙØ¯Ù) Ø ÙØ°Ø§ ÙØ­Ø¯Ø« ÙØ£Ø³Ø¨Ø§Ø¨ ÙØ®ØªÙÙØ© ÙÙ Ø³Ø±ÙØ± HTTP (ÙÙØ¨) . ÙØ±Ø¬Ù Ø§ÙØ§ØªØµØ§Ù Ø¨ÙØ®Ø¯Ù ISP Ø£Ù ÙØ¯ÙØ± Ø§ÙÙØ¸Ø§Ù ÙÙÙØ³Ø§Ø¹Ø¯Ø© .<br />";
$net2ftp_messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "ØªØ¹Ø°Ø± Ø§ÙØ¯Ø®ÙÙ Ø¥ÙÙ Ø³Ø±ÙØ± FTP Ø§ÙØ«Ø§ÙÙ (Ø§ÙÙØ¯Ù) <b>%1\$s</b> Ø¨ÙØ§Ø³Ø·Ø© Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù <b>%2\$s</b>.<br /><br />ÙÙ Ø£ÙØª ÙØªØ£ÙØ¯ ÙÙ ØµØ­Ø© Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± Ø ÙØ±Ø¬Ù Ø§ÙØ§ØªØµØ§Ù Ø¨ÙØ®Ø¯Ù ISP Ø£Ù ÙØ¯ÙØ± Ø§ÙÙØ¸Ø§Ù ÙÙÙØ³Ø§Ø¹Ø¯Ø© .<br />";
$net2ftp_messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "ØªØ¹Ø°Ø± Ø§ÙØªØ¨Ø¯ÙÙ Ø¥ÙÙ Ø§ÙÙÙØ· Ø§ÙØ®Ø§ÙÙ passive Ø¹ÙÙ Ø³Ø±ÙØ± FTP Ø§ÙØ«Ø§ÙÙ (Ø§ÙÙØ¯Ù) <b>%1\$s</b>.";

// ftp_myrename()
$net2ftp_messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "ØªØ¹Ø°Ø± Ø¥Ø¹Ø§Ø¯Ø© ØªØ³ÙÙØ© Ø§ÙÙØ¬ÙØ¯ Ø£Ù Ø§ÙÙÙÙ <b>%1\$s</b> Ø¥ÙÙ <b>%2\$s</b>";

// ftp_mychmod()
$net2ftp_messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "ØªØ¹Ø°Ø± ØªÙÙÙØ° Ø£ÙØ± Ø§ÙÙÙÙØ¹ <b>%1\$s</b>. ÙØ§Ø­Ø¸ Ø§Ù Ø£ÙØ± Ø§ÙØªØµØ±ÙØ­ CHMOD ÙØªØ§Ø­ ÙÙØ· Ø¹ÙÙ Ø³Ø±ÙØ±Ø§Øª Unix FTP , Ù ØºÙØ± ÙØªØ§Ø­ Ø¹ÙÙ Ø³Ø±ÙØ±Ø§Øª Windows FTP ..";
$net2ftp_messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "ØªÙ ØªØºÙÙØ± ØªØµØ±ÙØ­ Ø§ÙÙØ¬ÙØ¯ <b>%1\$s</b> Ø¥ÙÙ <b>%2\$s</b> Ø¨ÙØ¬Ø§Ø­ ! ";
$net2ftp_messages["Processing entries within directory <b>%1\$s</b>:"] = "ÙØ¹Ø§ÙØ¬Ø© Ø§ÙØ¹ÙØ§ØµØ± ÙÙ Ø§ÙÙØ¬ÙØ¯ <b>%1\$s</b> Â»";
$net2ftp_messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "ØªÙ ØªØºÙÙØ± ØªØµØ±ÙØ­ Ø§ÙÙÙÙ <b>%1\$s</b> Ø¥ÙÙ <b>%2\$s</b> Ø¨ÙØ¬Ø§Ø­ !";
$net2ftp_messages["All the selected directories and files have been processed."] = "ØªÙØª ÙØ¹Ø§ÙØ¬Ø© Ø¬ÙÙØ¹ Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª Ø§ÙÙØ­Ø¯Ø¯Ø© .";

// ftp_rmdir2()
$net2ftp_messages["Unable to delete the directory <b>%1\$s</b>"] = "ØªØ¹Ø°Ø± Ø­Ø°Ù Ø§ÙÙØ¬ÙØ¯ <b>%1\$s</b>";

// ftp_delete2()
$net2ftp_messages["Unable to delete the file <b>%1\$s</b>"] = "ØªØ¹Ø°Ø± Ø­Ø°Ù Ø§ÙÙÙÙ <b>%1\$s</b>";

// ftp_newdirectory()
$net2ftp_messages["Unable to create the directory <b>%1\$s</b>"] = "ØªØ¹Ø°Ø± Ø¥ÙØ´Ø§Ø¡ Ø§ÙÙØ¬ÙØ¯ <b>%1\$s</b>";

// ftp_readfile()
$net2ftp_messages["Unable to create the temporary file"] = "ØªØ¹Ø°Ø± Ø¥ÙØ´Ø§Ø¡ ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª";
$net2ftp_messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "ØªØ¹Ø°Ø± Ø¬ÙØ¨ Ø§ÙÙÙÙ <b>%1\$s</b> ÙÙ Ø³Ø±ÙØ± FTP Ù Ø­ÙØ¸Ù ÙÙ ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª <b>%2\$s</b>.<br />ØªÙØ­Øµ ØµÙØ§Ø­ÙØ§Øª Ø§ÙÙØ¬ÙØ¯ %3\$s .<br />";
$net2ftp_messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "ØªØ¹Ø°Ø± ÙØªØ­ ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª . ØªÙØ­Øµ ØµÙØ§Ø­ÙØ§Øª Ø§ÙÙØ¬ÙØ¯ %1\$s .";
$net2ftp_messages["Unable to read the temporary file"] = "ØªØ¹Ø°Ø± ÙØ±Ø§Ø¡Ø© ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª";
$net2ftp_messages["Unable to close the handle of the temporary file"] = "ØªØ¹Ø°Ø± Ø¥ØºÙØ§Ù ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª";
$net2ftp_messages["Unable to delete the temporary file"] = "ØªØ¹Ø°Ø± Ø­Ø°Ù ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª";

// ftp_writefile()
$net2ftp_messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "ØªØ¹Ø°Ø± Ø¥ÙØ´Ø§Ø¡ ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª . ØªÙØ­Øµ ØµÙØ§Ø­ÙØ§Øª Ø§ÙÙØ¬ÙØ¯ %1\$s .";
$net2ftp_messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "ØªØ¹Ø°Ø± ÙØªØ­ ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª . ØªÙØ­Øµ ØµÙØ§Ø­ÙØ§Øª Ø§ÙÙØ¬ÙØ¯ %1\$s .";
$net2ftp_messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "ØªØ¹Ø°Ø± Ø§ÙÙØªØ§Ø¨Ø© Ø¥ÙÙ ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª <b>%1\$s</b>.<br />ØªÙØ­Øµ ØµÙØ§Ø­ÙØ§Øª Ø§ÙÙØ¬ÙØ¯ %2\$s .";
$net2ftp_messages["Unable to close the handle of the temporary file"] = "ØªØ¹Ø°Ø± Ø¥ØºÙØ§Ù ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª";
$net2ftp_messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "ØªØ¹Ø°Ø± ÙØ¶Ø¹ Ø§ÙÙÙÙ <b>%1\$s</b> Ø¹ÙÙ Ø³Ø±ÙØ± FTP .<br />Ø±Ø¨ÙØ§ ÙØ§ ØªÙØªÙÙ ØµÙØ§Ø­ÙØ§Øª Ø§ÙÙØªØ§Ø¨Ø© Ø¥ÙÙ ÙØ°Ø§ Ø§ÙØ¯ÙÙÙ !";
$net2ftp_messages["Unable to delete the temporary file"] = "ØªØ¹Ø°Ø± Ø­Ø°Ù ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª";

// ftp_copymovedelete()
$net2ftp_messages["Processing directory <b>%1\$s</b>"] = "Processing directory <b>%1\$s</b>";
$net2ftp_messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ¯Ù <b>%1\$s</b> ÙÙØ³ Ø§ÙÙØµØ¯Ø± Ø£Ù Ø¯ÙÙÙ ÙØ±Ø¹Ù ÙÙ Ø§ÙØ¯ÙÙÙ Ø§ÙÙØµØ¯Ø± <b>%2\$s</b>, ÙØ°Ø§ Ø³ÙØªÙ ØªØ®Ø·Ù ÙØ°Ø§ Ø§ÙØ¯ÙÙÙ .";
$net2ftp_messages["The directory <b>%1\$s</b> contains a banned keyword, so this directory will be skipped"] = "Ø§ÙØ¯ÙÙÙ <b>%1\$s</b> ÙØ­ØªÙÙ Ø¹ÙÙ ÙÙÙØ§Øª ÙÙØªØ§Ø­ÙØ© ÙØ­Ø¸ÙØ±Ø© Ø ÙØ°Ø§ Ø³ÙØªÙ ØªØ®Ø·Ù ÙØ°Ø§ Ø§ÙØ¯ÙÙÙ";
$net2ftp_messages["The directory <b>%1\$s</b> contains a banned keyword, aborting the move"] = "Ø§ÙØ¯ÙÙÙ <b>%1\$s</b> ÙØ­ØªÙÙ Ø¹ÙÙ ÙÙÙØ§Øª ÙÙØªØ§Ø­ÙØ© ÙØ­Ø¸ÙØ±Ø© Ø ØªÙ Ø¥ÙØºØ§Ø¡ Ø§ÙÙÙÙ";
$net2ftp_messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "ØªØ¹Ø°Ø± Ø¥ÙØ´Ø§Ø¡ Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ±Ø¹Ù <b>%1\$s</b>. Ø±Ø¨ÙØ§ ÙÙÙÙ ÙÙØ¬ÙØ¯ ÙÙ . ÙØªØ§Ø¨Ø¹Ø© Ø¹ÙÙÙØ© Ø§ÙÙØ³Ø®/Ø§ÙÙÙÙ ...";
$net2ftp_messages["Created target subdirectory <b>%1\$s</b>"] = "Ø¥ÙØ´Ø§Ø¡ Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ±Ø¹Ù Ø§ÙÙØ¯Ù <b>%1\$s</b>";
$net2ftp_messages["The directory <b>%1\$s</b> could not be selected, so this directory will be skipped"] = "Ø§ÙØ¯ÙÙÙ <b>%1\$s</b> ÙØ§ ÙÙÙÙ ØªØ­Ø¯ÙØ¯Ù . ÙØ°Ø§ Ø³ÙØªÙ ØªØ®Ø·Ù ÙØ°Ø§ Ø§ÙØ¯ÙÙÙ .";
$net2ftp_messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "ØªØ¹Ø°Ø± Ø­Ø°Ù Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ±Ø¹Ù <b>%1\$s</b> - Ø±Ø¨ÙØ§ ÙÙÙÙ ÙØ§Ø±Øº";
$net2ftp_messages["Deleted subdirectory <b>%1\$s</b>"] = "ØªÙ Ø­Ø°Ù Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ±Ø¹Ù <b>%1\$s</b>";
$net2ftp_messages["Deleted subdirectory <b>%1\$s</b>"] = "ØªÙ Ø­Ø°Ù Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ±Ø¹Ù <b>%1\$s</b>";
$net2ftp_messages["Unable to move the directory <b>%1\$s</b>"] = "Unable to move the directory <b>%1\$s</b>";
$net2ftp_messages["Moved directory <b>%1\$s</b>"] = "Moved directory <b>%1\$s</b>";
$net2ftp_messages["Processing of directory <b>%1\$s</b> completed"] = "ØªÙØª ÙØ¹Ø§ÙØ¬Ø© Ø§ÙØ¯ÙÙÙ <b>%1\$s</b>";
$net2ftp_messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ¯Ù ÙÙÙÙÙ <b>%1\$s</b> ÙØ¨Ø¯Ù Ø£ÙÙ ÙØ§ÙÙØµØ¯Ø± , ÙØ°Ø§ Ø³ÙØªÙ ØªØ®Ø·Ù ÙØ°Ø§ Ø§ÙÙÙÙ";
$net2ftp_messages["The file <b>%1\$s</b> contains a banned keyword, so this file will be skipped"] = "Ø§ÙÙÙÙ <b>%1\$s</b> ÙØ­ØªÙÙ Ø¹ÙÙ ÙÙÙØ§Øª ÙÙØªØ§Ø­ÙØ© ÙØ­Ø¸ÙØ±Ø© Ø ÙØ°Ø§ Ø³ÙØªÙ ØªØ®Ø·Ù ÙØ°Ø§ Ø§ÙÙÙÙ";
$net2ftp_messages["The file <b>%1\$s</b> contains a banned keyword, aborting the move"] = "Ø§ÙÙÙÙ <b>%1\$s</b> ÙØ­ØªÙÙ Ø¹ÙÙ ÙÙÙØ§Øª ÙÙØªØ§Ø­ÙØ© ÙØ­Ø¸ÙØ±Ø© Ø ØªÙ Ø¥ÙØºØ§Ø¡ Ø§ÙÙÙÙ";
$net2ftp_messages["The file <b>%1\$s</b> is too big to be copied, so this file will be skipped"] = "Ø§ÙÙÙÙ <b>%1\$s</b> ÙØ¨ÙØ± Ø¬Ø¯Ø§Ù ÙÙ ÙÙØ³Ø® Ø ÙØ°Ø§ Ø³ÙØªÙ ØªØ¬Ø§ÙØ²Ù";
$net2ftp_messages["The file <b>%1\$s</b> is too big to be moved, aborting the move"] = "Ø§ÙÙÙÙ <b>%1\$s</b> ÙØ¨ÙØ± Ø¬Ø¯Ø§Ù ÙÙ ÙÙÙÙ Ø ØªÙ Ø¥ÙØºØ§Ø¡ Ø§ÙÙÙÙ";
$net2ftp_messages["Unable to copy the file <b>%1\$s</b>"] = "ØªØ¹Ø°Ø± ÙØ³Ø® Ø§ÙÙÙÙ <b>%1\$s</b>";
$net2ftp_messages["Copied file <b>%1\$s</b>"] = "ØªÙ ÙØ³Ø® Ø§ÙÙÙÙ <b>%1\$s</b>";
$net2ftp_messages["Unable to move the file <b>%1\$s</b>, aborting the move"] = "ØªØ¹Ø°Ø± ÙÙÙ Ø§ÙÙÙÙ <b>%1\$s</b>, ØªÙ Ø¥ÙØºØ§Ø¡ Ø§ÙØ¹ÙÙÙØ©";
$net2ftp_messages["Unable to move the file <b>%1\$s</b>"] = "Unable to move the file <b>%1\$s</b>";
$net2ftp_messages["Moved file <b>%1\$s</b>"] = "ØªÙ ÙÙÙ Ø§ÙÙÙÙ <b>%1\$s</b>";
$net2ftp_messages["Unable to delete the file <b>%1\$s</b>"] = "ØªØ¹Ø°Ø± Ø­Ø°Ù Ø§ÙÙÙÙ <b>%1\$s</b>";
$net2ftp_messages["Deleted file <b>%1\$s</b>"] = "ØªÙ Ø­Ø°Ù Ø§ÙÙÙÙ <b>%1\$s</b>";
$net2ftp_messages["All the selected directories and files have been processed."] = "ØªÙØª ÙØ¹Ø§ÙØ¬Ø© Ø¬ÙÙØ¹ Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª Ø§ÙÙØ­Ø¯Ø¯Ø© .";

// ftp_processfiles()

// ftp_getfile()
$net2ftp_messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "ØªØ¹Ø°Ø± ÙØ³Ø® Ø§ÙÙÙÙ Ø§ÙØ¨Ø¹ÙØ¯ <b>%1\$s</b> Ø¥ÙÙ Ø§ÙÙÙÙ Ø§ÙÙØ­ÙÙ Ø¨Ø§Ø³ØªØ®Ø¯Ø§Ù ÙÙØ· FTP <b>%2\$s</b>";
$net2ftp_messages["Unable to delete file <b>%1\$s</b>"] = "ØªØ¹Ø°Ø± Ø­Ø°Ù Ø§ÙÙÙÙ <b>%1\$s</b>";

// ftp_putfile()
$net2ftp_messages["The file is too big to be transferred"] = "ÙØ¨ÙØ± Ø¬Ø¯Ø§Ù ÙÙ ÙØªÙ ØªØ±Ø­ÙÙÙ";
$net2ftp_messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Ø§ÙØ­ØµØ© Ø§ÙÙÙÙÙØ© Ø§ÙÙØ³ÙÙØ­ Ø¨ÙØ§ Ø§Ø³ØªÙÙØ°Øª Â» Ø§ÙÙÙÙ <b>%1\$s</b> ÙÙ ÙØªÙ ØªØ±Ø­ÙÙÙ";
$net2ftp_messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "ØªØ¹Ø°Ø± ÙØ³Ø® Ø§ÙÙÙÙ Ø§ÙÙØ­ÙÙ Ø¥ÙÙ Ø§ÙÙÙÙ Ø§ÙØ¨Ø¹ÙØ¯ <b>%1\$s</b> Ø¨Ø§Ø³ØªØ®Ø¯Ø§Ù ÙÙØ· FTP <b>%2\$s</b>";
$net2ftp_messages["Unable to delete the local file"] = "ØªØ¹Ø°Ø± Ø­Ø°Ù Ø§ÙÙÙÙ Ø§ÙÙØ­ÙÙ";

// ftp_downloadfile()
$net2ftp_messages["Unable to delete the temporary file"] = "ØªØ¹Ø°Ø± Ø­Ø°Ù ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª";
$net2ftp_messages["Unable to send the file to the browser"] = "ØªØ¹Ø°Ø± Ø¥Ø±Ø³Ø§Ù Ø§ÙÙÙÙ Ø¥ÙÙ Ø§ÙÙØ³ØªØ¹Ø±Ø¶";

// ftp_zip()
$net2ftp_messages["Unable to create the temporary file"] = "ØªØ¹Ø°Ø± Ø¥ÙØ´Ø§Ø¡ ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª";
$net2ftp_messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "ØªÙ Ø­ÙØ¸ Ø§ÙÙÙÙ Ø§ÙÙØ¶ØºÙØ· zip Ø¥ÙÙ Ø³Ø±ÙØ± FTP Ø¨Ø§Ø³Ù <b>%1\$s</b>";
$net2ftp_messages["Requested files"] = "Ø§ÙÙÙÙØ§Øª Ø§ÙÙØ·ÙÙØ¨Ø©";

$net2ftp_messages["Dear,"] = "Ø§ÙØ³ÙØ§Ù Ø¹ÙÙÙÙ ,";
$net2ftp_messages["Someone has requested the files in attachment to be sent to this email account (%1\$s)."] = "Ø´Ø®Øµ ÙØ§ Ø·ÙØ¨ Ø¥Ø±Ø³Ø§Ù Ø§ÙÙÙÙØ§Øª Ø§ÙÙØ±ÙÙØ© Ø¥ÙÙ Ø¹ÙÙØ§Ù Ø§ÙØ¨Ø±ÙØ¯ Ø§ÙØ§ÙÙØªØ±ÙÙÙ (%1\$s) .";
$net2ftp_messages["If you know nothing about this or if you don't trust that person, please delete this email without opening the Zip file in attachment."] = "Ø¥Ù ÙÙ ØªÙÙ ØªØ¹Ø±Ù Ø´Ø¦ Ø­ÙÙ ÙØ°Ø§ , Ø£Ù Ø¥Ù ÙÙ ØªÙÙ ÙØ¹ÙÙ Ø¨ÙØ°Ø§ Ø§ÙØ´Ø®Øµ , ÙØ±Ø¬Ù Ø­Ø°Ù Ø§ÙØ±Ø³Ø§ÙØ© Ø¨Ø¯ÙÙ ÙØªØ­ Ø§ÙÙÙÙ Ø§ÙÙØ¶ØºÙØ· Ø§ÙÙØ±ÙÙ .";
$net2ftp_messages["Note that if you don't open the Zip file, the files inside cannot harm your computer."] = "ÙÙØ§Ø­Ø¸Ø© - Ø¥Ù ÙÙ ØªÙÙ Ø¨ÙØªØ­ Ø§ÙÙÙÙ Ø§ÙÙØ¶ØºÙØ· , ÙÙÙ ØªÙØ­Ù Ø§ÙÙÙÙØ§Øª Ø§ÙØªÙ Ø¨Ø¯Ø§Ø®ÙÙ Ø£Ù Ø£Ø°Ù Ø¨Ø¬ÙØ§Ø²Ù Ø¥Ù ÙÙØª ØªØ´Ù Ø¨ÙØ§ .";
$net2ftp_messages["Information about the sender: "] = "ÙØ¹ÙÙÙØ§Øª Ø­ÙÙ Ø§ÙÙØ±Ø³Ù Â» ";
$net2ftp_messages["IP address: "] = "Ø¹ÙÙØ§Ù IP Â» ";
$net2ftp_messages["Time of sending: "] = "ÙÙØª Ø§ÙØ¥Ø±Ø³Ø§Ù Â» ";
$net2ftp_messages["Sent via the net2ftp application installed on this website: "] = "Ø£Ø±Ø³ÙØª Ø¨ÙØ§Ø³Ø·Ø© Ø¨Ø±ÙØ§ÙØ¬ net2ftp Ø§ÙÙØ±ÙØ¨ Ø¹ÙÙ ÙØ°Ø§ Ø§ÙÙÙÙØ¹ Â» ";
$net2ftp_messages["Webmaster's email: "] = "Ø¨Ø±ÙØ¯ Ø§ÙØ¥Ø¯Ø§Ø±Ø© Â» ";
$net2ftp_messages["Message of the sender: "] = "Ø±Ø³Ø§ÙØ© Ø§ÙÙØ±Ø³Ù Â» ";
$net2ftp_messages["net2ftp is free software, released under the GNU/GPL license. For more information, go to http://www.net2ftp.com."] = "net2ftp Ø¨Ø±ÙØ§ÙØ¬ ÙØ¬Ø§ÙÙ Ø ØµØ§Ø¯Ø± ØªØ­Øª Ø§ÙØªØ±Ø®ÙØµ GNU/GPL .  ÙÙÙØ²ÙØ¯ ÙÙ Ø§ÙÙØ¹ÙÙÙØ§Øª Ø Ø±Ø§Ø¬Ø¹ http://www.net2ftp.com .";

$net2ftp_messages["The zip file has been sent to <b>%1\$s</b>."] = "ØªÙ Ø¥Ø±Ø³Ø§Ù Ø§ÙÙÙÙ Ø§ÙÙØ¶ØºÙØ· Ø¥ÙÙ <b>%1\$s</b>.";

// acceptFiles()
$net2ftp_messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "Ø­Ø¬Ù Ø§ÙÙÙÙ <b>%1\$s</b> ÙØ¨ÙØ± Ø¬Ø¯Ø§Ù . ÙÙ ÙØªÙ Ø±ÙØ¹ ÙØ°Ø§ Ø§ÙÙÙÙ .";
$net2ftp_messages["File <b>%1\$s</b> is contains a banned keyword. This file will not be uploaded."] = "Ø§ÙÙÙ <b>%1\$s</b> ÙØªØ¶ÙÙ ÙÙÙØ§Øª ÙÙØªØ§Ø­ÙØ© ÙØ­Ø¸ÙØ±Ø© .  ÙÙ ÙØªÙ Ø±ÙØ¹ ÙØ°Ø§ Ø§ÙÙÙÙ .";
$net2ftp_messages["Could not generate a temporary file."] = "ØªØ¹Ø°Ø± Ø¥ÙØ´Ø§Ø¡ ÙÙÙ Ø§ÙØªØ®Ø²ÙÙ Ø§ÙÙØ¤ÙØª .";
$net2ftp_messages["File <b>%1\$s</b> could not be moved"] = "ØªØ¹Ø°Ø± ÙÙÙ Ø§ÙÙÙÙ <b>%1\$s</b>";
$net2ftp_messages["File <b>%1\$s</b> is OK"] = "Ø§ÙÙÙ <b>%1\$s</b> ÙØ¬Ø§Ø­ !";
$net2ftp_messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "ØªØ¹Ø°Ø± ÙÙÙ Ø§ÙÙÙÙ Ø§ÙÙØ±ÙÙØ¹ Ø¥ÙÙ ÙØ¬ÙØ¯ temp .<br /><br />ÙØ¬Ø¨ ÙÙØ­ Ø§ÙØªØµØ±ÙØ­ <b>chmod 777</b> Ø¥ÙÙ Ø§ÙÙØ¬ÙØ¯ /temp ÙÙ Ø¯ÙÙÙ net2ftp.";
$net2ftp_messages["You did not provide any file to upload."] = "ÙÙ ØªÙÙ Ø¨ØªØ­Ø¯ÙØ¯ Ø£Ù ÙÙÙ ÙØ±ÙØ¹Ù !";

// ftp_transferfiles()
$net2ftp_messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "ØªØ¹Ø°Ø± ØªØ±Ø­ÙÙ Ø§ÙÙÙÙ <b>%1\$s</b> Ø¥ÙÙ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "ØªÙ ØªØ±Ø­ÙÙ Ø§ÙÙÙÙ <b>%1\$s</b> Ø¥ÙÙ Ø³Ø±ÙØ± FTP Ø¨Ø§Ø³ØªØ®Ø¯Ø§Ù ÙÙØ· FTP <b>%2\$s</b>";
$net2ftp_messages["Transferring files to the FTP server"] = "ØªØ±Ø­ÙÙ Ø§ÙÙÙÙØ§Øª Ø¥ÙÙ Ø³Ø±ÙØ± FTP";

// ftp_unziptransferfiles()
$net2ftp_messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "ÙØ¹Ø§ÙØ¬Ø© Ø§ÙØ£Ø±Ø´ÙÙ Ø±ÙÙ %1\$s Â» <b>%2\$s</b>";
$net2ftp_messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "ØªØ¹Ø°Ø± ÙØ¹Ø§ÙØ¬Ø© Ø§ÙØ£Ø±Ø´ÙÙ <b>%1\$s</b> Ø¨Ø³Ø¨Ø¨ Ø¹Ø¯Ù Ø¯Ø¹Ù ÙØ°Ø§ Ø§ÙÙÙØ¹ . ÙÙØ· Ø£ÙÙØ§Ø¹ Ø§ÙØ£Ø±Ø´ÙÙ zip, tar, tgz Ù gz ÙØ¯Ø¹ÙÙØ© Ø­Ø§ÙÙØ§Ù .";
$net2ftp_messages["Unable to extract the files and directories from the archive"] = "ØªØ¹Ø°Ø± Ø§Ø³ØªØ®Ø±Ø§Ø¬ Ø§ÙÙÙÙØ§Øª Ù Ø§ÙÙØ¬ÙØ¯Ø§Øª ÙÙ Ø§ÙØ£Ø±Ø´ÙÙ";
$net2ftp_messages["Archive contains filenames with ../ or ..\\ - aborting the extraction"] = "Archive contains filenames with ../ or ..\\ - aborting the extraction";
$net2ftp_messages["Could not unzip entry %1\$s (error code %2\$s)"] = "Could not unzip entry %1\$s (error code %2\$s)";
$net2ftp_messages["Created directory %1\$s"] = "ØªÙ Ø¥ÙØ´Ø§Ø¡ Ø§ÙØ¯ÙÙÙ %1\$s";
$net2ftp_messages["Could not create directory %1\$s"] = "ØªØ¹Ø°Ø± Ø¥ÙØ´Ø§Ø¡ Ø§ÙØ¯ÙÙÙ %1\$s";
$net2ftp_messages["Copied file %1\$s"] = "ØªÙ ÙØ³Ø® %1\$s";
$net2ftp_messages["Could not copy file %1\$s"] = "ØªØ¹Ø°Ø± ÙØ³Ø® Ø§ÙÙÙÙ %1\$s";
$net2ftp_messages["Unable to delete the temporary directory"] = "ØªØ¹Ø°Ø± Ø­Ø°Ù Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ¤ÙØª";
$net2ftp_messages["Unable to delete the temporary file %1\$s"] = "ØªØ¹Ø°Ø± Ø­Ø°Ù Ø§ÙÙÙÙ Ø§ÙÙØ¤ÙØª %1\$s";

// ftp_mysite()
$net2ftp_messages["Unable to execute site command <b>%1\$s</b>"] = "ØªØ¹Ø°Ø± ØªÙÙÙØ° Ø§ÙØ± Ø§ÙÙÙÙØ¹ <b>%1\$s</b>";

// shutdown()
$net2ftp_messages["Your task was stopped"] = "ØªÙ Ø¥ÙÙØ§Ù Ø§ÙÙÙÙØ©";
$net2ftp_messages["The task you wanted to perform with net2ftp took more time than the allowed %1\$s seconds, and therefor that task was stopped."] = "Ø§ÙÙÙÙØ© Ø§ÙØªÙ ØªØ±ÙØ¯ Ø¥ÙØ¬Ø§Ø²ÙØ§ Ø¨ÙØ§Ø³Ø·Ø© net2ftp Ø§Ø³ØªØºØ±ÙØª ÙÙØª Ø£Ø·ÙÙ ÙÙ Ø§ÙÙØ³ÙÙØ­ %1\$s Ø«Ø§ÙÙØ© , Ù ÙØ°ÙÙ ØªÙ Ø¥ÙÙØ§Ù Ø§ÙÙÙÙØ© .";
$net2ftp_messages["This time limit guarantees the fair use of the web server for everyone."] = "ÙØ°Ø§ Ø§ÙÙÙØª Ø§ÙÙØ­Ø¯Ø¯ ÙØ¶ÙØ§Ù Ø¹Ø¯Ø§ÙØ© Ø§Ø³ØªØ®Ø¯Ø§Ù Ø§ÙØ³Ø±ÙØ± ÙÙØ¬ÙÙØ¹ .";
$net2ftp_messages["Try to split your task in smaller tasks: restrict your selection of files, and omit the biggest files."] = "Ø¬Ø±Ø¨ ØªØ¬Ø²Ø¦Ø© ÙÙÙØªÙ Ø¥ÙÙ ÙÙÙØ§Øª Ø£ØµØºØ± Â» ÙÙÙ ÙÙ Ø¹Ø¯Ø¯ Ø§ÙÙÙÙØ§Øª Ø§ÙÙØ­Ø¯Ø¯Ø© , Ù Ø§Ø­Ø°Ù Ø§ÙÙÙÙØ§Øª Ø§ÙØ£ÙØ¨Ø± .";
$net2ftp_messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "Ø¥Ø°Ø§ ÙÙØª ØªØ±ÙØ¯ Ø­ÙØ§Ù ØªÙÙÙÙ net2ftp ÙÙ Ø¥ÙØ¬Ø§Ø² Ø§ÙÙÙØ§Ù Ø§ÙÙØ¨ÙØ±Ø© Ø§ÙØªÙ ØªØ³ØªØºØ±Ù ÙÙØª Ø·ÙÙÙ , ÙÙÙÙÙ Ø§ÙØªÙÙÙØ± ÙÙ ØªØ±ÙÙØ¨ Ø¨Ø±ÙØ§ÙØ¬ net2ftp Ø¹ÙÙ ÙÙÙØ¹Ù ÙØ¨Ø§Ø´Ø±Ø© .";

// SendMail()
$net2ftp_messages["You did not provide any text to send by email!"] = "ÙÙ ØªÙØ¯Ù Ø£Ù ÙØµ ÙØ¥Ø±Ø³Ø§ÙÙ Ø¨ÙØ§Ø³Ø·Ø© Ø§ÙØ¨Ø±ÙØ¯ Ø§ÙØ§ÙÙØªØ±ÙÙÙ !";
$net2ftp_messages["You did not supply a From address."] = "ÙØ±Ø¬Ù ÙØªØ§Ø¨Ø© Ø¹ÙÙØ§Ù Ø¨Ø±ÙØ¯ Ø§ÙÙØ±Ø³Ù !";
$net2ftp_messages["You did not supply a To address."] = "ÙØ±Ø¬Ù ÙØªØ§Ø¨Ø© Ø¹ÙÙØ§Ù Ø¨Ø±ÙØ¯ Ø§ÙÙØªÙÙÙ !";
$net2ftp_messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "Ø­Ø¯Ø« Ø®Ø·Ø£ ØªÙÙÙ Ø®ÙØ§Ù ÙØ­Ø§ÙÙØ© Ø§ÙØ¥Ø±Ø³Ø§Ù Ø¥ÙÙ <b>%1\$s</b> ØªØ¹Ø°Ø± Ø§ÙØ¥Ø±Ø³Ø§Ù .";

// tempdir2()
$net2ftp_messages["Unable to create a temporary directory because (unvalid parent directory)"] = "Unable to create a temporary directory because (unvalid parent directory)";
$net2ftp_messages["Unable to create a temporary directory because (parent directory is not writeable)"] = "Unable to create a temporary directory because (parent directory is not writeable)";
$net2ftp_messages["Unable to create a temporary directory (too many tries)"] = "Unable to create a temporary directory (too many tries)";

// -------------------------------------------------------------------------
// /includes/logging.inc.php
// -------------------------------------------------------------------------
// logAccess(), logLogin(), logError()
$net2ftp_messages["Unable to execute the SQL query."] = "ØªØ¹Ø°Ø± ØªÙÙÙØ° Ø§Ø³ØªØ¹ÙØ§Ù SQL .";
$net2ftp_messages["Unable to open the system log."] = "Unable to open the system log.";
$net2ftp_messages["Unable to write a message to the system log."] = "Unable to write a message to the system log.";

// getLogStatus(), putLogStatus()
$net2ftp_messages["Table net2ftp_log_status contains duplicate entries."] = "Table net2ftp_log_status contains duplicate entries.";
$net2ftp_messages["Table net2ftp_log_status could not be updated."] = "Table net2ftp_log_status could not be updated.";

// rotateLogs()
$net2ftp_messages["The log tables were renamed successfully."] = "The log tables were renamed successfully.";
$net2ftp_messages["The log tables could not be renamed."] = "The log tables could not be renamed.";
$net2ftp_messages["The log tables were copied successfully."] = "The log tables were copied successfully.";
$net2ftp_messages["The log tables could not be copied."] = "The log tables could not be copied.";
$net2ftp_messages["The oldest log table was dropped successfully."] = "The oldest log table was dropped successfully.";
$net2ftp_messages["The oldest log table could not be dropped."] = "The oldest log table could not be dropped.";


// -------------------------------------------------------------------------
// /includes/registerglobals.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Please enter your username and password for FTP server "] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± ÙØ³Ø±ÙØ± FTP ";
$net2ftp_messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "ÙÙ ØªÙÙ Ø¨ÙØªØ§Ø¨Ø© ÙØ¹ÙÙÙØ§Øª Ø§ÙØ¯Ø®ÙÙ ÙÙ ÙØ§ÙØ°Ø© Ø§ÙØ¨ÙØ¨ Ø§Ø¨ .<br />Ø§Ø¶ØºØ· Ø¹ÙÙ \"Ø§ÙØ°ÙØ§Ø¨ Ø¥ÙÙ ØµÙØ­Ø© Ø§ÙØ¯Ø®ÙÙ\" Ø¨Ø§ÙØ£Ø³ÙÙ .";
$net2ftp_messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "Ø§ÙØ¯Ø®ÙÙ Ø¥ÙÙ ÙÙØ­Ø© Ø§ÙØªØ­ÙÙ ØºÙØ± ÙØªØ§Ø­ , Ø¨Ø³Ø¨Ø¨ Ø¹Ø¯Ù ØªØ¹ÙÙÙ ÙÙÙØ© ÙØ±ÙØ± ÙÙ Ø§ÙÙÙÙ settings.inc.php . Ø£Ø¯Ø®Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± ÙÙ Ø§ÙÙÙÙ , Ø«Ù Ø£Ø¹Ø¯ ØªØ­ÙÙÙ ÙØ°Ù Ø§ÙØµÙØ­Ø© .";
$net2ftp_messages["Please enter your Admin username and password"] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± Ø§ÙØ¥Ø¯Ø§Ø±ÙØ©";
$net2ftp_messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "ÙÙ ØªÙÙ Ø¨ÙØªØ§Ø¨Ø© ÙØ¹ÙÙÙØ§Øª Ø§ÙØ¯Ø®ÙÙ ÙÙ ÙØ§ÙØ°Ø© Ø§ÙØ¨ÙØ¨ Ø§Ø¨ .<br />Ø§Ø¶ØºØ· Ø¹ÙÙ \"Ø§ÙØ°ÙØ§Ø¨ Ø¥ÙÙ ØµÙØ­Ø© Ø§ÙØ¯Ø®ÙÙ\" Ø¨Ø§ÙØ£Ø³ÙÙ .";
$net2ftp_messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "Ø®Ø·Ø£ ÙÙ Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù Ø£Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± ÙÙÙØ­Ø© Ø§ÙØªØ­ÙÙ . Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± ÙÙÙÙ ØªØ¹ÙÙÙÙØ§ ÙÙ Ø§ÙÙÙÙ settings.inc.php .";


// -------------------------------------------------------------------------
// /skins/skins.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Blue"] = "Blue";
$net2ftp_messages["Grey"] = "Grey";
$net2ftp_messages["Black"] = "Black";
$net2ftp_messages["Yellow"] = "Yellow";
$net2ftp_messages["Pastel"] = "Pastel";

// getMime()
$net2ftp_messages["Directory"] = "Ø§ÙØ¯ÙÙÙ";
$net2ftp_messages["Symlink"] = "Symlink";
$net2ftp_messages["ASP script"] = "ÙÙÙ ASP";
$net2ftp_messages["Cascading Style Sheet"] = "ÙØ±ÙØ© Ø£ÙÙØ§Ø· ÙØªØªØ§ÙÙØ©";
$net2ftp_messages["HTML file"] = "ÙÙÙ HTML";
$net2ftp_messages["Java source file"] = "ÙÙÙ ÙØµØ¯Ø± Java";
$net2ftp_messages["JavaScript file"] = "ÙÙÙ JavaScript";
$net2ftp_messages["PHP Source"] = "ÙØµØ¯Ø± PHP";
$net2ftp_messages["PHP script"] = "ÙÙÙ PHP";
$net2ftp_messages["Text file"] = "ÙÙÙ ÙØµÙ";
$net2ftp_messages["Bitmap file"] = "ØµÙØ±Ø© ÙÙØ·ÙØ© Bitmap";
$net2ftp_messages["GIF file"] = "ØµÙØ±Ø© GIF";
$net2ftp_messages["JPEG file"] = "ØµÙØ±Ø© JPEG";
$net2ftp_messages["PNG file"] = "ØµÙØ±Ø© PNG";
$net2ftp_messages["TIF file"] = "ØµÙØ±Ø© TIF";
$net2ftp_messages["GIMP file"] = "ÙÙÙ GIMP";
$net2ftp_messages["Executable"] = "ÙÙÙ ØªÙÙÙØ°Ù";
$net2ftp_messages["Shell script"] = "ÙÙÙ Shell";
$net2ftp_messages["MS Office - Word document"] = "MS Office - ÙØ³ØªÙØ¯ Word";
$net2ftp_messages["MS Office - Excel spreadsheet"] = "MS Office - Ø¬Ø¯ÙÙ Excel";
$net2ftp_messages["MS Office - PowerPoint presentation"] = "MS Office - Ø¹Ø±Ø¶ ØªÙØ¯ÙÙÙ PowerPoint";
$net2ftp_messages["MS Office - Access database"] = "MS Office - ÙØ§Ø¹Ø¯Ø© Ø¨ÙØ§ÙØ§Øª Access";
$net2ftp_messages["MS Office - Visio drawing"] = "MS Office - ÙØ®Ø·Ø· Visio";
$net2ftp_messages["MS Office - Project file"] = "MS Office - ÙÙÙ ÙØ´Ø±ÙØ¹";
$net2ftp_messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - ÙØ³ØªÙØ¯ Writer 6.0";
$net2ftp_messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - ÙØ§ÙØ¨ Writer 6.0";
$net2ftp_messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - Ø¬Ø¯ÙÙ Calc 6.0";
$net2ftp_messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - ÙØ§ÙØ¨ Calc 6.0";
$net2ftp_messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - ÙØ³ØªÙØ¯ Draw 6.0";
$net2ftp_messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - ÙØ§ÙØ¨ Draw 6.0";
$net2ftp_messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - Ø¹Ø±Ø¶ ØªÙØ¯ÙÙÙ Impress 6.0";
$net2ftp_messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - ÙØ§ÙØ¨ Impress 6.0";
$net2ftp_messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - ÙØ§ÙØ¨ Ø¹Ø§Ù Writer 6.0";
$net2ftp_messages["OpenOffice - Math 6.0 document"] = "OpenOffice - ÙØ³ØªÙØ¯ Math 6.0";
$net2ftp_messages["StarOffice - StarWriter 5.x document"] = "StarOffice - ÙØ³ØªÙØ¯ StarWriter 5.x";
$net2ftp_messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - ÙØ³ØªÙØ¯ Ø¹Ø§Ù StarWriter 5.x";
$net2ftp_messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - Ø¬Ø¯ÙÙ StarCalc 5.x";
$net2ftp_messages["StarOffice - StarDraw 5.x document"] = "StarOffice - ÙØ³ØªÙØ¯ StarDraw 5.x";
$net2ftp_messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - Ø¹Ø±Ø¶ ØªÙØ¯ÙÙÙ StarImpress 5.x";
$net2ftp_messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - ÙÙÙ StarImpress Packed 5.x";
$net2ftp_messages["StarOffice - StarMath 5.x document"] = "StarOffice - ÙØ³ØªÙØ¯ StarMath 5.x";
$net2ftp_messages["StarOffice - StarChart 5.x document"] = "StarOffice - ÙØ³ØªÙØ¯ StarChart 5.x";
$net2ftp_messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - ÙÙÙ Ø¨Ø±ÙØ¯ StarMail 5.x";
$net2ftp_messages["Adobe Acrobat document"] = "ÙØ³ØªÙØ¯ Adobe Acrobat";
$net2ftp_messages["ARC archive"] = "Ø£Ø±Ø´ÙÙ ARC";
$net2ftp_messages["ARJ archive"] = "Ø£Ø±Ø´ÙÙ ARJ";
$net2ftp_messages["RPM"] = "RPM";
$net2ftp_messages["GZ archive"] = "Ø£Ø±Ø´ÙÙ GZ";
$net2ftp_messages["TAR archive"] = "Ø£Ø±Ø´ÙÙ TAR";
$net2ftp_messages["Zip archive"] = "Ø£Ø±Ø´ÙÙ Zip";
$net2ftp_messages["MOV movie file"] = "ÙÙÙ ÙÙØ¯ÙÙ MOV";
$net2ftp_messages["MPEG movie file"] = "ÙÙÙ ÙÙØ¯ÙÙ MPEG movie file";
$net2ftp_messages["Real movie file"] = "ÙÙÙ ÙÙØ¯ÙÙ Real";
$net2ftp_messages["Quicktime movie file"] = "ÙÙÙ ÙÙØ¯ÙÙ Quicktime";
$net2ftp_messages["Shockwave flash file"] = "ÙÙÙ ÙÙØ§Ø´ Shockwave";
$net2ftp_messages["Shockwave file"] = "ÙÙÙ Shockwave";
$net2ftp_messages["WAV sound file"] = "ÙÙÙ ÙÙØ¬Ø© ØµÙØªÙØ©";
$net2ftp_messages["Font file"] = "ÙÙÙ Ø®Ø·";
$net2ftp_messages["%1\$s File"] = "ÙÙÙ %1\$s";
$net2ftp_messages["File"] = "ÙÙÙ";

// getAction()
$net2ftp_messages["Back"] = "Ø®Ø·ÙØ© ÙÙØ®ÙÙ";
$net2ftp_messages["Submit"] = "Ø§Ø¹ØªÙØ¯ Ø§ÙØ¨ÙØ§ÙØ§Øª";
$net2ftp_messages["Refresh"] = "ØªØ­Ø¯ÙØ« Ø§ÙØµÙØ­Ø©";
$net2ftp_messages["Details"] = "Ø§ÙØªÙØ§ØµÙÙ";
$net2ftp_messages["Icons"] = "Ø§ÙØ±ÙÙØ²";
$net2ftp_messages["List"] = "Ø§ÙÙØ§Ø¦ÙØ©";
$net2ftp_messages["Logout"] = "ØªØ³Ø¬ÙÙ Ø§ÙØ®Ø±ÙØ¬";
$net2ftp_messages["Help"] = "ÙØ³Ø§Ø¹Ø¯Ø©";
$net2ftp_messages["Bookmark"] = "Ø£Ø¶Ù Ø¥ÙÙ Ø§ÙÙÙØ¶ÙØ©";
$net2ftp_messages["Save"] = "Ø­ÙØ¸";
$net2ftp_messages["Default"] = "Ø§ÙØ§ÙØªØ±Ø§Ø¶Ù";


// -------------------------------------------------------------------------
// /skins/[skin]/header.template.php and footer.template.php
// -------------------------------------------------------------------------
$net2ftp_messages["Help Guide"] = "Ø¯ÙÙÙ Ø§ÙÙØ³Ø§Ø¹Ø¯Ø©";
$net2ftp_messages["Forums"] = "Ø§ÙÙÙØªØ¯ÙØ§Øª";
$net2ftp_messages["License"] = "Ø§ÙØªØ±Ø®ÙØµ";
$net2ftp_messages["Powered by"] = "Powered by";
$net2ftp_messages["You are now taken to the net2ftp forums. These forums are for net2ftp related topics only - not for generic webhosting questions."] = "Ø³ÙØªÙ ÙÙÙÙ Ø§ÙØ¢Ù Ø¥ÙÙ ÙÙØªØ¯ÙØ§Øª net2ftp . ÙØ°Ù Ø§ÙÙÙØªØ¯ÙØ§Øª ÙØªØ®ØµØµØ© Ø¨ÙÙØ§Ø¶ÙØ¹ Ø¨Ø±ÙØ§ÙØ¬ net2ftp ÙÙØ·  - Ù ÙÙØ³ ÙØ£Ø³Ø¦ÙØ© Ø§ÙØ§Ø³ØªØ¶Ø§ÙØ© Ø§ÙØ¹Ø§ÙØ© .";
$net2ftp_messages["Standard"] = "Standard";
$net2ftp_messages["Mobile"] = "Mobile";

// -------------------------------------------------------------------------
// Admin module
if ($net2ftp_globals["state"] == "admin") {
// -------------------------------------------------------------------------

// /modules/admin/admin.inc.php
$net2ftp_messages["Admin functions"] = "Ø§ÙØ®ÙØ§Ø±Ø§Øª Ø§ÙØ¥Ø¯Ø§Ø±ÙØ©";

// /skins/[skin]/admin1.template.php
$net2ftp_messages["Version information"] = "ÙØ¹ÙÙÙØ§Øª Ø§ÙØ¥ØµØ¯Ø§Ø±";
$net2ftp_messages["This version of net2ftp is up-to-date."] = "ÙØ°Ø§ Ø§ÙØ¥ØµØ¯Ø§Ø± ÙÙ net2ftp ÙØ§Ø¨Ù ÙÙØªØ­Ø¯ÙØ« .";
$net2ftp_messages["The latest version information could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "ØªØ¹Ø°Ø± Ø¬ÙØ¨ Ø¢Ø®Ø± ÙØ¹ÙÙÙØ§Øª Ø§ÙØ¥ØµØ¯Ø§Ø± ÙÙ Ø³Ø±ÙØ± net2ftp . ØªÙØ­Øµ Ø¥Ø¹Ø¯Ø§Ø¯Ø§Øª Ø§ÙØ£ÙØ§Ù ÙÙ ÙØ³ØªØ¹Ø±Ø¶Ù , Ø­ÙØ« ØªÙÙØ¹ ØªØ­ÙÙÙ ÙÙÙ ØµØºÙØ± ÙÙ Ø³Ø±ÙØ± net2ftp.com .";
$net2ftp_messages["Logging"] = "Ø§ÙØ¯Ø®ÙÙ";
$net2ftp_messages["Date from:"] = "Ø§ÙØªØ§Ø±ÙØ® ÙÙ Â»";
$net2ftp_messages["to:"] = "Ø¥ÙÙ Â»";
$net2ftp_messages["Empty logs"] = "Ø¥ÙØ±Ø§Øº Ø§ÙØ³Ø¬Ù";
$net2ftp_messages["View logs"] = "Ø¹Ø±Ø¶ Ø§ÙØ³Ø¬Ù";
$net2ftp_messages["Go"] = "Ø§Ø°ÙØ¨";
$net2ftp_messages["Setup MySQL tables"] = "Ø¥Ø¹Ø¯Ø§Ø¯ Ø¬Ø¯Ø§ÙÙ MySQL";
$net2ftp_messages["Create the MySQL database tables"] = "Ø¥ÙØ´Ø§Ø¡ Ø¬Ø¯Ø§ÙÙ ÙØ§Ø¹Ø¯Ø© Ø§ÙØ¨ÙØ§ÙØ§Øª MySQL";

} // end admin

// -------------------------------------------------------------------------
// Admin_createtables module
if ($net2ftp_globals["state"] == "admin_createtables") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_createtables.inc.php
$net2ftp_messages["Admin functions"] = "Ø§ÙØ®ÙØ§Ø±Ø§Øª Ø§ÙØ¥Ø¯Ø§Ø±ÙØ©";
$net2ftp_messages["The handle of file %1\$s could not be opened."] = "Ø§Ø³Ù Ø§ÙÙÙÙ %1\$s ÙØ§ ÙÙÙÙ ÙØªØ­Ù .";
$net2ftp_messages["The file %1\$s could not be opened."] = "ØªØ¹Ø°Ø± ÙØªØ­ Ø§ÙÙÙÙ %1\$s .";
$net2ftp_messages["The handle of file %1\$s could not be closed."] = "Ø§Ø³Ù Ø§ÙÙÙÙ %1\$s ÙØ§ ÙÙÙÙ ÙØªØ­Ù .";
$net2ftp_messages["The connection to the server <b>%1\$s</b> could not be set up. Please check the database settings you've entered."] = "ØªØ¹Ø°Ø± Ø¥Ø¹Ø¯Ø§Ø¯ Ø§ÙØ§ØªØµØ§Ù Ø¥ÙÙ Ø§ÙØ³Ø±ÙØ± <b>%1\$s</b> . ÙØ±Ø¬Ù Ø§ÙØªØ£ÙØ¯ ÙÙ ÙØ¹ÙÙÙØ§Øª ÙØ§Ø¹Ø¯Ø© Ø§ÙØ¨ÙØ§ÙØ§Øª Ø§ÙØªÙ Ø§Ø¯Ø®ÙØªÙØ§ .";
$net2ftp_messages["Unable to select the database <b>%1\$s</b>."] = "ØªØ¹Ø°Ø± ØªØ­Ø¯ÙØ¯ ÙØ§Ø¹Ø¯Ø© Ø§ÙØ¨ÙØ§ÙØ§Øª <b>%1\$s</b>.";
$net2ftp_messages["The SQL query nr <b>%1\$s</b> could not be executed."] = "ØªØ¹Ø°Ø± ØªÙÙÙØ° Ø§Ø³ØªØ¹ÙØ§Ù SQL  nr <b>%1\$s</b> .";
$net2ftp_messages["The SQL query nr <b>%1\$s</b> was executed successfully."] = "ØªÙ ØªÙÙÙØ° Ø§Ø³ØªØ¹ÙØ§Ù SQL nr <b>%1\$s</b> Ø¨ÙØ¬Ø§Ø­ .";

// /skins/[skin]/admin_createtables1.template.php
$net2ftp_messages["Please enter your MySQL settings:"] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù Ø¥Ø¹Ø¯Ø§Ø¯Ø§Øª ÙØ§Ø¹Ø¯Ø© Ø§ÙØ¨ÙØ§ÙØ§Øª MySQL Â»";
$net2ftp_messages["MySQL username"] = "Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù MySQL";
$net2ftp_messages["MySQL password"] = "ÙÙÙØ© Ø§ÙÙØ±ÙØ± MySQL";
$net2ftp_messages["MySQL database"] = "ÙØ§Ø¹Ø¯Ø© Ø§ÙØ¨ÙØ§ÙØ§Øª MySQL";
$net2ftp_messages["MySQL server"] = "Ø³Ø±ÙØ± MySQL";
$net2ftp_messages["This SQL query is going to be executed:"] = "Ø§Ø³ØªØ¹ÙØ§Ù SQL Ø¬Ø§ÙØ² ÙÙØªÙÙÙØ° Â»";
$net2ftp_messages["Execute"] = "ØªÙÙÙØ° Ø§ÙØ§Ø³ØªØ¹ÙØ§Ù";

// /skins/[skin]/admin_createtables2.template.php
$net2ftp_messages["Settings used:"] = "Ø§ÙØ¥Ø¹Ø¯Ø§Ø¯Ø§Øª Ø§ÙÙØ³ØªØ®Ø¯ÙØ© Â»";
$net2ftp_messages["MySQL password length"] = "Ø¹ÙÙ ÙÙÙØ© ÙØ±ÙØ± MySQL";
$net2ftp_messages["Results:"] = "Ø§ÙÙØªØ§Ø¦Ø¬ Â»";

} // end admin_createtables


// -------------------------------------------------------------------------
// Admin_viewlogs module
if ($net2ftp_globals["state"] == "admin_viewlogs") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_viewlogs.inc.php
$net2ftp_messages["Admin functions"] = "Ø§ÙØ®ÙØ§Ø±Ø§Øª Ø§ÙØ¥Ø¯Ø§Ø±ÙØ©";
$net2ftp_messages["Unable to execute the SQL query <b>%1\$s</b>."] = "ØªØ¹Ø°Ø± ØªÙÙÙØ° Ø§Ø³ØªØ¹ÙØ§Ù SQL <b>%1\$s</b>.";
$net2ftp_messages["No data"] = "ÙØ§ ÙÙØ¬Ø¯ Ø¨ÙØ§ÙØ§Øª";

} // end admin_viewlogs


// -------------------------------------------------------------------------
// Admin_emptylogs module
if ($net2ftp_globals["state"] == "admin_emptylogs") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_emptylogs.inc.php
$net2ftp_messages["Admin functions"] = "Ø§ÙØ®ÙØ§Ø±Ø§Øª Ø§ÙØ¥Ø¯Ø§Ø±ÙØ©";
$net2ftp_messages["The table <b>%1\$s</b> was emptied successfully."] = "ØªÙ Ø¥ÙØ±Ø§Øº Ø§ÙØ¬Ø¯ÙÙ <b>%1\$s</b> Ø¨ÙØ¬Ø§Ø­ !";
$net2ftp_messages["The table <b>%1\$s</b> could not be emptied."] = "ØªØ¹Ø°Ø± Ø¥ÙØ±Ø§Øº Ø§ÙØ¬Ø¯ÙÙ <b>%1\$s</b> !";
$net2ftp_messages["The table <b>%1\$s</b> was optimized successfully."] = "ØªÙ Ø¥ØµÙØ§Ø­ Ø§ÙØ¬Ø¯ÙÙ <b>%1\$s</b> Ø¨ÙØ¬Ø§Ø­ !";
$net2ftp_messages["The table <b>%1\$s</b> could not be optimized."] = "ØªØ¹Ø°Ø± Ø¥ØµÙØ§Ø­ Ø§ÙØ¬Ø¯ÙÙ <b>%1\$s</b> !";

} // end admin_emptylogs


// -------------------------------------------------------------------------
// Advanced module
if ($net2ftp_globals["state"] == "advanced") {
// -------------------------------------------------------------------------

// /modules/advanced/advanced.inc.php
$net2ftp_messages["Advanced functions"] = "Ø§ÙØ®ÙØ§Ø±Ø§Øª Ø§ÙØ¥Ø¯Ø§Ø±ÙØ©";

// /skins/[skin]/advanced1.template.php
$net2ftp_messages["Go"] = "Ø§Ø°ÙØ¨";
$net2ftp_messages["Disabled"] = "ÙØ¹Ø·Ù";
$net2ftp_messages["Advanced FTP functions"] = "ÙØ¸Ø§Ø¦Ù FTP Ø§ÙÙØªÙØ¯ÙØ©";
$net2ftp_messages["Send arbitrary FTP commands to the FTP server"] = "Ø¥Ø±Ø³Ø§Ù Ø£ÙØ± FTP ØªØ­ÙÙÙ Ø¥ÙÙ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["This function is available on PHP 5 only"] = "ÙØ°Ù Ø§ÙÙØ¸ÙÙØ© ÙØªÙÙØ±Ø© ÙÙØ· Ø¹ÙÙ PHP 5";
$net2ftp_messages["Troubleshooting functions"] = "ÙØ¸Ø§Ø¦Ù ØªØªØ¨Ø¹ Ø§ÙØ£Ø®Ø·Ø§Ø¡";
$net2ftp_messages["Troubleshoot net2ftp on this webserver"] = "ØªØªØ¨Ø¹ Ø£Ø®Ø·Ø§Ø¡ net2ftp Ø¹ÙÙ Ø³Ø±Ù Ø§ÙÙÙØ¨ ÙØ°Ø§";
$net2ftp_messages["Troubleshoot an FTP server"] = "ØªØªØ¨Ø¹ Ø£Ø®Ø·Ø§Ø¡ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Test the net2ftp list parsing rules"] = "Ø§Ø®ØªØ¨Ø§Ø± ÙØ§Ø¦ÙØ© ÙÙØ§ÙÙÙ ØªØ¹Ø§Ø¨ÙØ± net2ftp";
$net2ftp_messages["Translation functions"] = "ÙØ¸Ø§Ø¦Ù Ø§ÙØªØ±Ø¬ÙØ©";
$net2ftp_messages["Introduction to the translation functions"] = "ÙÙØ¯ÙØ© Ø¥ÙÙ ÙØ¸Ø§Ø¦Ù Ø§ÙØªØ±Ø¬ÙØ©";
$net2ftp_messages["Extract messages to translate from code files"] = "Ø§Ø³ØªØ®Ø±Ø§Ø¬ Ø§ÙØ±Ø³Ø§Ø¦Ù ÙØªØ±Ø¬ÙØªÙØ§ ÙÙ ÙÙÙØ§Øª Ø§ÙÙÙØ¯";
$net2ftp_messages["Check if there are new or obsolete messages"] = "Ø§ÙØªÙØ­Øµ Ø¹Ù ÙØ¬ÙØ¯ Ø±Ø³Ø§Ø¦Ù Ø¬Ø¯ÙØ¯Ø© Ø£Ù Ø¨Ø§Ø·ÙØ©";

$net2ftp_messages["Beta functions"] = "ÙØ¸Ø§Ø¦Ù ØªØ¬Ø±ÙØ¨ÙØ©";
$net2ftp_messages["Send a site command to the FTP server"] = "Ø¥Ø±Ø³Ø§Ù Ø£ÙØ± Ø§ÙÙÙÙØ¹ Ø¥ÙØ© Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Apache: password-protect a directory, create custom error pages"] = "Apache Â» Ø­ÙØ§ÙØ© Ø¯ÙÙÙ Ø¨ÙÙÙØ© ÙØ±ÙØ± , Ø¥ÙØ´Ø§Ø¡ ØµÙØ­Ø§Øª Ø£Ø®Ø·Ø§Ø¡ ÙØ®ØµØµØ©";
$net2ftp_messages["MySQL: execute an SQL query"] = "MySQL Â» ØªÙÙÙØ° Ø§Ø³ØªØ¹ÙØ§Ù SQL";


// advanced()
$net2ftp_messages["The site command functions are not available on this webserver."] = "ÙØ¸Ø§Ø¦Ù Ø£ÙØ±Ø§ ÙÙÙÙØ¹ ØºÙØ± ÙØªØ§Ø­Ø© Ø¹ÙÙ ÙØ°Ø§ Ø§ÙÙÙØ¨ Ø³Ø±ÙØ± .";
$net2ftp_messages["The Apache functions are not available on this webserver."] = "ÙØ¸Ø§Ø¦Ù Ø£Ø¨Ø§ØªØ´Ù ØºÙØ± ÙØªØ§Ø­Ø© Ø¹ÙÙ ÙØ°Ø§ Ø§ÙÙÙØ¨ Ø³Ø±ÙØ± .";
$net2ftp_messages["The MySQL functions are not available on this webserver."] = "ÙØ¸Ø§Ø¦Ù MySQL ØºÙØ± ÙØªØ§Ø­Ø© Ø¹ÙÙ ÙØ°Ø§ Ø§ÙÙÙØ¨ Ø³Ø±ÙØ± .";
$net2ftp_messages["Unexpected state2 string. Exiting."] = "Ø­Ø§ÙØ© 2 ØºÙØ± ÙÙØ¨ÙÙØ© . ÙÙØ¬ÙØ¯ .";

} // end advanced


// -------------------------------------------------------------------------
// Advanced_ftpserver module
if ($net2ftp_globals["state"] == "advanced_ftpserver") {
// -------------------------------------------------------------------------

// /modules/advanced_ftpserver/advanced_ftpserver.inc.php
$net2ftp_messages["Troubleshoot an FTP server"] = "ØªØªØ¨Ø¹ Ø£Ø®Ø·Ø§Ø¡ Ø³Ø±ÙØ± FTP";

// /skins/[skin]/advanced_ftpserver1.template.php
$net2ftp_messages["Connection settings:"] = "Ø¥Ø¹Ø¯Ø§Ø¯Ø§Øª Ø§ÙØ§ØªØµØ§Ù Â»";
$net2ftp_messages["FTP server"] = "Ø³Ø±ÙØ± FTP";
$net2ftp_messages["FTP server port"] = "ÙÙÙØ° Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Username"] = "Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù";
$net2ftp_messages["Password"] = "ÙÙÙØ© Ø§ÙÙØ±ÙØ±";
$net2ftp_messages["Password length"] = "Ø·ÙÙ ÙÙÙØ© Ø§ÙÙØ±ÙØ±";
$net2ftp_messages["Passive mode"] = "ÙÙØ· Passive Ø§ÙØ®ÙÙÙ";
$net2ftp_messages["Directory"] = "Ø§ÙØ¯ÙÙÙ";
$net2ftp_messages["Printing the result"] = "Ø·Ø¨Ø§Ø¹Ø© Ø§ÙÙØªÙØ¬Ø©";

// /skins/[skin]/advanced_ftpserver2.template.php
$net2ftp_messages["Connecting to the FTP server: "] = "Ø§ÙØ§ØªØµØ§Ù Ø¨Ø³Ø±ÙØ± FTP Â» ";
$net2ftp_messages["Logging into the FTP server: "] = "Ø§ÙØ¯Ø®ÙÙ Ø¥ÙÙ Ø³Ø±ÙØ± FTP Â» ";
$net2ftp_messages["Setting the passive mode: "] = "Ø¥Ø¹Ø¯Ø§Ø¯ ÙÙØ· passive Ø§ÙØ®ÙÙÙ Â» ";
$net2ftp_messages["Getting the FTP server system type: "] = "Ø¯Ø®ÙÙ ÙÙØ· ÙØ¸Ø§Ù Ø³Ø±ÙØ± FTP Â» ";
$net2ftp_messages["Changing to the directory %1\$s: "] = "Ø§ÙØªØºÙÙØ± Ø¥ÙÙ Ø§ÙØ¯ÙÙÙ %1\$s Â» ";
$net2ftp_messages["The directory from the FTP server is: %1\$s "] = "Ø§ÙØ¯ÙÙÙ ÙÙ Ø³Ø±ÙØ± FTP ÙÙ Â» %1\$s ";
$net2ftp_messages["Getting the raw list of directories and files: "] = "Ø§ÙØ­ØµÙÙ Ø¹ÙÙ ÙØ§Ø¦ÙØ© Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª Â» ";
$net2ftp_messages["Trying a second time to get the raw list of directories and files: "] = "ÙØ­Ø§ÙÙØ© Ø«Ø§ÙÙØ© ÙÙØ­ØµÙÙ Ø¹ÙÙ ÙØ§Ø¦ÙØ© Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª Â» ";
$net2ftp_messages["Closing the connection: "] = "Ø¥ØºÙØ§Ù Ø§ÙØ§ØªØµØ§Ù Â» ";
$net2ftp_messages["Raw list of directories and files:"] = "ÙØ§Ø¦ÙØ© Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª Â»";
$net2ftp_messages["Parsed list of directories and files:"] = "ÙØ§Ø¦ÙØ© ØªØ¹Ø§Ø¨ÙØ± Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª Â»";

$net2ftp_messages["OK"] = "ÙØ¬Ø§Ø­";
$net2ftp_messages["not OK"] = "ÙØ´Ù";

} // end advanced_ftpserver


// -------------------------------------------------------------------------
// Advanced_parsing module
if ($net2ftp_globals["state"] == "advanced_parsing") {
// -------------------------------------------------------------------------

$net2ftp_messages["Test the net2ftp list parsing rules"] = "Ø§Ø®ØªØ¨Ø§Ø± ÙØ§Ø¦ÙØ© ÙÙØ§ÙÙÙ ØªØ¹Ø§Ø¨ÙØ± net2ftp";
$net2ftp_messages["Sample input"] = "Ø§Ø®ØªØ¨Ø§Ø± Ø§ÙØ¯Ø®Ù";
$net2ftp_messages["Parsed output"] = "ØªØ¹Ø¨ÙØ± Ø§ÙØ®Ø±Ø¬";

} // end advanced_parsing


// -------------------------------------------------------------------------
// Advanced_webserver module
if ($net2ftp_globals["state"] == "advanced_webserver") {
// -------------------------------------------------------------------------

$net2ftp_messages["Troubleshoot your net2ftp installation"] = "ØªØªØ¨Ø¹ Ø£Ø®Ø·Ø§Ø¡ ØªØ±ÙÙØ¨ net2ftp";
$net2ftp_messages["Printing the result"] = "Ø·Ø¨Ø§Ø¹Ø© Ø§ÙÙØªÙØ¬Ø©";

$net2ftp_messages["Checking if the FTP module of PHP is installed: "] = "Ø§ÙØªØ­ÙÙ ÙÙ ØªØ±ÙÙØ¨ ÙØ¸ÙÙØ© FTP ÙÙ PHP Â» ";
$net2ftp_messages["yes"] = "ÙØ¹Ù";
$net2ftp_messages["no - please install it!"] = "ÙØ§ - ÙØ±Ø¬Ù ØªØ±ÙÙØ¨ÙØ§ !";

$net2ftp_messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "Ø§ÙØªØ­ÙÙ ÙÙ ØµÙØ§Ø­ÙØ§Øª Ø§ÙØ¯ÙÙÙ Ø¹ÙÙ Ø³Ø±ÙØ± Ø§ÙÙÙØ¨ Â» Ø³ÙØªÙ ÙØªØ§Ø¨Ø© ÙÙÙ ØµØºÙØ± Ø¥ÙÙ Ø§ÙÙØ¬ÙØ¯ /temp Ø«Ù Ø­Ø°ÙÙ .";
$net2ftp_messages["Creating filename: "] = "Ø¥ÙØ´Ø§Ø¡ Ø§Ø³Ù Ø§ÙÙÙÙ Â» ";
$net2ftp_messages["OK. Filename: %1\$s"] = "ÙØ¬Ø§Ø­ . Ø§Ø³Ù Ø§ÙÙÙÙ Â» %1\$s";
$net2ftp_messages["not OK"] = "ÙØ´Ù";
$net2ftp_messages["OK"] = "ÙØ¬Ø§Ø­";
$net2ftp_messages["not OK. Check the permissions of the %1\$s directory"] = "ÙØ´Ù . ØªØ£ÙØ¯ ÙÙ ØµÙØ§Ø­ÙØ§Øª Ø§ÙØ¯ÙÙÙ %1\$s ";
$net2ftp_messages["Opening the file in write mode: "] = "ÙØªØ­ Ø§ÙÙÙÙ ÙÙ ÙÙØ· Ø§ÙÙØªØ§Ø¨Ø© Â» ";
$net2ftp_messages["Writing some text to the file: "] = "ÙØªØ§Ø¨Ø© Ø¨Ø¹Ø¶ Ø§ÙÙØµ ÙÙ Ø§ÙÙÙÙ Â» ";
$net2ftp_messages["Closing the file: "] = "Ø¥ØºÙØ§Ù Ø§ÙÙÙÙ Â» ";
$net2ftp_messages["Deleting the file: "] = "Ø­Ø°Ù Ø§ÙÙÙÙ Â» ";

$net2ftp_messages["Testing the FTP functions"] = "Ø§Ø®ØªØ¨Ø§Ø± ÙØ¸Ø§Ø¦Ù FTP";
$net2ftp_messages["Connecting to a test FTP server: "] = "Ø§ÙØ§ØªØµØ§Ù ÙØ§Ø®ØªØ¨Ø§Ø± Ø³Ø±ÙØ± FTP Â» ";
$net2ftp_messages["Connecting to the FTP server: "] = "Ø§ÙØ§ØªØµØ§Ù Ø¨Ø³Ø±ÙØ± FTP Â» ";
$net2ftp_messages["Logging into the FTP server: "] = "Ø§ÙØ¯Ø®ÙÙ Ø¥ÙÙ Ø³Ø±ÙØ± FTP Â» ";
$net2ftp_messages["Setting the passive mode: "] = "Ø¥Ø¹Ø¯Ø§Ø¯ ÙÙØ· passive Ø§ÙØ®ÙÙÙ Â» ";
$net2ftp_messages["Getting the FTP server system type: "] = "Ø¯Ø®ÙÙ ÙÙØ· ÙØ¸Ø§Ù Ø³Ø±ÙØ± FTP Â» ";
$net2ftp_messages["Changing to the directory %1\$s: "] = "Ø§ÙØªØºÙÙØ± Ø¥ÙÙ Ø§ÙØ¯ÙÙÙ %1\$s Â» ";
$net2ftp_messages["The directory from the FTP server is: %1\$s "] = "Ø§ÙØ¯ÙÙÙ ÙÙ Ø³Ø±ÙØ± FTP ÙÙ Â» %1\$s ";
$net2ftp_messages["Getting the raw list of directories and files: "] = "Ø§ÙØ­ØµÙÙ Ø¹ÙÙ ÙØ§Ø¦ÙØ© Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª Â» ";
$net2ftp_messages["Trying a second time to get the raw list of directories and files: "] = "ÙØ­Ø§ÙÙØ© Ø«Ø§ÙÙØ© ÙÙØ­ØµÙÙ Ø¹ÙÙ ÙØ§Ø¦ÙØ© Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª Â» ";
$net2ftp_messages["Closing the connection: "] = "Ø¥ØºÙØ§Ù Ø§ÙØ§ØªØµØ§Ù Â» ";
$net2ftp_messages["Raw list of directories and files:"] = "ÙØ§Ø¦ÙØ© Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª Â»";
$net2ftp_messages["Parsed list of directories and files:"] = "ÙØ§Ø¦ÙØ© ØªØ¹Ø§Ø¨ÙØ± Ø§ÙØ£Ø¯ÙØ© Ù Ø§ÙÙÙÙØ§Øª Â»";
$net2ftp_messages["OK"] = "ÙØ¬Ø§Ø­";
$net2ftp_messages["not OK"] = "ÙØ´Ù";

} // end advanced_webserver


// -------------------------------------------------------------------------
// Bookmark module
if ($net2ftp_globals["state"] == "bookmark") {
// -------------------------------------------------------------------------

$net2ftp_messages["Drag and drop one of the links below to the bookmarks bar"] = "Drag and drop one of the links below to the bookmarks bar";
$net2ftp_messages["Right-click on one of the links below and choose \"Add to Favorites...\""] = "Right-click on one of the links below and choose \"Add to Favorites...\"";
$net2ftp_messages["Right-click on one the links below and choose \"Add Link to Bookmarks...\""] = "Right-click on one the links below and choose \"Add Link to Bookmarks...\"";
$net2ftp_messages["Right-click on one of the links below and choose \"Bookmark link...\""] = "Right-click on one of the links below and choose \"Bookmark link...\"";
$net2ftp_messages["Right-click on one of the links below and choose \"Bookmark This Link...\""] = "Right-click on one of the links below and choose \"Bookmark This Link...\"";
$net2ftp_messages["One click access (net2ftp won't ask for a password - less safe)"] = "One click access (net2ftp won't ask for a password - less safe)";
$net2ftp_messages["Two click access (net2ftp will ask for a password - safer)"] = "Two click access (net2ftp will ask for a password - safer)";
$net2ftp_messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "ÙÙØ§Ø­Ø¸Ø© Â» Ø¹ÙØ¯ Ø§Ø³ØªØ®Ø¯Ø§Ù Ø§ÙØ§Ø®ØªØµØ§Ø± ÙÙ Ø§ÙÙÙØ¶ÙØ© , Ø³ÙØ·ÙØ¨ ÙÙÙ Ø¨ÙØ§Ø³Ø·Ø© ÙØ§ÙØ°Ø© Ø¨ÙØ¨ Ø§Ø¨ Ø¥Ø¯Ø®Ø§Ù Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± .";

} // end bookmark


// -------------------------------------------------------------------------
// Browse module
if ($net2ftp_globals["state"] == "browse") {
// -------------------------------------------------------------------------

// /modules/browse/browse.inc.php
$net2ftp_messages["Choose a directory"] = "Ø§Ø®ØªØ± Ø¯ÙÙÙ";
$net2ftp_messages["Please wait..."] = "ÙØ±Ø¬Ù Ø§ÙØ§ÙØªØ¸Ø§Ø± ...";

// browse()
$net2ftp_messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "Ø§ÙØ£Ø¯ÙØ© Ø§ÙØªÙ ØªØ­ØªÙÙ Ø§Ø³ÙØ§Ø¦ÙØ§ Ø¹ÙÙ \' ÙØ§ ÙÙÙÙ Ø¹Ø±Ø¶ÙØ§ Ø¨Ø´ÙÙ ØµØ­ÙØ­ . ÙÙÙÙ ÙÙØ· Ø­Ø°ÙÙØ§ . ÙØ±Ø¬Ù Ø§ÙØ¹ÙØ¯Ø© ÙÙØ®ÙÙ Ù Ø§Ø®ØªÙØ§Ø± Ø¯ÙÙÙ ÙØ±Ø¹Ù Ø¢Ø®Ø± .";

$net2ftp_messages["Daily limit reached: you will not be able to transfer data"] = "Ø§ÙØ­ØµØ© Ø§ÙÙÙÙÙØ© Ø§ÙØªÙØª Â» ÙØ§ ÙÙÙÙÙ ÙØªØ§Ø¨Ø¹Ø© ØªØ±Ø­ÙÙ Ø§ÙØ¨ÙØ§ÙØ§Øª .";
$net2ftp_messages["In order to guarantee the fair use of the web server for everyone, the data transfer volume and script execution time are limited per user, and per day. Once this limit is reached, you can still browse the FTP server but not transfer data to/from it."] = "ÙØ¶ÙØ§Ù Ø§Ø³ØªØ®Ø¯Ø§Ù Ø§ÙØ³Ø±ÙØ± ÙÙØ¨ ÙÙØ¬ÙÙØ¹ , ØªÙ ØªØ­Ø¯ÙØ¯ Ø­ØµØ© ÙÙÙÙØ© ÙØªØ±Ø­ÙÙ Ø§ÙØ¨ÙØ§ÙØ§Øª Ù Ø§ÙÙÙÙØ§Øª ÙÙÙ ÙØ³ØªØ®Ø¯Ù . Ø¹ÙØ¯ Ø§Ø³ØªÙÙØ§ÙÙ ÙÙØ°Ù Ø§ÙØ­ØµØ© , ØªØ³Ø·ÙØ¹ Ø§Ø³ØªØ¹Ø±Ø§Ø¶ Ø³Ø±ÙØ± FTP Ù ÙÙÙ ÙØ§ ÙÙÙÙÙ ÙØªØ§Ø¨Ø¹Ø© ÙÙÙ Ø§ÙØ¨ÙØ§ÙØ§Øª ÙÙ Ù Ø¥ÙÙ .";
$net2ftp_messages["If you need unlimited usage, please install net2ftp on your own web server."] = "Ø¥Ø°Ø§ ÙÙØª ØªØ±ÙØ¯ Ø§Ø³ØªØ®Ø¯Ø§Ù ÙØ°Ù Ø§Ø®Ø¯ÙØ© Ø¨Ø¯ÙÙ Ø­Ø¯ÙØ¯ , ÙÙÙÙÙ ØªØ±ÙÙØ¨ net2ftp Ø¹ÙÙ Ø³Ø±ÙØ±Ù Ø§ÙØ®Ø§Øµ .";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$net2ftp_messages["New dir"] = "Ø¯ÙÙÙ Ø¬Ø¯ÙØ¯";
$net2ftp_messages["New file"] = "ÙÙÙ Ø¬Ø¯ÙØ¯";
$net2ftp_messages["HTML templates"] = "ÙÙØ§ÙØ¨ HTML";
$net2ftp_messages["Upload"] = "Ø§ÙØ±ÙØ¹";
$net2ftp_messages["Java Upload"] = "Ø§ÙØ±ÙØ¹ Ø¨Ù Java";
$net2ftp_messages["Flash Upload"] = "Ø±ÙØ¹ Ø¨ÙØ§Ø³Ø·Ø© Ø§ÙÙÙØ§Ø´";
$net2ftp_messages["Install"] = "Ø§ÙØªØ±ÙÙØ¨";
$net2ftp_messages["Advanced"] = "ÙØªÙØ¯Ù";
$net2ftp_messages["Copy"] = "ÙØ³Ø®";
$net2ftp_messages["Move"] = "ÙÙÙ";
$net2ftp_messages["Delete"] = "Ø­Ø°Ù";
$net2ftp_messages["Rename"] = "Ø¥Ø¹Ø§Ø¯Ø© ØªØ³ÙÙØ©";
$net2ftp_messages["Chmod"] = "ØªØµØ±ÙØ­";
$net2ftp_messages["Download"] = "ØªØ­ÙÙÙ";
$net2ftp_messages["Unzip"] = "Ø§Ø³ØªØ®Ø±Ø§Ø¬";
$net2ftp_messages["Zip"] = "Zip";
$net2ftp_messages["Size"] = "Ø§ÙØ­Ø¬Ù";
$net2ftp_messages["Search"] = "Ø¨Ø­Ø«";
$net2ftp_messages["Go to the parent directory"] = "Ø§ÙØ°ÙØ§Ø¨ Ø¥ÙÙ Ø§ÙÙØ¬ÙØ¯ Ø§ÙØ£ØµÙ";
$net2ftp_messages["Go"] = "Ø§Ø°ÙØ¨";
$net2ftp_messages["Transform selected entries: "] = "ØªØ­ÙÙÙ Ø§ÙØ¹ÙØ§ØµØ± Ø§ÙÙØ­Ø¯Ø¯Ø© Â» ";
$net2ftp_messages["Transform selected entry: "] = "ØªØ­ÙÙÙ Ø§ÙØ¹ÙØµØ± Ø§ÙÙØ­Ø¯Ø¯ Â» ";
$net2ftp_messages["Make a new subdirectory in directory %1\$s"] = "Ø¥ÙØ´Ø§Ø¡ Ø¯ÙÙÙ ÙØ±Ø¹Ù Ø¬Ø¯ÙØ¯ ÙÙ Ø§ÙØ¯ÙÙÙ %1\$s";
$net2ftp_messages["Create a new file in directory %1\$s"] = "Ø¥ÙØ´Ø§Ø¡ ÙÙÙ Ø¬Ø¯ÙØ¯ ÙÙ Ø§ÙØ¯ÙÙÙ %1\$s";
$net2ftp_messages["Create a website easily using ready-made templates"] = "Ø¥ÙØ´Ø§Ø¡ Ø§ÙÙÙØ§ÙØ¹ Ø³ÙÙ Ø¨Ø§Ø³ØªØ®Ø¯Ø§Ù Ø§ÙÙÙØ§ÙØ¨ Ø§ÙØ¬Ø§ÙØ²Ø©";
$net2ftp_messages["Upload new files in directory %1\$s"] = "Ø±ÙØ¹ ÙÙÙØ§Øª Ø¬Ø¯ÙØ¯ Ø¥ÙÙ Ø§ÙØ¯ÙÙÙ %1\$s";
$net2ftp_messages["Upload directories and files using a Java applet"] = "Ø±ÙØ¹ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª Ø¨ÙØ§Ø³Ø·Ø© Java applet";
$net2ftp_messages["Upload files using a Flash applet"] = "Ø±ÙØ¹ Ø§ÙÙÙÙØ§Øª Ø¨ÙØ§Ø³Ø·Ø© Flash applet";
$net2ftp_messages["Install software packages (requires PHP on web server)"] = "ØªØ±ÙÙØ¨ Ø­Ø²ÙØ© Ø§ÙØ¨Ø±ÙØ§ÙØ¬ ( ÙØªØ·ÙØ¨ Ø³Ø±ÙØ± PHP Ø¹ÙÙ Ø§ÙÙÙÙØ¹ )";
$net2ftp_messages["Go to the advanced functions"] = "Ø§ÙØ°ÙØ§Ø¨ Ø¥ÙÙ Ø§ÙÙØ¸Ø§Ø¦Ù Ø§ÙÙØªÙØ¯ÙØ©";
$net2ftp_messages["Copy the selected entries"] = "ÙØ³Ø® Ø§ÙØ¹ÙØ§ØµØ± Ø§ÙÙØ­Ø¯Ø¯Ø©";
$net2ftp_messages["Move the selected entries"] = "ÙÙÙ Ø§ÙØ¹ÙØ§ØµØ± Ø§ÙÙØ­Ø¯Ø¯Ø©";
$net2ftp_messages["Delete the selected entries"] = "Ø­Ø°Ù Ø§ÙØ¹ÙØ§ØµØ± Ø§ÙÙØ­Ø¯Ø¯Ø©";
$net2ftp_messages["Rename the selected entries"] = "Ø¥Ø¹Ø§Ø¯Ø© ØªØ³ÙÙØ© Ø§ÙØ¹ÙØ§ØµØ± Ø§ÙÙØ­Ø¯Ø¯Ø©";
$net2ftp_messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "ØªØµØ±ÙØ­ Ø§ÙØ¹ÙØ§ØµØ± Ø§ÙÙØ­Ø¯Ø¯Ø© (ÙØ¹ÙÙ ÙÙØ· Ø¹ÙÙ Ø³Ø±ÙØ±Ø§Øª Unix/Linux/BSD)";
$net2ftp_messages["Download a zip file containing all selected entries"] = "ØªØ­ÙÙÙ ÙÙÙ zip ÙØ­ØªÙÙ Ø¹ÙÙ Ø¬ÙÙØ¹ Ø§ÙØ¹ÙØ§ØµØ± Ø§ÙÙØ­Ø¯Ø¯Ø©";
$net2ftp_messages["Unzip the selected archives on the FTP server"] = "ÙÙ Ø¶ØºØ· Ø§ÙØ£Ø±Ø§Ø´ÙÙ Ø§ÙÙØ­Ø¯Ø¯Ø© Ø¹ÙÙ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Zip the selected entries to save or email them"] = "Ø¶ØºØ· Zip Ø§ÙØ¹ÙØ§ØµØ± Ø§ÙÙØ­Ø¯Ø¯Ø© ÙØ­ÙØ¸ÙØ§ Ø£Ù Ø¥Ø±Ø³Ø§ÙÙØ§ Ø¨Ø§ÙØ¨Ø±ÙØ¯";
$net2ftp_messages["Calculate the size of the selected entries"] = "Ø­Ø³Ø§Ø¨ Ø­Ø¬Ù Ø§ÙØ¹ÙØ§ØµØ± Ø§ÙÙØ­Ø¯Ø¯Ø©";
$net2ftp_messages["Find files which contain a particular word"] = "Ø¥ÙØ¬Ø§Ø¯ Ø§ÙÙÙÙØ§Øª Ø§ÙØªÙ ØªØªØ¶ÙÙ Ø§ÙÙÙÙØ© Ø¬Ø²Ø¦ÙØ§Ù";
$net2ftp_messages["Click to sort by %1\$s in descending order"] = "Ø§Ø¶ØºØ· ÙÙØ±Ø² %1\$s Ø¨ØªØ±ØªÙØ¨ ØªÙØ§Ø²ÙÙ";
$net2ftp_messages["Click to sort by %1\$s in ascending order"] = "Ø§Ø¶ØºØ· ÙÙØ±Ø² %1\$s Ø¨ØªØ±ØªÙØ¨ ØªØµØ§Ø¹Ø¯Ù";
$net2ftp_messages["Ascending order"] = "ØªØ±ØªÙØ¨ ØªØµØ§Ø¹Ø¯Ù";
$net2ftp_messages["Descending order"] = "ØªØ±ØªÙØ¨ ØªÙØ§Ø²ÙÙ";
$net2ftp_messages["Upload files"] = "Ø±ÙØ¹ Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Up"] = "Ø®Ø·ÙØ© Ø¥ÙÙ Ø§ÙØ£Ø¹ÙÙ";
$net2ftp_messages["Click to check or uncheck all rows"] = "Ø§Ø¶ØºØ· ÙØªØ­Ø¯ÙØ¯ Ø£Ù Ø¥ÙØºØ§Ø¡ ØªØ­Ø¯ÙØ¯ Ø¬ÙÙØ¹ Ø§ÙØµÙÙÙ";
$net2ftp_messages["All"] = "Ø§ÙÙÙ";
$net2ftp_messages["Name"] = "Ø§ÙØ§Ø³Ù";
$net2ftp_messages["Type"] = "Ø§ÙÙÙØ¹";
//$net2ftp_messages["Size"] = "Size";
$net2ftp_messages["Owner"] = "Ø§ÙÙØ§ÙÙ";
$net2ftp_messages["Group"] = "Ø§ÙÙØ¬ÙÙØ¹Ø©";
$net2ftp_messages["Perms"] = "Ø§ÙØµÙØ§Ø­ÙØ©";
$net2ftp_messages["Mod Time"] = "ÙÙØ· Ø§ÙÙÙØª";
$net2ftp_messages["Actions"] = "Ø§ÙØ¥Ø¬Ø±Ø§Ø¡Ø§Øª";
$net2ftp_messages["Select the directory %1\$s"] = "Ø­Ø¯Ø¯ Ø§ÙØ¯ÙÙÙ %1\$s";
$net2ftp_messages["Select the file %1\$s"] = "Ø­Ø¯Ø¯ Ø§ÙÙÙÙ %1\$s";
$net2ftp_messages["Select the symlink %1\$s"] = "Ø­Ø¯Ø¯ symlink %1\$s";
$net2ftp_messages["Go to the subdirectory %1\$s"] = "Ø§ÙØ°ÙØ§Ø¨ Ø¥ÙÙ Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ±Ø¹Ù %1\$s";
$net2ftp_messages["Download the file %1\$s"] = "ØªØ­ÙÙÙ Ø§ÙÙÙÙ %1\$s";
$net2ftp_messages["Follow symlink %1\$s"] = "Ø§ØªØ¨Ø¹ Ø§ÙØ±Ø§Ø¨Ø· %1\$s";
$net2ftp_messages["View"] = "Ø¹Ø±Ø¶";
$net2ftp_messages["Edit"] = "ØªØ­Ø±ÙØ±";
$net2ftp_messages["Update"] = "ØªØ­Ø¯ÙØ«";
$net2ftp_messages["Open"] = "ÙØªØ­";
$net2ftp_messages["View the highlighted source code of file %1\$s"] = "Ø¹Ø±Ø¶ ÙÙØ¯ Ø§ÙÙØµØ¯Ø± Ø§ÙÙÙÙØ² ÙÙÙÙÙ %1\$s";
$net2ftp_messages["Edit the source code of file %1\$s"] = "ØªØ­Ø±ÙØ± ÙÙØ¯ Ø§ÙÙØµØ¯Ø± ÙÙÙÙÙ %1\$s";
$net2ftp_messages["Upload a new version of the file %1\$s and merge the changes"] = "Ø±ÙØ¹ ÙØ³Ø®Ø© Ø¬Ø¯ÙØ¯Ø© ÙÙ Ø§ÙÙÙÙ %1\$s Ù Ø¯ÙØ¬ Ø§ÙØªØ¹Ø¯ÙÙØ§Øª";
$net2ftp_messages["View image %1\$s"] = "Ø¹Ø±Ø¶ Ø§ÙØµÙØ±Ø© %1\$s";
$net2ftp_messages["View the file %1\$s from your HTTP web server"] = "Ø¹Ø±Ø¶ Ø§ÙÙÙÙ %1\$s Ø¨ÙØ§Ø³Ø·Ø© Ø³Ø±ÙØ± Ø§ÙÙÙØ¨ HTTP";
$net2ftp_messages["(Note: This link may not work if you don't have your own domain name.)"] = "(ÙÙØ§Ø­Ø¸Ø© Â» ÙØ¯ ÙØ§ ÙØ¹ÙÙ ÙØ°Ø§ Ø§ÙØ±Ø§Ø¨Ø· Ø¥Ù ÙÙ ÙÙÙ ÙØ¯ÙÙ Ø¯ÙÙÙÙ Ø®Ø§Øµ .)";
$net2ftp_messages["This folder is empty"] = "ÙØ°Ø§ Ø§ÙÙØ¬ÙØ¯ ÙØ§Ø±Øº";

// printSeparatorRow()
$net2ftp_messages["Directories"] = "Ø§ÙÙØ¬ÙØ¯Ø§Øª";
$net2ftp_messages["Files"] = "Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Symlinks"] = "Symlinks";
$net2ftp_messages["Unrecognized FTP output"] = "Ø®Ø±Ø¬ FTP ØºÙØ± ÙØ¹Ø±ÙÙ";
$net2ftp_messages["Number"] = "Ø§ÙØ¹Ø¯Ø¯";
$net2ftp_messages["Size"] = "Ø§ÙØ­Ø¬Ù";
$net2ftp_messages["Skipped"] = "ØªÙ ØªØ®Ø·ÙÙ";
$net2ftp_messages["Data transferred from this IP address today"] = "Ø§ÙØ¨ÙØ§ÙØ§Øª Ø§ÙØªÙ ØªÙ ØªØ±Ø­ÙÙÙØ§ Ø¨ÙØ§Ø³Ø·Ø© ÙØ°Ø§ Ø§ÙØ£Ù Ø¨Ù Ø§ÙÙÙÙ";
$net2ftp_messages["Data transferred to this FTP server today"] = "Ø§ÙØ¨ÙØ§ÙØ§Øª Ø§ÙØªÙ ØªÙ ØªØ±Ø­ÙÙÙØ§ Ø¨ÙØ§Ø³Ø·Ø© Ø³ÙØ± FTP ÙØ°Ø§ Ø§ÙÙÙÙ";

// printLocationActions()
$net2ftp_messages["Language:"] = "Ø§ÙÙØºØ© Â»";
$net2ftp_messages["Skin:"] = "Ø§ÙØ´ÙÙ Â»";
$net2ftp_messages["View mode:"] = "Ø·Ø±ÙÙØ© Ø§ÙØ¹Ø±Ø¶ Â»";
$net2ftp_messages["Directory Tree"] = "Ø´Ø¬Ø±Ø© Ø§ÙØ¯ÙÙÙ";

// ftp2http()
$net2ftp_messages["Execute %1\$s in a new window"] = "ØªÙÙÙØ° %1\$s ÙÙ ÙØ§ÙØ°Ø© Ø¬Ø¯ÙØ¯Ø©";
$net2ftp_messages["This file is not accessible from the web"] = "ÙØ§ ÙÙÙÙ Ø§ÙÙØµÙÙ Ø¥ÙÙ ÙØ°Ø§ Ø§ÙÙÙÙ ÙÙ Ø§ÙÙÙØ¨";

// printDirectorySelect()
$net2ftp_messages["Double-click to go to a subdirectory:"] = "Ø¶ØºØ· ÙØ²Ø°ÙØ¬ ÙÙØ°ÙØ§Ø¨ Ø¥ÙÙ Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ±Ø¹Ù";
$net2ftp_messages["Choose"] = "Ø§Ø®ØªÙØ§Ø±";
$net2ftp_messages["Up"] = "Ø®Ø·ÙØ© Ø¥ÙÙ Ø§ÙØ£Ø¹ÙÙ";

} // end browse


// -------------------------------------------------------------------------
// Calculate size module
if ($net2ftp_globals["state"] == "calculatesize") {
// -------------------------------------------------------------------------
$net2ftp_messages["Size of selected directories and files"] = "Ø­Ø¬Ù Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª Ø§ÙÙØ­Ø¯Ø¯Ø©";
$net2ftp_messages["The total size taken by the selected directories and files is:"] = "ÙØ¬ÙÙØ¹ Ø­Ø¬Ù Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª Ø§ÙÙØ­Ø¯Ø¯Ø© ÙÙ Â»";
$net2ftp_messages["The number of files which were skipped is:"] = "Ø¹Ø¯Ø¯ Ø§ÙÙÙÙØ§Øª Ø§ÙØªÙ ØªÙ ØªØ®Ø·ÙÙØ§ ÙÙ Â»";

} // end calculatesize


// -------------------------------------------------------------------------
// Chmod module
if ($net2ftp_globals["state"] == "chmod") {
// -------------------------------------------------------------------------
$net2ftp_messages["Chmod directories and files"] = "ØªØµØ±ÙØ­ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Set all permissions"] = "ØªØ¹ÙÙÙ Ø¬ÙÙØ¹ Ø§ÙØµÙØ§Ø­ÙØ§Øª";
$net2ftp_messages["Read"] = "ÙØ±Ø§Ø¡Ø©";
$net2ftp_messages["Write"] = "ÙØªØ§Ø¨Ø©";
$net2ftp_messages["Execute"] = "ØªÙÙÙØ° Ø§ÙØ§Ø³ØªØ¹ÙØ§Ù";
$net2ftp_messages["Owner"] = "Ø§ÙÙØ§ÙÙ";
$net2ftp_messages["Group"] = "Ø§ÙÙØ¬ÙÙØ¹Ø©";
$net2ftp_messages["Everyone"] = "Ø£Ù Ø´Ø®Øµ";
$net2ftp_messages["To set all permissions to the same values, enter those permissions and click on the button \"Set all permissions\""] = "ÙØªØ¹ÙÙÙ Ø¬ÙÙØ¹ Ø§ÙØµÙØ§Ø­ÙØ§Øª Ø¥ÙÙ ÙÙØ³ Ø§ÙÙÙÙØ© , Ø­Ø¯Ø¯ Ø§ÙØµÙØ§Ø­ÙØ§Øª Ø«Ù Ø§Ø¶ØºØ· Ø²Ø± \"ØªØ¹ÙÙÙ Ø¬ÙÙØ¹ Ø§ÙØµÙØ§Ø­ÙØ§Øª\"";
$net2ftp_messages["Set the permissions of directory <b>%1\$s</b> to: "] = "ØªØ¹ÙÙÙ ØµÙØ§Ø­ÙØ§Øª Ø§ÙÙØ¬ÙØ¯ <b>%1\$s</b> Ø¥ÙÙ Â» ";
$net2ftp_messages["Set the permissions of file <b>%1\$s</b> to: "] = "ØªØ¹ÙÙÙ ØµÙØ§Ø­ÙØ§Øª Ø§ÙÙÙÙ <b>%1\$s</b> Ø¥ÙÙ Â» ";
$net2ftp_messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "ØªØ¹ÙÙÙ ØµÙØ§Ø­ÙØ§Øª symlink <b>%1\$s</b> Ø¥ÙÙ Â» ";
$net2ftp_messages["Chmod value"] = "ÙÙÙØ© Ø§ÙØªØµØ±ÙØ­";
$net2ftp_messages["Chmod also the subdirectories within this directory"] = "ØªØ·Ø¨ÙÙ Ø§ÙØªØµØ±ÙØ­ Ø¹ÙÙ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ø§ÙÙØ±Ø¹ÙØ© ÙÙ ÙØ°Ø§ Ø§ÙÙØ¬ÙØ¯";
$net2ftp_messages["Chmod also the files within this directory"] = "ØªØ·Ø¨ÙÙ Ø§ÙØªØµØ±ÙØ­ Ø¹ÙÙ Ø§ÙÙÙÙØ§Øª Ø¯Ø§Ø®Ù ÙØ°Ø§ Ø§ÙÙØ¬ÙØ¯";
$net2ftp_messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "Ø§ÙØªØµØ±ÙØ­ nr <b>%1\$s</b> Ø®Ø§Ø±Ø¬ ÙØ·Ø§Ù 000-777. ÙØ±Ø¬Ù Ø§ÙÙØ­Ø§ÙÙØ© ÙÙ Ø¬Ø¯ÙØ¯ .";

} // end chmod


// -------------------------------------------------------------------------
// Clear cookies module
// -------------------------------------------------------------------------
// No messages


// -------------------------------------------------------------------------
// Copy/Move/Delete module
if ($net2ftp_globals["state"] == "copymovedelete") {
// -------------------------------------------------------------------------
$net2ftp_messages["Choose a directory"] = "Ø§Ø®ØªØ± Ø¯ÙÙÙ";
$net2ftp_messages["Copy directories and files"] = "ÙØ³Ø® Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Move directories and files"] = "ÙÙÙ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Delete directories and files"] = "Ø­Ø°Ù Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Are you sure you want to delete these directories and files?"] = "ÙÙ Ø§ÙØª ÙØªØ£ÙØ¯ ÙÙ Ø£ÙÙ ØªØ±ÙØ¯ Ø­Ø°Ù ÙØ°Ù Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª Ø";
$net2ftp_messages["All the subdirectories and files of the selected directories will also be deleted!"] = "Ø¬ÙÙØ¹ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ø§ÙÙØ±Ø¹ÙØ© Ù Ø§ÙÙÙÙØ§Øª ÙÙ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ø§ÙÙØ­Ø¯Ø¯Ø© Ø³ÙÙ ØªØ­Ø°Ù !";
$net2ftp_messages["Set all targetdirectories"] = "ØªØ¹ÙÙÙ Ø¬ÙÙØ¹ Ø§ÙØ£Ø¯ÙØ© Ø§ÙÙØ¯Ù";
$net2ftp_messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "ÙØªØ¹ÙÙÙ Ø¯ÙÙÙ ÙØ¯Ù ÙØ´ØªØ±Ù , Ø£Ø¯Ø®Ù Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ¯Ù ÙÙ Ø§ÙØ­ÙÙ Ø§ÙÙØµÙ Ø§ÙØ³Ø§Ø¨Ù Ø«Ù Ø§Ø¶ØºØ· Ø²Ø± \"ØªØ¹ÙÙÙ Ø¬ÙÙØ¹ Ø§ÙØ£Ø¯ÙØ© Ø§ÙÙØ¯Ù\".";
$net2ftp_messages["Note: the target directory must already exist before anything can be copied into it."] = "ÙÙØ§Ø­Ø¸Ø© Â» Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ¯Ù ÙØ¬Ø¨ Ø£Ù ÙÙÙÙ ÙÙØ¬ÙØ¯ Ø£ÙÙØ§Ù .";
$net2ftp_messages["Different target FTP server:"] = "Ø³Ø±ÙØ± FTP Ø§ÙØ¢Ø®Ø± Ø§ÙÙØ¯Ù Â»";
$net2ftp_messages["Username"] = "Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù";
$net2ftp_messages["Password"] = "ÙÙÙØ© Ø§ÙÙØ±ÙØ±";
$net2ftp_messages["Leave empty if you want to copy the files to the same FTP server."] = "Ø§ØªØ±ÙÙ ÙØ§Ø±Øº Ø¥Ø°Ø§ ÙÙØª ØªØ±ÙØ¯ ÙØ³Ø® Ø§ÙÙÙÙØ§Øª Ø¥ÙÙ ÙÙØ³ Ø³Ø±ÙØ± FTP .";
$net2ftp_messages["If you want to copy the files to another FTP server, enter your login data."] = "Ø¥Ø°Ø§ ÙÙØª ØªØ±ÙØ¯ ÙØ³Ø® Ø§ÙÙÙÙØ§Øª Ø¥ÙÙ Ø³Ø±ÙØ± FTP Ø¢Ø®Ø± , Ø£Ø¯Ø®Ù Ø¨ÙØ§ÙØ§Øª Ø§ÙØ¯Ø®ÙÙ .";
$net2ftp_messages["Leave empty if you want to move the files to the same FTP server."] = "Ø§ØªØ±ÙÙ ÙØ§Ø±Øº Ø¥Ø°Ø§ ÙÙØª ØªØ±ÙØ¯ ÙÙÙ Ø§ÙÙÙÙØ§Øª Ø¥ÙÙ ÙÙØ³ Ø³Ø±ÙØ± FTP .";
$net2ftp_messages["If you want to move the files to another FTP server, enter your login data."] = "Ø¥Ø°Ø§ ÙÙØª ØªØ±ÙØ¯ ÙÙÙ Ø§ÙÙÙÙØ§Øª Ø¥ÙÙ Ø³Ø±ÙØ± FTP Ø¢Ø®Ø± , Ø£Ø¯Ø®Ù Ø¨ÙØ§ÙØ§Øª Ø§ÙØ¯Ø®ÙÙ .";
$net2ftp_messages["Copy directory <b>%1\$s</b> to:"] = "ÙØ³Ø® Ø§ÙÙØ¬ÙØ¯ <b>%1\$s</b> Ø¥ÙÙ Â»";
$net2ftp_messages["Move directory <b>%1\$s</b> to:"] = "ÙÙÙ Ø§ÙÙØ¬ÙØ¯ <b>%1\$s</b> Ø¥ÙÙ Â»";
$net2ftp_messages["Directory <b>%1\$s</b>"] = "Ø§ÙÙØ¬ÙØ¯ <b>%1\$s</b>";
$net2ftp_messages["Copy file <b>%1\$s</b> to:"] = "ÙØ³Ø® Ø§ÙÙÙÙ <b>%1\$s</b> Ø¥ÙÙ Â»";
$net2ftp_messages["Move file <b>%1\$s</b> to:"] = "ÙÙÙ Ø§ÙÙÙÙ <b>%1\$s</b> Ø¥ÙÙ Â»";
$net2ftp_messages["File <b>%1\$s</b>"] = "Ø§ÙÙÙÙ <b>%1\$s</b>";
$net2ftp_messages["Copy symlink <b>%1\$s</b> to:"] = "ÙØ³Ø® symlink <b>%1\$s</b> Ø¥ÙÙ Â»";
$net2ftp_messages["Move symlink <b>%1\$s</b> to:"] = "ÙÙÙ symlink <b>%1\$s</b> Ø¥ÙÙ Â»";
$net2ftp_messages["Symlink <b>%1\$s</b>"] = "Symlink <b>%1\$s</b>";
$net2ftp_messages["Target directory:"] = "Ø§ÙÙØ¬ÙØ¯ Ø§ÙÙØ¯Ù Â»";
$net2ftp_messages["Target name:"] = "Ø§Ø³Ù Ø§ÙÙØ¯Ù Â»";
$net2ftp_messages["Processing the entries:"] = "ÙØ¹Ø§ÙØ¬Ø© Ø§ÙØ¹ÙØ§ØµØ± Â»";

} // end copymovedelete


// -------------------------------------------------------------------------
// Download file module
// -------------------------------------------------------------------------
// No messages


// -------------------------------------------------------------------------
// EasyWebsite module
if ($net2ftp_globals["state"] == "easyWebsite") {
// -------------------------------------------------------------------------
$net2ftp_messages["Create a website in 4 easy steps"] = "Ø¥ÙØ´Ø§Ø¡ ÙÙÙØ¹ ÙÙ 4 Ø®Ø·ÙØ§Øª Ø³ÙÙØ©";
$net2ftp_messages["Template overview"] = "Ø®ÙØ§ØµØ© Ø§ÙÙØ§ÙØ¨";
$net2ftp_messages["Template details"] = "ØªÙØ§ØµÙÙ Ø§ÙÙØ§ÙØ¨";
$net2ftp_messages["Files are copied"] = "ØªÙ ÙØ³Ø® Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Edit your pages"] = "ØªØ­Ø±ÙØ± ØµÙØ­Ø§ØªÙ";

// Screen 1 - printTemplateOverview
$net2ftp_messages["Click on the image to view the details of a template."] = "Ø§Ø¶ØºØ· Ø¹ÙÙ Ø§ÙØµÙØ±Ø© ÙØ¹Ø±Ø¶ ØªÙØ§ØµÙÙ Ø§ÙÙØ§ÙØ¨ .";
$net2ftp_messages["Back to the Browse screen"] = "Ø§ÙØ¹ÙØ¯Ø© Ø¥ÙÙ Ø´Ø§Ø´Ø© Ø§ÙÙØ³ØªØ¹Ø±Ø¶";
$net2ftp_messages["Template"] = "Ø§ÙÙØ§ÙØ¨";
$net2ftp_messages["Copyright"] = "Ø­ÙÙÙ Ø§ÙÙØ´Ø±";
$net2ftp_messages["Click on the image to view the details of this template"] = "Ø§Ø¶ØºØ· Ø¹ÙÙ Ø§ÙØµÙØ±Ø© ÙØ¹Ø±Ø¶ ØªÙØ§ØµÙÙ Ø§ÙÙØ§ÙØ¨ .";

// Screen 2 - printTemplateDetails
$net2ftp_messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "Ø³ÙØªÙ ÙØ³Ø® ÙÙÙØ§Øª Ø§ÙÙØ§ÙØ¨ Ø¥ÙÙ Ø³Ø±ÙØ±Ù FTP .Ø§ÙÙÙÙØ§Øª Ø§ÙØªÙ ØªØ­ÙÙ ÙÙØ³ Ø§ÙØ§Ø³Ù Ø³ÙØªÙ Ø§ÙÙØªØ§Ø¨Ø© ÙÙÙÙØ§ . ÙÙ ØªØ±ØºØ¨ Ø¨Ø§ÙÙØªØ§Ø¨Ø¹Ø© Ø";
$net2ftp_messages["Install template to directory: "] = "ØªØ±ÙÙØ¨ Ø§ÙÙØ§ÙØ¨ ÙÙ Ø§ÙØ¯ÙÙÙ Â» ";
$net2ftp_messages["Install"] = "Ø§ÙØªØ±ÙÙØ¨";
$net2ftp_messages["Size"] = "Ø§ÙØ­Ø¬Ù";
$net2ftp_messages["Preview page"] = "ÙØ¹Ø§ÙÙØ© Ø§ÙØµÙØ­Ø©";
$net2ftp_messages["opens in a new window"] = "ÙÙ ÙÙ ÙØ§ÙØ°Ø© Ø¬Ø¯ÙØ¯Ø©";

// Screen 3
$net2ftp_messages["Please wait while the template files are being transferred to your server: "] = "ÙØ±Ø¬Ù Ø§ÙØ§ÙØªØ¸Ø§Ø± Ø¨ÙÙÙØ§ ÙØªÙ ÙØ³Ø® ÙÙÙØ§Øª Ø§ÙÙØ§ÙØ¨ Ø¥ÙÙ Ø³Ø±ÙØ±Ù Â» ";
$net2ftp_messages["Done."] = "ØªÙÙ .";
$net2ftp_messages["Continue"] = "Ø§ÙÙØªØ§Ø¨Ø¹Ø©";

// Screen 4 - printEasyAdminPanel
$net2ftp_messages["Edit page"] = "ØªØ­Ø±ÙØ± Ø§ÙØµÙØ­Ø©";
$net2ftp_messages["Browse the FTP server"] = "Ø§Ø³ØªØ¹Ø±Ø§Ø¶ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Add this link to your favorites to return to this page later on!"] = "Ø¥Ø¶Ø§ÙØ© ÙØ°Ø§ Ø§ÙØ±Ø§Ø¨Ø· Ø¥ÙÙ ÙÙØ¶ÙØªÙ ÙÙØ¹ÙØ¯Ø© Ø¥ÙÙ ÙØ°Ù Ø§ÙØµÙØ®Ø© ÙÙÙØ§ Ø¨Ø¹Ø¯ !";
$net2ftp_messages["Edit website at %1\$s"] = "ØªØ­Ø±ÙØ± ÙÙÙØ¹ Ø§ÙÙÙØ¨ ÙÙ %1\$s";
$net2ftp_messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer Â» Ø§Ø¶ØºØ· Ø¨Ø§ÙØ²Ø± Ø§ÙØ£ÙÙÙ ÙÙÙ Ø§ÙØ±Ø§Ø¨Ø· Ù Ø§Ø®ØªØ± \"Ø¥Ø¶Ø§ÙØ© Ø¥ÙÙ Ø§ÙÙÙØ¶ÙØ©...\"";
$net2ftp_messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox Â» Ø§Ø¶ØºØ· Ø¨Ø§ÙØ²Ø± Ø§ÙØ£ÙÙÙ ÙÙÙ Ø§ÙØ±Ø§Ø¨Ø· Ù Ø§Ø®ØªØ± \"Ø£Ø¶Ù ÙØ°Ø§ Ø§ÙØ±Ø§Ø¨Ø· Ø¥ÙÙ Ø§ÙÙÙØ¶ÙØ©...\"";

// ftp_copy_local2ftp
$net2ftp_messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "ØªØ­Ø°ÙØ± Â» ØªØ¹Ø°Ø± Ø¥ÙØ´Ø§Ø¡ Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ±Ø¹Ù <b>%1\$s</b> . Ø±Ø¨ÙØ§ ÙÙÙÙ ÙÙØ¬ÙØ¯ ÙÙ ÙØ¨Ù . Ø§ÙÙØªØ§Ø¨Ø¹Ø©...";
$net2ftp_messages["Created target subdirectory <b>%1\$s</b>"] = "Ø¥ÙØ´Ø§Ø¡ Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ±Ø¹Ù Ø§ÙÙØ¯Ù <b>%1\$s</b>";
$net2ftp_messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "ØªØ­Ø°ÙØ± Â» ØªØ¹Ø°Ø± ÙØ³Ø® Ø§ÙÙÙÙ <b>%1\$s</b> . Ø§ÙÙØªØ§Ø¨Ø¹Ø© ...";
$net2ftp_messages["Copied file <b>%1\$s</b>"] = "ØªÙ ÙØ³Ø® Ø§ÙÙÙÙ <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// Edit module
if ($net2ftp_globals["state"] == "edit") {
// -------------------------------------------------------------------------

// /modules/edit/edit.inc.php
$net2ftp_messages["Unable to open the template file"] = "ØªØ¹Ø°Ø± ÙØªØ­ ÙÙÙ Ø§ÙÙØ§ÙØ¨";
$net2ftp_messages["Unable to read the template file"] = "ØªØ¹Ø°Ø± ÙØ±Ø§Ø¡Ø© ÙÙÙ Ø§ÙÙØ§ÙØ¨";
$net2ftp_messages["Please specify a filename"] = "ÙØ±Ø¬Ù ØªØ­Ø¯ÙØ¯ Ø§Ø³Ù Ø§ÙÙÙÙ";
$net2ftp_messages["Status: This file has not yet been saved"] = "Ø§ÙØ­Ø§ÙØ© Â» ÙÙ ÙØªÙ Ø­ÙØ¸ ÙØ°Ø§ Ø§ÙÙÙÙ Ø¨Ø¹Ø¯";
$net2ftp_messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Ø§ÙØ­Ø§ÙØ© Â» ØªÙ Ø§ÙØ­ÙØ¸ ÙÙ <b>%1\$s</b> Ø¨Ø§Ø³ØªØ®Ø¯Ø§Ù Ø§ÙÙÙØ· %2\$s";
$net2ftp_messages["Status: <b>This file could not be saved</b>"] = "Ø§ÙØ­Ø§ÙØ© Â» <b>ØªØ¹Ø°Ø± Ø­ÙØ¸ ÙØ°Ø§ Ø§ÙÙÙÙ</b>";
$net2ftp_messages["Not yet saved"] = "Not yet saved";
$net2ftp_messages["Could not be saved"] = "Could not be saved";
$net2ftp_messages["Saved at %1\$s"] = "Saved at %1\$s";

// /skins/[skin]/edit.template.php
$net2ftp_messages["Directory: "] = "Ø§ÙÙØ¬ÙØ¯ Â» ";
$net2ftp_messages["File: "] = "Ø§ÙÙÙÙ Â» ";
$net2ftp_messages["New file name: "] = "Ø§Ø³Ù Ø§ÙÙÙÙ Ø§ÙØ¬Ø¯ÙØ¯ Â» ";
$net2ftp_messages["Character encoding: "] = "ØµÙØºØ© Ø§ÙØªØ±ÙÙØ² Â» ";
$net2ftp_messages["Note: changing the textarea type will save the changes"] = "ÙÙØ§Ø­Ø¸Ø© Â» ØªØºÙÙØ± ÙÙØ¹ ØµÙØ¯ÙÙ Ø§ÙÙØµ Ø³ÙÙ ÙØ­ÙØ¸ ÙØ°Ù Ø§ÙØªØ¹Ø¯ÙÙØ§Øª";
$net2ftp_messages["Copy up"] = "ÙØ³Ø® Ø¥ÙÙ";
$net2ftp_messages["Copy down"] = "ÙØ³Ø® ÙÙ";

} // end if edit


// -------------------------------------------------------------------------
// Find string module
if ($net2ftp_globals["state"] == "findstring") {
// -------------------------------------------------------------------------

// /modules/findstring/findstring.inc.php 
$net2ftp_messages["Search directories and files"] = "Ø¨Ø­Ø« ÙÙ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Search again"] = "Ø¨Ø­Ø« Ø¬Ø¯ÙØ¯";
$net2ftp_messages["Search results"] = "ÙØªØ§Ø¦Ø¬ Ø§ÙØ¨Ø­Ø«";
$net2ftp_messages["Please enter a valid search word or phrase."] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù ÙÙÙØ© Ø£Ù ØªØ¹Ø¨ÙØ± ÙÙØ¨ÙÙ ÙÙØ¨Ø­Ø« .";
$net2ftp_messages["Please enter a valid filename."] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù Ø§Ø³Ù ÙÙÙ ÙÙØ¨ÙÙ .";
$net2ftp_messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù Ø­Ø¬Ù ÙÙÙ ÙÙØ¨ÙÙ ÙÙ ØµÙØ¯ÙÙ Ø§ÙÙØµ \"ÙÙ\" , ÙØ«Ø§Ù 0.";
$net2ftp_messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù Ø­Ø¬Ù ÙÙÙ ÙÙØ¨ÙÙ ÙÙ ØµÙØ¯ÙÙ Ø§ÙÙØµ \"Ø¥ÙÙ\" , ÙØ«Ø§Ù 500000.";
$net2ftp_messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù ØªØ§Ø±ÙØ® ÙÙØ¨ÙÙ ÙÙ Ø§ÙØ­ÙÙ \"ÙÙ\" Ø¨ØªÙØ³ÙÙ Y-m-d .";
$net2ftp_messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù ØªØ§Ø±ÙØ® ÙÙØ¨ÙÙ ÙÙ Ø§ÙØ­ÙÙ \"Ø¥ÙÙ\" Ø¨ØªÙØ³ÙÙ Y-m-d .";
$net2ftp_messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "ÙÙ ÙØªÙ Ø§ÙØ¹Ø«ÙØ± Ø¹ÙÙ Ø§ÙÙÙÙØ© <b>%1\$s</b> ÙÙ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª Ø§ÙÙØ­Ø¯Ø¯Ø© .";
$net2ftp_messages["The word <b>%1\$s</b> was found in the following files:"] = "ØªÙ Ø§ÙØ¹Ø«ÙØ± Ø¹ÙÙ Ø§ÙÙÙÙØ© <b>%1\$s</b> ÙÙ Ø§ÙÙÙÙØ§Øª Ø§ÙØªØ§ÙÙØ© Â»";

// /skins/[skin]/findstring1.template.php
$net2ftp_messages["Search for a word or phrase"] = "Ø¨Ø­Ø« Ø¹Ù ÙÙÙØ© Ø£Ù ØªØ¹Ø¨ÙØ±";
$net2ftp_messages["Case sensitive search"] = "Ø¨Ø­Ø« ÙØ·Ø§Ø¨Ù ÙØ­Ø§ÙØ© Ø§ÙØ£Ø­Ø±Ù";
$net2ftp_messages["Restrict the search to:"] = "Ø§ÙØªØµØ§Ø± Ø§ÙØ¨Ø­Ø« Ø¹ÙÙ Â»";
$net2ftp_messages["files with a filename like"] = "Ø§ÙÙÙÙØ§Øª Ø°Ø§Øª Ø§Ø³Ù Ø§ÙÙÙÙ ÙÙØ§Ø«Ù";
$net2ftp_messages["(wildcard character is *)"] = "(ÙØ­Ø±Ù ØªØ¹ÙÙÙ Ø§ÙØ¨Ø­Ø« ÙÙ *)";
$net2ftp_messages["files with a size"] = "Ø§ÙÙÙÙØ§Øª Ø°Ø§Øª Ø§ÙØ­Ø¬Ù";
$net2ftp_messages["files which were last modified"] = "Ø§ÙÙÙÙØ§Øª Ø°Ø§Øª Ø¢Ø®Ø± ØªØ¹Ø¯ÙÙ ÙØ§Ù";
$net2ftp_messages["from"] = "ÙÙ";
$net2ftp_messages["to"] = "Ø¥ÙÙ";

$net2ftp_messages["Directory"] = "Ø§ÙØ¯ÙÙÙ";
$net2ftp_messages["File"] = "ÙÙÙ";
$net2ftp_messages["Line"] = "Ø§ÙØ³Ø·Ø±";
$net2ftp_messages["Action"] = "Ø§ÙØ¥Ø¬Ø±Ø§Ø¡";
$net2ftp_messages["View"] = "Ø¹Ø±Ø¶";
$net2ftp_messages["Edit"] = "ØªØ­Ø±ÙØ±";
$net2ftp_messages["View the highlighted source code of file %1\$s"] = "Ø¹Ø±Ø¶ ÙÙØ¯ Ø§ÙÙØµØ¯Ø± Ø§ÙÙÙÙØ² ÙÙÙÙÙ %1\$s";
$net2ftp_messages["Edit the source code of file %1\$s"] = "ØªØ­Ø±ÙØ± ÙÙØ¯ Ø§ÙÙØµØ¯Ø± ÙÙÙÙÙ %1\$s";

} // end findstring


// -------------------------------------------------------------------------
// Help module
// -------------------------------------------------------------------------
// No messages yet


// -------------------------------------------------------------------------
// Install size module
if ($net2ftp_globals["state"] == "install") {
// -------------------------------------------------------------------------

// /modules/install/install.inc.php
$net2ftp_messages["Install software packages"] = "ØªØ«Ø¨ÙØª Ø­Ø²ÙØ© Ø§ÙØ¨Ø±ÙØ§ÙØ¬";
$net2ftp_messages["Unable to open the template file"] = "ØªØ¹Ø°Ø± ÙØªØ­ ÙÙÙ Ø§ÙÙØ§ÙØ¨";
$net2ftp_messages["Unable to read the template file"] = "ØªØ¹Ø°Ø± ÙØ±Ø§Ø¡Ø© ÙÙÙ Ø§ÙÙØ§ÙØ¨";
$net2ftp_messages["Unable to get the list of packages"] = "ØªØ¹Ø°Ø± Ø¬ÙØ¨ ÙØ§Ø¦ÙØ© Ø§ÙØ­Ø²ÙØ©";

// /skins/blue/install1.template.php
$net2ftp_messages["The net2ftp installer script has been copied to the FTP server."] = "ØªÙ ÙØ³Ø® ÙØ¹Ø§ÙØ¬ ØªØ±ÙÙØ¨ net2ftp Ø¥ÙÙ Ø³Ø±ÙØ± FTP .";
$net2ftp_messages["This script runs on your web server and requires PHP to be installed."] = "ÙØ°Ø§ Ø§ÙÙØ¹Ø§ÙØ¬ ÙØ¹ÙÙ Ø¹ÙÙ Ø³Ø±ÙØ± ÙÙÙØ¹ Ù ÙØ­ØªØ§Ø¬ Ø¥ÙÙ PHP ÙÙØªÙ ØªØ±ÙÙØ¨Ù .";
$net2ftp_messages["In order to run it, click on the link below."] = "ÙØªØ´ØºÙÙÙ Ø Ø§Ø¶ØºØ· Ø§ÙØ±Ø§Ø¨Ø· Ø§ÙØªØ§ÙÙ .";
$net2ftp_messages["net2ftp has tried to determine the directory mapping between the FTP server and the web server."] = "Ø­Ø§ÙÙ net2ftp Ø§ÙÙÙØ§Ø±ÙØ© Ø¨ÙÙ Ø³Ø±ÙØ± FTP Ù Ø³Ø±ÙØ±Ù ÙÙÙØ¹Ù .";
$net2ftp_messages["Should this link not be correct, enter the URL manually in your web browser."] = "Ø±Ø¨ÙØ§ ÙØ§ ÙÙÙÙ ÙØ°Ø§ Ø§ÙØ±Ø§Ø¨Ø· ØµØ­ÙØ­ Ø Ø£Ø¯Ø®Ù Ø§ÙØ±Ø§Ø¨Ø· URL ÙÙ ÙØ³ØªØ¹Ø±Ø¶Ù ÙØ¯ÙÙØ§Ù .";

} // end install


// -------------------------------------------------------------------------
// Java upload module
if ($net2ftp_globals["state"] == "jupload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Upload directories and files using a Java applet"] = "Ø±ÙØ¹ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª Ø¨ÙØ§Ø³Ø·Ø© Java applet";
$net2ftp_messages["Your browser does not support applets, or you have disabled applets in your browser settings."] = "Your browser does not support applets, or you have disabled applets in your browser settings.";
$net2ftp_messages["To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now."] = "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.";
$net2ftp_messages["The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment)."] = "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).";
$net2ftp_messages["Alternatively, use net2ftp's normal upload or upload-and-unzip functionality."] = "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.";

} // end jupload



// -------------------------------------------------------------------------
// Login module
if ($net2ftp_globals["state"] == "login") {
// -------------------------------------------------------------------------
$net2ftp_messages["Login!"] = "ØªØ³Ø¬ÙÙ Ø§ÙØ¯Ø®ÙÙ !";
$net2ftp_messages["Once you are logged in, you will be able to:"] = "Once you are logged in, you will be able to:";
$net2ftp_messages["Navigate the FTP server"] = "Ø§Ø³ØªØ¹Ø±Ø§Ø¶ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Once you have logged in, you can browse from directory to directory and see all the subdirectories and files."] = "Ø§ÙØªÙÙÙ ÙÙ ÙØ¬ÙØ¯ Ø¥ÙÙ ÙØ¬ÙØ¯ Ù Ø§Ø³ØªØ¹Ø±Ø§Ø¶ Ø¬ÙÙØ¹ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ø§ÙÙØ±Ø¹ÙØ© Ù Ø§ÙÙÙÙØ§Øª .";
$net2ftp_messages["Upload files"] = "Ø±ÙØ¹ Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["There are 3 different ways to upload files: the standard upload form, the upload-and-unzip functionality, and the Java Applet."] = "ÙÙØ¬Ø¯ 3 Ø·Ø±Ù ÙØ®ØªÙÙØ© ÙØ±ÙØ¹ Ø§ÙÙÙÙØ§Øª Â» 1 - Ø§ÙØ·Ø±ÙÙØ© Ø§ÙØ¹Ø§Ø¯ÙØ© Ø§ÙÙØ¹Ø±ÙÙØ© . 2 - Ø·Ø±ÙÙØ© Ø±ÙØ¹ ÙÙÙ ÙØ¶ØºÙØ· Ø«Ù ÙÙ Ø§ÙØ¶ØºØ· ØªÙÙØ§Ø¦ÙØ§Ù . 3 - Ø·Ø±ÙÙØ© Ø§ÙØ¬Ø§ÙØ§ Ø£Ø¨ÙÙØª .";
$net2ftp_messages["Download files"] = "ØªØ­ÙÙÙ Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Click on a filename to quickly download one file.<br />Select multiple files and click on Download; the selected files will be downloaded in a zip archive."] = "Ø§Ø¶ØºØ· Ø¹ÙÙ Ø§Ø³Ù Ø§ÙÙÙÙ ÙÙØªØ­ÙÙÙ Ø§ÙÙØ±Ø¯Ù Ø§ÙØ³Ø±ÙØ¹ .<br />Ø­Ø¯Ø¯ ÙÙÙØ§Øª ÙØªØ¹Ø¯Ø¯Ø© Ø«Ù Ø§Ø¶ØºØ· Ø¹ÙÙ ØªØ­ÙÙÙ , ÙØªÙ ØªØ­ÙÙÙ Ø§ÙÙÙÙØ§Øª Ø§ÙÙØ­Ø¯Ø¯Ø© Ø¶ÙÙ ÙÙÙ ÙØ¶ØºÙØ· zip .";
$net2ftp_messages["Zip files"] = "Ø¶ØºØ· Zip Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["... and save the zip archive on the FTP server, or email it to someone."] = "... Ù Ø­ÙØ¸ Ø§ÙÙÙÙ zip Ø¹ÙÙ Ø³Ø±ÙØ± FTP , Ø£Ù Ø¥Ø±Ø³Ø§ÙÙ Ø¨ÙØ§Ø³Ø·Ø© Ø§ÙØ¨Ø±ÙØ¯ Ø§ÙØ§ÙÙØªØ±ÙÙÙ .";
$net2ftp_messages["Unzip files"] = "Ø§Ø³ØªØ®Ø±Ø§Ø¬ Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Different formats are supported: .zip, .tar, .tgz and .gz."] = "Ø§ÙØµÙØº Ø§ÙÙØ¯Ø¹ÙÙØ© Â» .zip, .tar, .tgz Ù .gz.";
$net2ftp_messages["Install software"] = "ØªØ±ÙÙØ¨ Ø§ÙØ¨Ø±ÙØ§ÙØ¬";
$net2ftp_messages["Choose from a list of popular applications (PHP required)."] = "Ø§Ø®ØªØ± ÙÙ ÙØ§Ø¦ÙØ© Ø§ÙØªØ·Ø¨ÙÙØ§Øª Ø§ÙØ´Ø§Ø¦Ø¹Ø© ( ØªØªØ·ÙØ¨ PHP ) .";
$net2ftp_messages["Copy, move and delete"] = "ÙØ³Ø® , ÙÙÙ , Ù Ø­Ø°Ù";
$net2ftp_messages["Directories are handled recursively, meaning that their content (subdirectories and files) will also be copied, moved or deleted."] = "Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù ÙØ­ØªÙÙØ§ØªÙØ§ (Ø§ÙÙØ¬ÙØ¯Ø§Øª Ø§ÙÙØ±Ø¹ÙØ© Ù Ø§ÙÙÙÙØ§Øª) .";
$net2ftp_messages["Copy or move to a 2nd FTP server"] = "ÙØ³Ø® Ø£Ù ÙÙÙ ÙÙ Ù Ø¥ÙÙ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Handy to import files to your FTP server, or to export files from your FTP server to another FTP server."] = "Ø§Ø³ØªÙØ±Ø§Ø¯ Ø§ÙÙÙÙØ§Øª Ø¥ÙÙ Ø³Ø±ÙØ± FTP , Ø£Ù ØªØµØ¯ÙØ± Ø§ÙÙÙÙØ§Øª ÙÙ Ø³Ø±ÙØ±Ù Ø¥ÙÙ Ø³Ø±ÙØ± FTP Ø¢Ø®Ø± .";
$net2ftp_messages["Rename and chmod"] = "Ø¥Ø¹Ø§Ø¯Ø© Ø§ÙØªØ³ÙÙØ© Ù Ø§ÙØªØµØ§Ø±ÙØ­";
$net2ftp_messages["Chmod handles directories recursively."] = "ØªØºÙØ± Ø£Ø³ÙØ§Ø¡ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª Ù ØªØºÙÙØ± Ø§ÙØªØµØ§Ø±ÙØ­ .";
$net2ftp_messages["View code with syntax highlighting"] = "Ø¹Ø±Ø¶ Ø§ÙÙÙØ¯ ÙØ¹ ØªÙÙÙØ² Ø§ÙÙØµØ¯Ø±";
$net2ftp_messages["PHP functions are linked to the documentation on php.net."] = "Ø§Ø±ØªØ¨Ø§Ø·Ø§Øª ÙÙØ«Ø§Ø¦Ù ÙØ¸Ø§Ø¦Ù PHP Ø¹ÙÙ php.net.";
$net2ftp_messages["Plain text editor"] = "ÙØ­Ø±Ø± ÙØµÙØµ Ø¹Ø§Ø¯ÙØ©";
$net2ftp_messages["Edit text right from your browser; every time you save the changes the new file is transferred to the FTP server."] = "ØªØ­Ø±ÙØ± Ø§ÙÙØµ Ø¨ÙØ§Ø³Ø·Ø© Ø§ÙÙØ³ØªØ¹Ø±Ø¶ .";
$net2ftp_messages["HTML editors"] = "ÙØ­Ø±Ø± HTML";
$net2ftp_messages["Edit HTML a What-You-See-Is-What-You-Get (WYSIWYG) form; there are 2 different editors to choose from."] = "ÙØ­Ø±Ø± HTML ÙØªÙØ¯Ù (WYSIWYG) , ÙØ§ ØªØ´Ø§ÙØ¯Ù ØªØ­ØµÙ Ø¹ÙÙÙ , ÙÙÙÙÙ Ø§ÙØ§Ø®ØªÙØ§Ø± Ø¨ÙÙ ÙØ­Ø±Ø±ÙÙ .";
$net2ftp_messages["Code editor"] = "ÙØ­Ø±Ø± Ø§ÙÙÙØ¯";
$net2ftp_messages["Edit HTML and PHP in an editor with syntax highlighting."] = "ØªØ­Ø±ÙØ± ÙÙØ¯ HTML Ù PHP ÙØ¹ Ø§ÙØªÙÙÙØ² .";
$net2ftp_messages["Search for words or phrases"] = "Ø¨Ø­Ø« Ø¹Ù ÙÙÙØ§Øª Ø£Ù ØªØ¹Ø¨ÙØ± Ø¨Ø±ÙØ¬Ù";
$net2ftp_messages["Filter out files based on the filename, last modification time and filesize."] = "ÙÙØªØ±Ø© Ø¹ÙÙ Ø£Ø³Ø§Ø³ Ø§Ø³Ù Ø§ÙÙÙÙ , ÙÙØª Ø¢Ø®Ø± ØªØ­Ø±ÙØ± Ù Ø­Ø¬Ù Ø§ÙÙÙÙ .";
$net2ftp_messages["Calculate size"] = "Ø­Ø³Ø§Ø¨ Ø§ÙØ­Ø¬Ù";
$net2ftp_messages["Calculate the size of directories and files."] = "Ø­Ø³Ø§Ø¨ Ø­Ø¬Ù Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª .";

$net2ftp_messages["FTP server"] = "Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Example"] = "ÙØ«Ø§Ù";
$net2ftp_messages["Port"] = "Ø§ÙÙÙÙØ°";
$net2ftp_messages["Protocol"] = "Protocol";
$net2ftp_messages["Username"] = "Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù";
$net2ftp_messages["Password"] = "ÙÙÙØ© Ø§ÙÙØ±ÙØ±";
$net2ftp_messages["Anonymous"] = "Anonymous";
$net2ftp_messages["Passive mode"] = "ÙÙØ· Passive Ø§ÙØ®ÙÙÙ";
$net2ftp_messages["Initial directory"] = "Ø§ÙØ¯ÙÙÙ Ø§ÙØ£ÙÙÙ";
$net2ftp_messages["Language"] = "Ø§ÙÙØºØ©";
$net2ftp_messages["Skin"] = "Ø§ÙØ´ÙÙ";
$net2ftp_messages["FTP mode"] = "ÙÙØ· FTP";
$net2ftp_messages["Automatic"] = "ØªÙÙØ§Ø¦Ù";
$net2ftp_messages["Login"] = "ØªØ³Ø¬ÙÙ Ø§ÙØ¯Ø®ÙÙ";
$net2ftp_messages["Clear cookies"] = "ÙØ³Ø­ Ø§ÙÙÙÙÙØ²";
$net2ftp_messages["Admin"] = "Ø§ÙØ¥Ø¯Ø§Ø±Ø©";
$net2ftp_messages["Please enter an FTP server."] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù Ø³Ø±ÙØ± FTP.";
$net2ftp_messages["Please enter a username."] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù .";
$net2ftp_messages["Please enter a password."] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± .";

} // end login


// -------------------------------------------------------------------------
// Login module
if ($net2ftp_globals["state"] == "login_small") {
// -------------------------------------------------------------------------

$net2ftp_messages["Please enter your Administrator username and password."] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± Ø§ÙØ®Ø§ØµØ© Ø¨Ø§ÙØ¥Ø¯Ø§Ø±Ø© .";
$net2ftp_messages["Please enter your username and password for FTP server <b>%1\$s</b>."] = "ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± ÙØ³Ø±ÙØ± FTP <b>%1\$s</b> .";
$net2ftp_messages["Username"] = "Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù";
$net2ftp_messages["Your session has expired; please enter your password for FTP server <b>%1\$s</b> to continue."] = "Ø§ÙØªÙØª ÙØ¯Ø© Ø¬ÙØ³Ø© Ø§ÙØ¹ÙÙ Ø ÙØ±Ø¬Ù Ø¥Ø¹Ø§Ø¯Ø© ÙØªØ§Ø¨Ø© Ø§Ø³Ù Ø§ÙÙØ³ØªØ®Ø¯Ù Ù ÙÙÙØ© Ø§ÙÙØ±ÙØ± ÙØ³Ø±ÙØ± FTP <b>%1\$s</b> ÙÙÙØªØ§Ø¨Ø¹Ø© .";
$net2ftp_messages["Your IP address has changed; please enter your password for FTP server <b>%1\$s</b> to continue."] = "ØªÙ ØªØºÙÙØ± Ø¹ÙÙØ§Ù IP Ø§ÙØ®Ø§Øµ Ø¨Ù Ø ÙØ±Ø¬Ù Ø¥Ø¹Ø§Ø¯Ø© ÙØªØ§Ø¨Ø© ÙÙÙØ© Ø§ÙÙØ±ÙØ± ÙØ³Ø±ÙØ± FTP <b>%1\$s</b> ÙÙÙØªØ¹Ø§Ø¨Ø¹Ø© .";
$net2ftp_messages["Password"] = "ÙÙÙØ© Ø§ÙÙØ±ÙØ±";
$net2ftp_messages["Login"] = "ØªØ³Ø¬ÙÙ Ø§ÙØ¯Ø®ÙÙ";
$net2ftp_messages["Continue"] = "Ø§ÙÙØªØ§Ø¨Ø¹Ø©";

} // end login_small


// -------------------------------------------------------------------------
// Logout module
if ($net2ftp_globals["state"] == "logout") {
// -------------------------------------------------------------------------

// logout.inc.php
$net2ftp_messages["Login page"] = "ØµÙØ­Ø© Ø§ÙØ¯Ø®ÙÙ";

// logout.template.php
$net2ftp_messages["You have logged out from the FTP server. To log back in, <a href=\"%1\$s\" title=\"Login page (accesskey l)\" accesskey=\"l\">follow this link</a>."] = "ØªÙ ØªØ³Ø¬ÙÙ Ø®Ø±ÙØ¬Ù ÙÙ Ø³Ø±ÙØ± FTP . ÙØªØ³Ø¬ÙÙ Ø§ÙØ¯Ø®ÙÙ ÙÙ Ø¬Ø¯ÙØ¯ , <a href=\"%1\$s\" title=\"ØµÙØ­Ø© Ø§ÙØ¯Ø®ÙÙ (accesskey l)\" accesskey=\"l\">Ø§ØªØ¨Ø¹ Ø§ÙØ±Ø§Ø¨Ø· Ø§ÙØªØ§ÙÙ</a>.";
$net2ftp_messages["Note: other users of this computer could click on the browser's Back button and access the FTP server."] = "ÙÙØ§Ø­Ø¸Ø© Â» ÙÙÙÙ ÙØ£Ù ÙØ³ØªØ®Ø¯Ù Ø¢Ø®Ø± ÙÙØ°Ø§ Ø§ÙØ¬ÙØ§Ø² Ø£Ù ÙØ¶ØºØ· Ø²Ø± ÙÙØ®ÙÙ ÙÙ Ø§ÙÙØ³ØªØ¹Ø±Ø¶ Ù Ø§ÙÙØµÙÙ Ø¥ÙÙ Ø³Ø±ÙØ± FTP .";
$net2ftp_messages["To prevent this, you must close all browser windows."] = "ÙÙÙØ¹ Ø­ØµÙÙ Ø°ÙÙ , ÙØªÙØ¬Ø¨ Ø¹ÙÙÙ Ø¥ØºÙØ§Ù Ø¬ÙÙØ¹ ØµÙØ­Ø§Øª Ø§ÙÙØ³ØªØ¹Ø±Ø¶ Ø§ÙØ¢Ù .";
$net2ftp_messages["Close"] = "Ø¥ØºÙØ§Ù";
$net2ftp_messages["Click here to close this window"] = "Ø§Ø¶ØºØ· ÙÙØ§ ÙØ¥ØºÙØ§Ù ÙØ°Ù Ø§ÙÙØ§ÙØ°Ø©";

} // end logout


// -------------------------------------------------------------------------
// New directory module
if ($net2ftp_globals["state"] == "newdir") {
// -------------------------------------------------------------------------
$net2ftp_messages["Create new directories"] = "Ø¥ÙØ´Ø§Ø¡ ÙØ¬ÙØ¯Ø§Øª Ø¬Ø¯ÙØ¯Ø©";
$net2ftp_messages["The new directories will be created in <b>%1\$s</b>."] = "Ø§ÙÙØ¬ÙØ¯Ø§Øª Ø§ÙØ¬Ø¯ÙØ¯Ø© Ø³ÙØªÙ Ø¥ÙØ´Ø§Ø¦ÙØ§ ÙÙ <b>%1\$s</b>.";
$net2ftp_messages["New directory name:"] = "New directory name:";
$net2ftp_messages["Directory <b>%1\$s</b> was successfully created."] = "ØªÙ Ø¥ÙØ´Ø§Ø¡ Ø§ÙÙØ¬ÙØ¯ <b>%1\$s</b> Ø¨ÙØ¬Ø§Ø­ !";
$net2ftp_messages["Directory <b>%1\$s</b> could not be created."] = "ØªØ¹Ø°Ø± Ø¥ÙØ´Ø§Ø¡ Ø§ÙÙØ¬ÙØ¯ <b>%1\$s</b> !";

} // end newdir


// -------------------------------------------------------------------------
// Raw module
if ($net2ftp_globals["state"] == "raw") {
// -------------------------------------------------------------------------

// /modules/raw/raw.inc.php
$net2ftp_messages["Send arbitrary FTP commands"] = "Ø¥Ø±Ø³Ø§Ù Ø£ÙØ± FTP ØªØ­ÙÙÙ";


// /skins/[skin]/raw1.template.php
$net2ftp_messages["List of commands:"] = "ÙØ§Ø¦ÙØ© Ø§ÙØ£ÙØ§ÙØ± Â»";
$net2ftp_messages["FTP server response:"] = "Ø¥Ø¬Ø§Ø¨Ø© Ø³Ø±ÙØ± FTP Â»";

} // end raw


// -------------------------------------------------------------------------
// Rename module
if ($net2ftp_globals["state"] == "rename") {
// -------------------------------------------------------------------------
$net2ftp_messages["Rename directories and files"] = "Ø¥Ø¹Ø§Ø¯Ø© ØªØ³ÙÙØ© Ø§ÙÙØ¬ÙØ¯Ø§Øª Ù Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Old name: "] = "Ø§ÙØ§Ø³Ù Ø§ÙÙØ¯ÙÙ Â» ";
$net2ftp_messages["New name: "] = "Ø§ÙØ§Ø³Ù Ø§ÙØ¬Ø¯ÙØ¯ Â» ";
$net2ftp_messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "Ø§ÙØ§Ø³Ù Ø§ÙØ¬Ø¯ÙØ¯ ÙØ¬Ø¨ Ø£Ù ÙØ§ ÙØªØ¶ÙÙ ÙÙØ§Ø· . ÙÙ ØªØªÙ Ø¥Ø¹Ø§Ø¯Ø© ØªØ³ÙÙØ© ÙØ°Ø§ Ø§ÙØ¹ÙØµØ± Ø¥ÙÙ <b>%1\$s</b>";
$net2ftp_messages["The new name may not contain any banned keywords. This entry was not renamed to <b>%1\$s</b>"] = "Ø§ÙØ§Ø³Ù Ø§ÙØ¬Ø¯ÙØ¯ ÙØ§ ÙÙÙÙ Ø£Ù ÙØªØ¶ÙÙ ÙÙÙØ§Øª ÙÙØªØ§Ø­ÙØ© ÙØ­Ø¸ÙØ±Ø© .  ÙÙ ØªØªØªÙ Ø¥Ø¹Ø§Ø¯Ø© Ø§ÙØªØ³ÙÙØ© Ø¥ÙÙ <b>%1\$s</b>";
$net2ftp_messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "ØªÙ Ø¥Ø¹Ø§Ø¯Ø© ØªØ³ÙÙØ© <b>%1\$s</b> Ø¥ÙÙ <b>%2\$s</b> Ø¨ÙØ¬Ø§Ø­ !";
$net2ftp_messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "ØªØ¹Ø°Ø± Ø¥Ø¹Ø§Ø¯Ø© ØªØ³ÙÙØ© <b>%1\$s</b> Ø¥ÙÙ <b>%2\$s</b> !";

} // end rename


// -------------------------------------------------------------------------
// Unzip module
if ($net2ftp_globals["state"] == "unzip") {
// -------------------------------------------------------------------------

// /modules/unzip/unzip.inc.php
$net2ftp_messages["Unzip archives"] = "Ø§Ø³ØªØ®Ø±Ø§Ø¬ Ø§ÙÙÙ";
$net2ftp_messages["Getting archive %1\$s of %2\$s from the FTP server"] = "Ø¬ÙØ¨ Ø£Ø±Ø´ÙÙ %1\$s ÙÙ %2\$s ÙÙ Ø³Ø±ÙØ± FTP";
$net2ftp_messages["Unable to get the archive <b>%1\$s</b> from the FTP server"] = "ØªØ¹Ø°Ø± Ø¬ÙØ¨ Ø§ÙØ£Ø±Ø´ÙÙ <b>%1\$s</b> ÙÙ Ø³Ø±ÙØ± FTP";

// /skins/[skin]/unzip1.template.php
$net2ftp_messages["Set all targetdirectories"] = "ØªØ¹ÙÙÙ Ø¬ÙÙØ¹ Ø§ÙØ£Ø¯ÙØ© Ø§ÙÙØ¯Ù";
$net2ftp_messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "ÙØªØ¹ÙÙÙ Ø¯ÙÙÙ ÙØ¯Ù ÙØ´ØªØ±Ù , Ø£Ø¯Ø®Ù Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ¯Ù ÙÙ Ø§ÙØ­ÙÙ Ø§ÙÙØµÙ Ø§ÙØ³Ø§Ø¨Ù Ø«Ù Ø§Ø¶ØºØ· Ø²Ø± \"ØªØ¹ÙÙÙ Ø¬ÙÙØ¹ Ø§ÙØ£Ø¯ÙØ© Ø§ÙÙØ¯Ù\".";
$net2ftp_messages["Note: the target directory must already exist before anything can be copied into it."] = "ÙÙØ§Ø­Ø¸Ø© Â» Ø§ÙØ¯ÙÙÙ Ø§ÙÙØ¯Ù ÙØ¬Ø¨ Ø£Ù ÙÙÙÙ ÙÙØ¬ÙØ¯ Ø£ÙÙØ§Ù .";
$net2ftp_messages["Unzip archive <b>%1\$s</b> to:"] = "ÙÙ Ø§ÙØ£Ø±Ø´ÙÙ <b>%1\$s</b> Ø¥ÙÙ Â»";
$net2ftp_messages["Target directory:"] = "Ø§ÙÙØ¬ÙØ¯ Ø§ÙÙØ¯Ù Â»";
$net2ftp_messages["Use folder names (creates subdirectories automatically)"] = "Ø§Ø³ØªØ®Ø¯Ø§Ù ÙÙØ³ Ø£Ø³ÙØ§Ø¡ Ø§ÙÙØ¬ÙØ¯Ø§Øª (Ø¥ÙØ´Ø§Ø¡ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ø§ÙÙØ±Ø¹ÙØ© ØªÙÙØ§Ø¦ÙØ§Ù)";

} // end unzip


// -------------------------------------------------------------------------
// Upload module
if ($net2ftp_globals["state"] == "upload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Upload to directory:"] = "Ø±ÙØ¹ Ø¥ÙÙ Ø§ÙØ¯ÙÙÙ Â»";
$net2ftp_messages["Files"] = "Ø§ÙÙÙÙØ§Øª";
$net2ftp_messages["Archives"] = "Ø§ÙØ£Ø±Ø§Ø´ÙÙ";
$net2ftp_messages["Files entered here will be transferred to the FTP server."] = "Ø§ÙÙÙÙØ§Øª Ø§ÙØªÙ ØªØ¶Ø§Ù ÙÙØ§ Ø³ØªØ±Ø­Ù Ø¥ÙÙ Ø³Ø±ÙØ± FTP .";
$net2ftp_messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Ø§ÙØ£Ø±Ø§Ø´ÙÙ Ø§ÙØªÙ ØªØ¶Ø§Ù ÙÙØ§ ÙØªÙ ÙÙ Ø¶ØºØ·ÙØ§ Ù ØªØ±Ø­ÙÙ Ø§ÙÙÙÙØ§Øª Ø§ÙØªÙ Ø¨Ø¯Ø§Ø®ÙÙØ§ Ø¥ÙÙ Ø³Ø±ÙØ± FTP .";
$net2ftp_messages["Add another"] = "Ø¥Ø¶Ø§ÙØ© Ø¢Ø®Ø±";
$net2ftp_messages["Use folder names (creates subdirectories automatically)"] = "Ø§Ø³ØªØ®Ø¯Ø§Ù ÙÙØ³ Ø£Ø³ÙØ§Ø¡ Ø§ÙÙØ¬ÙØ¯Ø§Øª (Ø¥ÙØ´Ø§Ø¡ Ø§ÙÙØ¬ÙØ¯Ø§Øª Ø§ÙÙØ±Ø¹ÙØ© ØªÙÙØ§Ø¦ÙØ§Ù)";

$net2ftp_messages["Choose a directory"] = "Ø§Ø®ØªØ± Ø¯ÙÙÙ";
$net2ftp_messages["Please wait..."] = "ÙØ±Ø¬Ù Ø§ÙØ§ÙØªØ¸Ø§Ø± ...";
$net2ftp_messages["Uploading... please wait..."] = "Ø¬Ø§Ø± Ø§ÙØ±ÙØ¹ ... ÙØ±Ø¬Ù Ø§ÙØ§ÙØªØ¸Ø§Ø± ...";
$net2ftp_messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "Ø¥Ø°Ø§ Ø§Ø³ØªØºØ±Ù Ø§ÙØ±ÙØ¹ ÙÙØª Ø£Ø·ÙÙ ÙÙ Ø§ÙÙØ³ÙÙØ­ <b>%1\$s Ø«Ø§ÙÙØ©<\/b> , Ø³ØªØ­Ø§ØªØ¬ Ø¥ÙÙ Ø¥Ø¹Ø§Ø¯Ø© Ø§ÙÙØ­Ø§ÙÙØ© ÙØ¹ Ø¹Ø¯Ø¯ ÙÙÙØ§Øª Ø£ÙÙ / Ø£ØµØºØ± .";
$net2ftp_messages["This window will close automatically in a few seconds."] = "ÙØ°Ù Ø§ÙÙØ§ÙØ°Ø© Ø³ØªØºÙÙ ØªÙÙØ§Ø¦ÙØ§Ù Ø®ÙØ§Ù Ø«ÙØ§Ù ÙÙÙÙØ© .";
$net2ftp_messages["Close window now"] = "Ø¥ØºÙØ§Ù Ø§ÙÙØ§ÙØ°Ø© Ø§ÙØ¢Ù";

$net2ftp_messages["Upload files and archives"] = "Ø±ÙØ¹ Ø§ÙÙÙÙØ§Øª Ù Ø§ÙØ£Ø±Ø§Ø´ÙÙ";
$net2ftp_messages["Upload results"] = "ÙØªØ§Ø¦Ø¬ Ø§ÙØ±ÙØ¹";
$net2ftp_messages["Checking files:"] = "ØªÙØ­Øµ Ø§ÙÙÙÙØ§Øª Â»";
$net2ftp_messages["Transferring files to the FTP server:"] = "ØªØ±Ø­ÙÙ Ø§ÙÙÙÙØ§Øª Ø¥ÙÙ Ø§ÙØ³Ø±ÙØ± FTP Â»";
$net2ftp_messages["Decompressing archives and transferring files to the FTP server:"] = "ÙÙ Ø§ÙØ¶ØºØ· Ù ØªØ±Ø­ÙÙ Ø§ÙÙÙÙØ§Øª Ø¥ÙÙ Ø³Ø±ÙØ± FTP Â»";
$net2ftp_messages["Upload more files and archives"] = "Ø±ÙØ¹ Ø§ÙÙØ²ÙØ¯ ÙÙ Ø§ÙÙÙÙØ§Øª Ù Ø§ÙØ£Ø±Ø§Ø´ÙÙ";

} // end upload


// -------------------------------------------------------------------------
// Messages which are shared by upload and jupload
if ($net2ftp_globals["state"] == "upload" || $net2ftp_globals["state"] == "jupload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Restrictions:"] = "Ø§ÙØªØ­Ø¯ÙØ¯ Â»";
$net2ftp_messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s</b> and by PHP to <b>%2\$s</b>"] = "Ø§ÙØ­Ø¬Ù Ø§ÙØ£ÙØµÙ ÙÙÙÙÙ Ø§ÙÙØ§Ø­Ø¯ ÙØ­Ø¯Ø¯ Ø¨ÙØ§Ø³Ø·Ø© Ø§ÙØ¨Ø±ÙØ§ÙØ¬ Ø¥ÙÙ <b>%1\$s</b> Ù Ø¨ÙØ§Ø³Ø·Ø© PHP Ø¥ÙÙ <b>%2\$s</b>";
$net2ftp_messages["The maximum execution time is <b>%1\$s seconds</b>"] = "ÙØ¯Ø© Ø§ÙØªÙÙÙØ° Ø§ÙÙØµÙÙ ÙÙ <b>%1\$s Ø«Ø§ÙÙØ©</b>";
$net2ftp_messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "ÙÙØ· ØªØ±Ø­ÙÙ FTP Ø¥Ù ÙØ§Ù (ASCII Ø£Ù BINARY) ÙØªÙ ØªØ­Ø¯ÙØ¯Ù ØªÙÙØ§Ø¦ÙØ§Ù , Ø¨Ø§ÙØ£Ø¹ØªÙØ§Ø¯ Ø¹ÙÙ ÙØ§Ø­ÙØ© Ø§Ø³Ù Ø§ÙÙÙÙ";
$net2ftp_messages["If the destination file already exists, it will be overwritten"] = "Ø¥Ø°Ø§ ÙØ§Ù Ø§ÙÙÙÙ Ø§ÙÙØ¬ÙØ© ÙÙØ¬ÙØ¯ , Ø³ÙØªÙ Ø§Ø³ØªØ¨Ø¯Ø§ÙÙ";

} // end upload or jupload


// -------------------------------------------------------------------------
// View module
if ($net2ftp_globals["state"] == "view") {
// -------------------------------------------------------------------------

// /modules/view/view.inc.php
$net2ftp_messages["View file %1\$s"] = "Ø¹Ø±Ø¶ Ø§ÙÙÙÙ %1\$s";
$net2ftp_messages["View image %1\$s"] = "Ø¹Ø±Ø¶ Ø§ÙØµÙØ±Ø© %1\$s";
$net2ftp_messages["View Macromedia ShockWave Flash movie %1\$s"] = "Ø¹Ø±Ø¶ Macromedia ShockWave ÙÙÙ ÙÙØ§Ø´ %1\$s";
$net2ftp_messages["Image"] = "Ø§ÙØµÙØ±Ø©";

// /skins/[skin]/view1.template.php
$net2ftp_messages["Syntax highlighting powered by <a href=\"http://luminous.asgaard.co.uk\">Luminous</a>"] = "Syntax highlighting powered by <a href=\"http://luminous.asgaard.co.uk\">Luminous</a>";
$net2ftp_messages["To save the image, right-click on it and choose 'Save picture as...'"] = "ÙØ­ÙØ¸ Ø§ÙØµÙØ±Ø© , Ø§Ø¶ØºØ· Ø¨Ø§ÙØ²Ø± Ø§ÙØ£ÙÙÙ ÙÙÙÙØ§ Ù Ø§Ø®ØªØ± 'Ø­ÙØ¸ Ø§ÙØµÙØ±Ø© Ø¨Ø§Ø³Ù...'";

} // end view


// -------------------------------------------------------------------------
// Zip module
if ($net2ftp_globals["state"] == "zip") {
// -------------------------------------------------------------------------

// /modules/zip/zip.inc.php
$net2ftp_messages["Zip entries"] = "Ø¹ÙØ§ØµØ± Zip";

// /skins/[skin]/zip1.template.php
$net2ftp_messages["Save the zip file on the FTP server as:"] = "Ø­ÙØ¸ ÙÙÙ zip Ø¹ÙÙ Ø³Ø±ÙØ± FTP ÙÙ Â»";
$net2ftp_messages["Email the zip file in attachment to:"] = "Ø¥Ø±Ø³Ø§Ù ÙÙÙ zip Ø¨Ø§ÙØ¨Ø±ÙØ¯ ÙÙØ±ÙÙ Ø¥ÙÙ Â»";
$net2ftp_messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "ÙØ§Ø­Ø¸ Ø§Ù Ø¥Ø±Ø³Ø§Ù Ø§ÙÙÙÙØ§Øª ÙØ§ ÙØªØ¬Ø§ÙÙ Â» Ø¹ÙÙØ§ÙÙ IP ÙØ«Ù Ø¥Ø¶Ø§ÙØ© ÙÙØª Ø§ÙØ¥Ø±Ø³Ø§Ù Ø¥ÙÙ Ø§ÙØ±Ø³Ø§ÙØ© .";
$net2ftp_messages["Some additional comments to add in the email:"] = "Ø¥Ø¶Ø§ÙØ© Ø¨Ø¹Ø¶ Ø§ÙØªØ¹ÙÙÙØ§Øª Ø§ÙØ¥Ø¶Ø§ÙÙØ© Ø¥ÙÙ Ø§ÙØ±Ø³Ø§ÙØ© Â»";

$net2ftp_messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "ÙÙ ØªØ¯Ø®Ù Ø§Ø³Ù Ø§ÙÙÙÙ zip . Ø§Ø±Ø¬Ø¹ ÙÙØ®ÙÙ Ù Ø£Ø¯Ø®Ù Ø§ÙØ§Ø³Ù .";
$net2ftp_messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "Ø¹ÙÙØ§Ù Ø§ÙØ¨Ø±ÙØ¯ Ø§ÙØ§ÙÙØªØ±ÙÙÙ Ø§ÙØ°Ù Ø£Ø¯Ø®ÙØªÙ (%1\$s) ØºÙØ± ÙÙØ¨ÙÙ .<br />ÙØ±Ø¬Ù Ø¥Ø¯Ø®Ø§Ù Ø¹ÙÙØ§Ù Ø§ÙØ¨Ø±ÙØ¯ Ø§ÙØ§ÙÙØªØ±ÙÙÙ Ø¨Ø§ÙØªÙØ³ÙÙ <b>username@domain.com</b>";

} // end zip

?>