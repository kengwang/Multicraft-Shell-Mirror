<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2013 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | For credits, see the credits.txt file                                         |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a été copié vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |      if ($net2ftp_globals["state2"] == "rename") {           // <-- PHP code  |
//  |          $net2ftp_messages["Rename file"] = "Rename file";   // <-- message   |
//  |      }                                                       // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------


// -------------------------------------------------------------------------
// Language settings
// -------------------------------------------------------------------------

// HTML lang attribute
$net2ftp_messages["en"] = "ar";

// HTML dir attribute: left-to-right (LTR) or right-to-left (RTL)
$net2ftp_messages["ltr"] = "rtl";

// CSS style: align left or right (use in combination with LTR or RTL)
$net2ftp_messages["left"] = "right";
$net2ftp_messages["right"] = "left";

// Encoding
$net2ftp_messages["iso-8859-1"] = "windows-1256";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------

// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox

$net2ftp_messages["Connecting to the FTP server"] = "ÇáÇÊÕÇá ÈÓÑÝÑ FTP";
$net2ftp_messages["Logging into the FTP server"] = "ÇáÏÎæá Åáì ÓÑÝÑ FTP";
$net2ftp_messages["Setting the passive mode"] = "ÅÚÏÇÏÇÊ ÇáæÖÚ ÇáÎÇãá";
$net2ftp_messages["Getting the FTP system type"] = "ÇáÏÎæá Ýí äãØ äÙÇã FTP";
$net2ftp_messages["Changing the directory"] = "ÊÛííÑ ÇáÏáíá";
$net2ftp_messages["Getting the current directory"] = "ÇáÍÕæá Úáì ÇáÏáíá ÇáÍÇáí";
$net2ftp_messages["Getting the list of directories and files"] = "ÇáÍÕæá Úáì ÞÇÆãÉ ÇáÃÏáÉ æ ÇáãáÝÇÊ";
$net2ftp_messages["Parsing the list of directories and files"] = "ÊÍáíá ÞÇÆãÉ ÇáÃÏáÉ æ ÇáãáÝÇÊ";
$net2ftp_messages["Logging out of the FTP server"] = "ÊÓÌíá ÇáÎÑæÌ ãä ÓÑÝÑ FTP";
$net2ftp_messages["Getting the list of directories and files"] = "ÇáÍÕæá Úáì ÞÇÆãÉ ÇáÃÏáÉ æ ÇáãáÝÇÊ";
$net2ftp_messages["Printing the list of directories and files"] = "ØÈÇÚÉ ÞÇÆãÉ ÇáÃÏáÉ æ ÇáãáÝÇÊ";
$net2ftp_messages["Processing the entries"] = "ãÚÇáÌÉ ÇáÚäÇÕÑ";
$net2ftp_messages["Processing entry %1\$s"] = "ãÚÇáÌÉ ÇáÚäÕÑ %1\$s";
$net2ftp_messages["Checking files"] = "ÊÝÍÕ ÇáãáÝÇÊ";
$net2ftp_messages["Transferring files to the FTP server"] = "ÊÑÍíá ÇáãáÝÇÊ Åáì ÓÑÝÑ FTP";
$net2ftp_messages["Decompressing archives and transferring files"] = "Ýß ÖÛØ ÇáÃÑÔíÝ æ ÊÑÍíá ÇáãáÝÇÊ";
$net2ftp_messages["Searching the files..."] = "ÌÇÑí ÇáÈÍË Úä ÇáãáÝÇÊ ...";
$net2ftp_messages["Uploading new file"] = "ÌÇÑí ÑÝÚ ÇáãáÝ ÇáÌÏíÏ";
$net2ftp_messages["Reading the file"] = "ÞÑÇÁÉ ÇáãáÝ";
$net2ftp_messages["Parsing the file"] = "ÊÍáíá ÇáãáÝ";
$net2ftp_messages["Reading the new file"] = "ÞÑÇÁÉ ÇáãáÝ ÇáÌÏíÏ";
$net2ftp_messages["Reading the old file"] = "ÞÑÇÁÉ ÇáãáÝ ÇáÞÏíã";
$net2ftp_messages["Comparing the 2 files"] = "ãÞÇÑäÉ ÇáãáÝíä";
$net2ftp_messages["Printing the comparison"] = "ØÈÇÚÉ ÇáãÞÇÑäÉ";
$net2ftp_messages["Sending FTP command %1\$s of %2\$s"] = "ÅÑÓÇá ÃãÑ FTP %1\$s ãä %2\$s";
$net2ftp_messages["Getting archive %1\$s of %2\$s from the FTP server"] = "ÌáÈ ÃÑÔíÝ %1\$s ãä %2\$s ãä ÓÑÝÑ FTP";
$net2ftp_messages["Creating a temporary directory on the FTP server"] = "ÅäÔÇÁ Ïáíá ãÄÞÊ Úáì ÓÑÝÑ FTP";
$net2ftp_messages["Setting the permissions of the temporary directory"] = "ÅÚÏÇÏ ÊÕÇÑíÍ ÇáÏáíá ÇáãÄÞÊ";
$net2ftp_messages["Copying the net2ftp installer script to the FTP server"] = "äÓÎ ãÚÇáÌ net2ftp Åáì ÓÑÝÑ FTP";
$net2ftp_messages["Script finished in %1\$s seconds"] = "ÇáæÞÊ ÇáãÓÊÛÑÞ %1\$s ËÇäíÉ";
$net2ftp_messages["Script halted"] = "ÊÚËÑ ÇáãÚÇáÌ";

// Used on various screens
$net2ftp_messages["Please wait..."] = "íÑÌì ÇáÇäÊÙÇÑ ...";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unexpected state string: %1\$s. Exiting."] = "ÍÇáÉ ÛíÑ ãÞÈæáÉ » %1\$s . ãæÌæÏ .";
$net2ftp_messages["This beta function is not activated on this server."] = "æÙíÝÉ ÇáÇÎÊÈÇÑ ÛíÑ äÔØÉ Úáì åÐÇ ÇáÓÑÝÑ .";
$net2ftp_messages["This function has been disabled by the Administrator of this website."] = "åÐå ÇáæÙíÝÉ Êã ÊÚØíáåÇ ãä ÞÈá ÅÏÇÑÉ åÐÇ ÇáãæÞÚ .";


// -------------------------------------------------------------------------
// /includes/browse.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the directory <b>%2\$s</b> is shown instead."] = "ÇáÏáíá <b>%1\$s</b> ÛíÑ ãæÌæÏ Ãæ áÇ íãßä ÊÍÏíÏå , áÐÇ áÇ íãßä ÚÑÖ ÇáÏáíá <b>%2\$s</b> ÈÏáÇð ãäå .";
$net2ftp_messages["Your root directory <b>%1\$s</b> does not exist or could not be selected."] = "ÇáÏáíá ÇáÌÑÒ root <b>%1\$s</b> ÛíÑ ãæÌæÏ Ãæ áÇ íãßä ÊÍÏíÏå .";
$net2ftp_messages["The directory <b>%1\$s</b> could not be selected - you may not have sufficient rights to view this directory, or it may not exist."] = "ÇáÏáíá <b>%1\$s</b> áÇ íãßä ÊÍÏíÏå - ÑÈãÇ áÇÊãÊáß ÊÎæíá ßÇÝ áÚÑÖ åÐÇ ÇáÏáíá , Ãæ ÑÈãÇ íßæä ÛíÑ ãæÌæÏ .";
$net2ftp_messages["Entries which contain banned keywords can't be managed using net2ftp. This is to avoid Paypal or Ebay scams from being uploaded through net2ftp."] = "ÇáÅÏÎÇáÇÊ ÇáÊí ÊÍÊæí Úáì ßáãÇÊ ãÝÊÇÍíÉ ãÍÙæÑÉ áÇ íãßä ÅÏÇÑÊåÇ ÈæÇÓØÉ net2ftp .  Ðáß áÍãÇíÉ Paypal Ãæ Ebay ãä ÇáÛÔ æ ÇáÊáÇÚÈ .";
$net2ftp_messages["Files which are too big can't be downloaded, uploaded, copied, moved, searched, zipped, unzipped, viewed or edited; they can only be renamed, chmodded or deleted."] = "ÇáãáÝÇÊ ÇáßÈíÑÉ ÌÏÇð áÇ íãßä ÊÍãíáåÇ ¡ ÑÝÚåÇ ¡ äÓÎåÇ ¡ äÞáåÇ ¡ ÇáÈÍË ÝíåÇ ¡ ÖÛØåÇ ¡ Ýß ÖÛØåÇ ¡ ÚÑÖåÇ Ãæ ÊÍÑíÑåÇ º  ÝÞØ íãßä ÊÛííÑ ÇáÇÓã ¡ ÇáÊÕÇÑíÍ Ãæ ÇáÍÐÝ .";
$net2ftp_messages["Execute %1\$s in a new window"] = "ÊäÝíÐ %1\$s Ýí äÇÝÐÉ ÌÏíÏÉ";


// -------------------------------------------------------------------------
// /includes/main.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Please select at least one directory or file!"] = "íÑÌì ÊÍÏíÏ ãÌáÏ Ãæ ãáÝ æÇÍÏ Úáì ÇáÃÞá !";


// -------------------------------------------------------------------------
// /includes/authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$net2ftp_messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "ÓÑÝÑ FTP <b>%1\$s</b> ÛíÑ ãæÌæÏ Ýí ÞÇÆãÉ ÓÑÝÑÇÊ FTP ÇáãÓãæÍ ÈåÇ .";
$net2ftp_messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "ÇáÓÑÝÑ FTP <b>%1\$s</b> ãæÌæÏ Ýí ÞÇÆãÉ ÓÑÝÑÇÊ FTP ÇáãÍÙæÑÉ .";
$net2ftp_messages["The FTP server port %1\$s may not be used."] = "ãäÝÐ ÓÑÝÑ FTP %1\$s áÇ íãßä ÇÓÊÎÏÇãå .";
$net2ftp_messages["Your IP address (%1\$s) is not in the list of allowed IP addresses."] = "ÚäæÇä IP  ÇáÎÇÕ Èß (%1\$s) ÛíÑ ãæÌæÏ Ýí ÞÇÆãÉ ÚäÇæíä IP ÇáãÓãæÍ ÈåÇ .";
$net2ftp_messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "ÚäæÇä IP ÇáÎÇÕ Èß (%1\$s) ãæÌæÏ Ýí ÞÇÆãÉ ÚäÇæíä IP ÇáãÍÙæÑÉ .";

// isAuthorizedDirectory()
$net2ftp_messages["Table net2ftp_users contains duplicate rows."] = "ÇáÌÏæá net2ftp_users íÍÊæí Úáì ÕÝæÝ ãßÑÑÉ .";

// checkAdminUsernamePassword()
$net2ftp_messages["You did not enter your Administrator username or password."] = "áã ÊÞã ÈÅÏÎÇá ÇÓã ÇáãÓÊÎÏã ááÅÏÇÑÉ Ãæ ßáãÉ ÇáãÑæÑ !";
$net2ftp_messages["Wrong username or password. Please try again."] = "ÎØÃ Ýí ÇÓã ÇáãÓÊÎÏã Ãæ ßáãÉ ÇáãÑæÑ . íÑÌì ÇáãÍÇæáÉ ãä ÌÏíÏ !";

// -------------------------------------------------------------------------
// /includes/consumption.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unable to determine your IP address."] = "ÊÚÐÑ ÊÍÏíÏ ÚäæÇä IP ÇáÎÇÕ Èß .";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress contains duplicate rows."] = "ÇáÌÏæá net2ftp_log_consumption_ipaddress íÍÊæí Úáì ÕÝæÝ ãßÑÑÉ .";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver contains duplicate rows."] = "ÇáÌÏæá net2ftp_log_consumption_ftpserver íÍÊæí Úáì ÕÝæÝ ãßÑÑÉ .";
$net2ftp_messages["The variable <b>consumption_ipaddress_datatransfer</b> is not numeric."] = "ÇáãÊÛíÑ <b>consumption_ipaddress_datatransfer</b> áíÓ ÚÏÏí .";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress could not be updated."] = "áÇ íãßä ÊÍÏíË ÇáÌÏæá net2ftp_log_consumption_ipaddress .";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress contains duplicate entries."] = "ÇáÌÏæá net2ftp_log_consumption_ipaddress íÍÊæí Úáì ÚäÇÕÑ ãßÑÑÉ .";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver could not be updated."] = "áÇ íãßä ÊÍÏíË ÇáÌÏæá net2ftp_log_consumption_ftpserver .";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver contains duplicate entries."] = "ÇáÌÏæá net2ftp_log_consumption_ftpserver íÍÊæí Úáì ÚäÇÕÑ ãßÑÑÉ .";
$net2ftp_messages["Table net2ftp_log_access could not be updated."] = "áÇ íãßä ÊÍÏíË ÇáÌÏæá net2ftp_log_access .";
$net2ftp_messages["Table net2ftp_log_access contains duplicate entries."] = "íÊÖãä ÇáÌÏæá net2ftp_log_access ãÏÎáÇÊ ãÊßÑÑÉ .";


// -------------------------------------------------------------------------
// /includes/database.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unable to connect to the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php."] = "ÊÚÐÑ ÇáÇÊÕÇá ÈÞÇÚÏÉ ÇáÈíÇäÇÊ MySQL . íÑÌì ÇáÊÃßÏ ãä ÕÍÉ ãÚáæãÇÊß ÇáãÏÎáÉ Ýí ÇáãáÝ settings.inc.php.";
$net2ftp_messages["Unable to select the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php."] = "ÊÚÐÑ ÊÍÏíÏ ÞÇÚÏÉ ÇáÈíÇäÇÊ MySQL . íÑÌì ÇáÊÃßÏ ãä ÕÍÉ ãÚáæãÇÊß ÇáãÏÎáÉ Ýí ÇáãáÝ settings.inc.php.";


// -------------------------------------------------------------------------
// /includes/errorhandling.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["An error has occured"] = "ÍÏË ÎØÃ";
$net2ftp_messages["Go back"] = "ÇáÚæÏÉ ááÎáÝ";
$net2ftp_messages["Go to the login page"] = "ÇáÐåÇÈ Åáì ÕÝÍÉ ÇáÏÎæá";


// -------------------------------------------------------------------------
// /includes/filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">php.net</a><br />"] = "The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">php.net</a><br />";
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/function.ftp-ssl-connect.php\" target=\"_blank\">FTP and/or OpenSSL modules of PHP</a> is not installed.<br /><br /> The administrator of this website should install these modules. Installation instructions are given on php.net: <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">here for FTP</a>, and <a href=\"http://www.php.net/manual/en/openssl.installation.php\" target=\"_blank\">here for OpenSSL</a><br />"] = "The <a href=\"http://www.php.net/manual/en/function.ftp-ssl-connect.php\" target=\"_blank\">FTP and/or OpenSSL modules of PHP</a> is not installed.<br /><br /> The administrator of this website should install these modules. Installation instructions are given on php.net: <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">here for FTP</a>, and <a href=\"http://www.php.net/manual/en/openssl.installation.php\" target=\"_blank\">here for OpenSSL</a><br />";
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/function.ssh2-sftp.php\" target=\"_blank\">SSH2 module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ssh2.installation.php\" target=\"_blank\">php.net</a><br />"] = "The <a href=\"http://www.php.net/manual/en/function.ssh2-sftp.php\" target=\"_blank\">SSH2 module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ssh2.installation.php\" target=\"_blank\">php.net</a><br />";
$net2ftp_messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "ÊÚÐÑ ÇáÇÊÕÇá ÈÓÑÝÑ FTP <b>%1\$s</b> Úáì ÇáãäÝÐ <b>%2\$s</b>.<br /><br />åá ÃäÊ ãÊÃßÏ ãä ÕÍÉ ÚäæÇä ÓÑÝÑ FTP ¿ åÐÇ íÍÕá áÃÓÈÇÈ ãÎÊáÝÉ ãä ÓÑÝÑ HTTP (æíÈ) . íÑÌì ÇáÇÊÕÇá ÈãÎÏã ISP Ãæ ãÏíÑ ÇáäÙÇã ááãÓÇÚÏÉ .<br />";
$net2ftp_messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "ÊÚÐÑ ÇáÏÎæá Åáì ÓÑÝÑ FTP <b>%1\$s</b> ÈæÇÓØÉ ÇÓã ÇáãÓÊÎÏã <b>%2\$s</b>.<br /><br />åá ÇäÊ ãÊÃßÏ ãä ÕÍÉ ÇÓã ÇáãÓÊÎÏã æ ßáãÉ ÇáãÑæÑ ¿ íÑÌì ÇáÇÊÕÇá ÈãÎÏã ISP Ãæ ãÏíÑ ÇáäÙÇã ááãÓÇÚÏÉ .<br />";
$net2ftp_messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "ÊÚÐÑ ÇáÊÈÏíá Åáì ÇáäãØ ÇáÎÇãá passive Úáì ÓÑÝÑ FTP <b>%1\$s</b>.";

// ftp_openconnection2()
$net2ftp_messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "ÊÚÐÑ ÇáÇÊÕÇá ÈÓÑÝÑ FTP ÇáËÇäí (ÇáåÏÝ) <b>%1\$s</b> Úáì ÇáãäÝÐ <b>%2\$s</b>.<br /><br />åá ÇäÊ ãÊÃßÏ ãä ÕÍÉ ÚäæÇä ÓÑÝÑ FTP ÇáËÇäí (ÇáåÏÝ) ¿ åÐÇ íÍÏË áÃÓÈÇÈ ãÎÊáÝÉ ãä ÓÑÝÑ HTTP (æíÈ) . íÑÌì ÇáÇÊÕÇá ÈãÎÏã ISP Ãæ ãÏíÑ ÇáäÙÇã ááãÓÇÚÏÉ .<br />";
$net2ftp_messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "ÊÚÐÑ ÇáÏÎæá Åáì ÓÑÝÑ FTP ÇáËÇäí (ÇáåÏÝ) <b>%1\$s</b> ÈæÇÓØÉ ÇÓã ÇáãÓÊÎÏã <b>%2\$s</b>.<br /><br />åá ÃäÊ ãÊÃßÏ ãä ÕÍÉ ÇÓã ÇáãÓÊÎÏã æ ßáãÉ ÇáãÑæÑ ¿ íÑÌì ÇáÇÊÕÇá ÈãÎÏã ISP Ãæ ãÏíÑ ÇáäÙÇã ááãÓÇÚÏÉ .<br />";
$net2ftp_messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "ÊÚÐÑ ÇáÊÈÏíá Åáì ÇáäãØ ÇáÎÇãá passive Úáì ÓÑÝÑ FTP ÇáËÇäí (ÇáåÏÝ) <b>%1\$s</b>.";

// ftp_myrename()
$net2ftp_messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "ÊÚÐÑ ÅÚÇÏÉ ÊÓãíÉ ÇáãÌáÏ Ãæ ÇáãáÝ <b>%1\$s</b> Åáì <b>%2\$s</b>";

// ftp_mychmod()
$net2ftp_messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "ÊÚÐÑ ÊäÝíÐ ÃãÑ ÇáãæÞÚ <b>%1\$s</b>. áÇÍÙ Çä ÃãÑ ÇáÊÕÑíÍ CHMOD ãÊÇÍ ÝÞØ Úáì ÓÑÝÑÇÊ Unix FTP , æ ÛíÑ ãÊÇÍ Úáì ÓÑÝÑÇÊ Windows FTP ..";
$net2ftp_messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "Êã ÊÛííÑ ÊÕÑíÍ ÇáãÌáÏ <b>%1\$s</b> Åáì <b>%2\$s</b> ÈäÌÇÍ ! ";
$net2ftp_messages["Processing entries within directory <b>%1\$s</b>:"] = "ãÚÇáÌÉ ÇáÚäÇÕÑ Ýí ÇáãÌáÏ <b>%1\$s</b> »";
$net2ftp_messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "Êã ÊÛííÑ ÊÕÑíÍ ÇáãáÝ <b>%1\$s</b> Åáì <b>%2\$s</b> ÈäÌÇÍ !";
$net2ftp_messages["All the selected directories and files have been processed."] = "ÊãÊ ãÚÇáÌÉ ÌãíÚ ÇáÃÏáÉ æ ÇáãáÝÇÊ ÇáãÍÏÏÉ .";

// ftp_rmdir2()
$net2ftp_messages["Unable to delete the directory <b>%1\$s</b>"] = "ÊÚÐÑ ÍÐÝ ÇáãÌáÏ <b>%1\$s</b>";

// ftp_delete2()
$net2ftp_messages["Unable to delete the file <b>%1\$s</b>"] = "ÊÚÐÑ ÍÐÝ ÇáãáÝ <b>%1\$s</b>";

// ftp_newdirectory()
$net2ftp_messages["Unable to create the directory <b>%1\$s</b>"] = "ÊÚÐÑ ÅäÔÇÁ ÇáãÌáÏ <b>%1\$s</b>";

// ftp_readfile()
$net2ftp_messages["Unable to create the temporary file"] = "ÊÚÐÑ ÅäÔÇÁ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ";
$net2ftp_messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "ÊÚÐÑ ÌáÈ ÇáãáÝ <b>%1\$s</b> ãä ÓÑÝÑ FTP æ ÍÝÙå Ýí ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ <b>%2\$s</b>.<br />ÊÝÍÕ ÕáÇÍíÇÊ ÇáãÌáÏ %3\$s .<br />";
$net2ftp_messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "ÊÚÐÑ ÝÊÍ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ . ÊÝÍÕ ÕáÇÍíÇÊ ÇáãÌáÏ %1\$s .";
$net2ftp_messages["Unable to read the temporary file"] = "ÊÚÐÑ ÞÑÇÁÉ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ";
$net2ftp_messages["Unable to close the handle of the temporary file"] = "ÊÚÐÑ ÅÛáÇÞ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ";
$net2ftp_messages["Unable to delete the temporary file"] = "ÊÚÐÑ ÍÐÝ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ";

// ftp_writefile()
$net2ftp_messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "ÊÚÐÑ ÅäÔÇÁ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ . ÊÝÍÕ ÕáÇÍíÇÊ ÇáãÌáÏ %1\$s .";
$net2ftp_messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "ÊÚÐÑ ÝÊÍ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ . ÊÝÍÕ ÕáÇÍíÇÊ ÇáãÌáÏ %1\$s .";
$net2ftp_messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "ÊÚÐÑ ÇáßÊÇÈÉ Åáì ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ <b>%1\$s</b>.<br />ÊÝÍÕ ÕáÇÍíÇÊ ÇáãÌáÏ %2\$s .";
$net2ftp_messages["Unable to close the handle of the temporary file"] = "ÊÚÐÑ ÅÛáÇÞ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ";
$net2ftp_messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "ÊÚÐÑ æÖÚ ÇáãáÝ <b>%1\$s</b> Úáì ÓÑÝÑ FTP .<br />ÑÈãÇ áÇ ÊãÊáß ÕáÇÍíÇÊ ÇáßÊÇÈÉ Åáì åÐÇ ÇáÏáíá !";
$net2ftp_messages["Unable to delete the temporary file"] = "ÊÚÐÑ ÍÐÝ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ";

// ftp_copymovedelete()
$net2ftp_messages["Processing directory <b>%1\$s</b>"] = "Processing directory <b>%1\$s</b>";
$net2ftp_messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "ÇáÏáíá ÇáåÏÝ <b>%1\$s</b> äÝÓ ÇáãÕÏÑ Ãæ Ïáíá ÝÑÚí ãä ÇáÏáíá ÇáãÕÏÑ <b>%2\$s</b>, áÐÇ ÓíÊã ÊÎØí åÐÇ ÇáÏáíá .";
$net2ftp_messages["The directory <b>%1\$s</b> contains a banned keyword, so this directory will be skipped"] = "ÇáÏáíá <b>%1\$s</b> íÍÊæí Úáì ßáãÇÊ ãÝÊÇÍíÉ ãÍÙæÑÉ ¡ áÐÇ ÓíÊã ÊÎØí åÐÇ ÇáÏáíá";
$net2ftp_messages["The directory <b>%1\$s</b> contains a banned keyword, aborting the move"] = "ÇáÏáíá <b>%1\$s</b> íÍÊæí Úáì ßáãÇÊ ãÝÊÇÍíÉ ãÍÙæÑÉ ¡ Êã ÅáÛÇÁ ÇáäÞá";
$net2ftp_messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "ÊÚÐÑ ÅäÔÇÁ ÇáÏáíá ÇáÝÑÚí <b>%1\$s</b>. ÑÈãÇ íßæä ãæÌæÏ ãä . ãÊÇÈÚÉ ÚãáíÉ ÇáäÓÎ/ÇáäÞá ...";
$net2ftp_messages["Created target subdirectory <b>%1\$s</b>"] = "ÅäÔÇÁ ÇáÏáíá ÇáÝÑÚí ÇáåÏÝ <b>%1\$s</b>";
$net2ftp_messages["The directory <b>%1\$s</b> could not be selected, so this directory will be skipped"] = "ÇáÏáíá <b>%1\$s</b> áÇ íãßä ÊÍÏíÏå . áÐÇ ÓíÊã ÊÎØí åÐÇ ÇáÏáíá .";
$net2ftp_messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "ÊÚÐÑ ÍÐÝ ÇáÏáíá ÇáÝÑÚí <b>%1\$s</b> - ÑÈãÇ íßæä ÝÇÑÛ";
$net2ftp_messages["Deleted subdirectory <b>%1\$s</b>"] = "Êã ÍÐÝ ÇáÏáíá ÇáÝÑÚí <b>%1\$s</b>";
$net2ftp_messages["Deleted subdirectory <b>%1\$s</b>"] = "Êã ÍÐÝ ÇáÏáíá ÇáÝÑÚí <b>%1\$s</b>";
$net2ftp_messages["Unable to move the directory <b>%1\$s</b>"] = "Unable to move the directory <b>%1\$s</b>";
$net2ftp_messages["Moved directory <b>%1\$s</b>"] = "Moved directory <b>%1\$s</b>";
$net2ftp_messages["Processing of directory <b>%1\$s</b> completed"] = "ÊãÊ ãÚÇáÌÉ ÇáÏáíá <b>%1\$s</b>";
$net2ftp_messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "ÇáÏáíá ÇáåÏÝ ááãáÝ <b>%1\$s</b> íÈÏæ Ãäå ßÇáãÕÏÑ , áÐÇ ÓíÊã ÊÎØí åÐÇ ÇáãáÝ";
$net2ftp_messages["The file <b>%1\$s</b> contains a banned keyword, so this file will be skipped"] = "ÇáãáÝ <b>%1\$s</b> íÍÊæí Úáì ßáãÇÊ ãÝÊÇÍíÉ ãÍÙæÑÉ ¡ áÐÇ ÓíÊã ÊÎØí åÐÇ ÇáãáÝ";
$net2ftp_messages["The file <b>%1\$s</b> contains a banned keyword, aborting the move"] = "ÇáãáÝ <b>%1\$s</b> íÍÊæí Úáì ßáãÇÊ ãÝÊÇÍíÉ ãÍÙæÑÉ ¡ Êã ÅáÛÇÁ ÇáäÞá";
$net2ftp_messages["The file <b>%1\$s</b> is too big to be copied, so this file will be skipped"] = "ÇáãáÝ <b>%1\$s</b> ßÈíÑ ÌÏÇð ßí íäÓÎ ¡ áÐÇ ÓíÊã ÊÌÇæÒå";
$net2ftp_messages["The file <b>%1\$s</b> is too big to be moved, aborting the move"] = "ÇáãáÝ <b>%1\$s</b> ßÈíÑ ÌÏÇð ßí íäÞá ¡ Êã ÅáÛÇÁ ÇáäÞá";
$net2ftp_messages["Unable to copy the file <b>%1\$s</b>"] = "ÊÚÐÑ äÓÎ ÇáãáÝ <b>%1\$s</b>";
$net2ftp_messages["Copied file <b>%1\$s</b>"] = "Êã äÓÎ ÇáãáÝ <b>%1\$s</b>";
$net2ftp_messages["Unable to move the file <b>%1\$s</b>, aborting the move"] = "ÊÚÐÑ äÞá ÇáãáÝ <b>%1\$s</b>, Êã ÅáÛÇÁ ÇáÚãáíÉ";
$net2ftp_messages["Unable to move the file <b>%1\$s</b>"] = "Unable to move the file <b>%1\$s</b>";
$net2ftp_messages["Moved file <b>%1\$s</b>"] = "Êã äÞá ÇáãáÝ <b>%1\$s</b>";
$net2ftp_messages["Unable to delete the file <b>%1\$s</b>"] = "ÊÚÐÑ ÍÐÝ ÇáãáÝ <b>%1\$s</b>";
$net2ftp_messages["Deleted file <b>%1\$s</b>"] = "Êã ÍÐÝ ÇáãáÝ <b>%1\$s</b>";
$net2ftp_messages["All the selected directories and files have been processed."] = "ÊãÊ ãÚÇáÌÉ ÌãíÚ ÇáÃÏáÉ æ ÇáãáÝÇÊ ÇáãÍÏÏÉ .";

// ftp_processfiles()

// ftp_getfile()
$net2ftp_messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "ÊÚÐÑ äÓÎ ÇáãáÝ ÇáÈÚíÏ <b>%1\$s</b> Åáì ÇáãáÝ ÇáãÍáí ÈÇÓÊÎÏÇã äãØ FTP <b>%2\$s</b>";
$net2ftp_messages["Unable to delete file <b>%1\$s</b>"] = "ÊÚÐÑ ÍÐÝ ÇáãáÝ <b>%1\$s</b>";

// ftp_putfile()
$net2ftp_messages["The file is too big to be transferred"] = "ßÈíÑ ÌÏÇð ßí íÊã ÊÑÍíáå";
$net2ftp_messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "ÇáÍÕÉ ÇáíæãíÉ ÇáãÓãæÍ ÈåÇ ÇÓÊäÝÐÊ » ÇáãáÝ <b>%1\$s</b> áä íÊã ÊÑÍíáå";
$net2ftp_messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "ÊÚÐÑ äÓÎ ÇáãáÝ ÇáãÍáí Åáì ÇáãáÝ ÇáÈÚíÏ <b>%1\$s</b> ÈÇÓÊÎÏÇã äãØ FTP <b>%2\$s</b>";
$net2ftp_messages["Unable to delete the local file"] = "ÊÚÐÑ ÍÐÝ ÇáãáÝ ÇáãÍáí";

// ftp_downloadfile()
$net2ftp_messages["Unable to delete the temporary file"] = "ÊÚÐÑ ÍÐÝ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ";
$net2ftp_messages["Unable to send the file to the browser"] = "ÊÚÐÑ ÅÑÓÇá ÇáãáÝ Åáì ÇáãÓÊÚÑÖ";

// ftp_zip()
$net2ftp_messages["Unable to create the temporary file"] = "ÊÚÐÑ ÅäÔÇÁ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ";
$net2ftp_messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "Êã ÍÝÙ ÇáãáÝ ÇáãÖÛæØ zip Åáì ÓÑÝÑ FTP ÈÇÓã <b>%1\$s</b>";
$net2ftp_messages["Requested files"] = "ÇáãáÝÇÊ ÇáãØáæÈÉ";

$net2ftp_messages["Dear,"] = "ÇáÓáÇã Úáíßã ,";
$net2ftp_messages["Someone has requested the files in attachment to be sent to this email account (%1\$s)."] = "ÔÎÕ ãÇ ØáÈ ÅÑÓÇá ÇáãáÝÇÊ ÇáãÑÝÞÉ Åáì ÚäæÇä ÇáÈÑíÏ ÇáÇáßÊÑæäí (%1\$s) .";
$net2ftp_messages["If you know nothing about this or if you don't trust that person, please delete this email without opening the Zip file in attachment."] = "Åä áã Êßä ÊÚÑÝ ÔÆ Íæá åÐÇ , Ãæ Åä áã Êßä ãÚäí ÈåÐÇ ÇáÔÎÕ , íÑÌì ÍÐÝ ÇáÑÓÇáÉ ÈÏæä ÝÊÍ ÇáãáÝ ÇáãÖÛæØ ÇáãÑÝÞ .";
$net2ftp_messages["Note that if you don't open the Zip file, the files inside cannot harm your computer."] = "ãáÇÍÙÉ - Åä áã ÊÞã ÈÝÊÍ ÇáãáÝ ÇáãÖÛæØ , Ýáä ÊáÍÞ ÇáãáÝÇÊ ÇáÊí ÈÏÇÎáå Ãí ÃÐì ÈÌåÇÒß Åä ßäÊ ÊÔß ÈåÇ .";
$net2ftp_messages["Information about the sender: "] = "ãÚáæãÇÊ Íæá ÇáãÑÓá » ";
$net2ftp_messages["IP address: "] = "ÚäæÇä IP » ";
$net2ftp_messages["Time of sending: "] = "æÞÊ ÇáÅÑÓÇá » ";
$net2ftp_messages["Sent via the net2ftp application installed on this website: "] = "ÃÑÓáÊ ÈæÇÓØÉ ÈÑäÇãÌ net2ftp ÇáãÑßÈ Úáì åÐÇ ÇáãæÞÚ » ";
$net2ftp_messages["Webmaster's email: "] = "ÈÑíÏ ÇáÅÏÇÑÉ » ";
$net2ftp_messages["Message of the sender: "] = "ÑÓÇáÉ ÇáãÑÓá » ";
$net2ftp_messages["net2ftp is free software, released under the GNU/GPL license. For more information, go to http://www.net2ftp.com."] = "net2ftp ÈÑäÇãÌ ãÌÇäí ¡ ÕÇÏÑ ÊÍÊ ÇáÊÑÎíÕ GNU/GPL .  ááãÒíÏ ãä ÇáãÚáæãÇÊ ¡ ÑÇÌÚ http://www.net2ftp.com .";

$net2ftp_messages["The zip file has been sent to <b>%1\$s</b>."] = "Êã ÅÑÓÇá ÇáãáÝ ÇáãÖÛæØ Åáì <b>%1\$s</b>.";

// acceptFiles()
$net2ftp_messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "ÍÌã ÇáãáÝ <b>%1\$s</b> ßÈíÑ ÌÏÇð . áä íÊã ÑÝÚ åÐÇ ÇáãáÝ .";
$net2ftp_messages["File <b>%1\$s</b> is contains a banned keyword. This file will not be uploaded."] = "ÇáãÝ <b>%1\$s</b> íÊÖãä ßáãÇÊ ãÝÊÇÍíÉ ãÍÙæÑÉ .  áä íÊã ÑÝÚ åÐÇ ÇáãáÝ .";
$net2ftp_messages["Could not generate a temporary file."] = "ÊÚÐÑ ÅäÔÇÁ ãáÝ ÇáÊÎÒíä ÇáãÄÞÊ .";
$net2ftp_messages["File <b>%1\$s</b> could not be moved"] = "ÊÚÐÑ äÞá ÇáãáÝ <b>%1\$s</b>";
$net2ftp_messages["File <b>%1\$s</b> is OK"] = "ÇáãÝ <b>%1\$s</b> äÌÇÍ !";
$net2ftp_messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "ÊÚÐÑ äÞá ÇáãáÝ ÇáãÑÝæÚ Åáì ãÌáÏ temp .<br /><br />íÌÈ ãäÍ ÇáÊÕÑíÍ <b>chmod 777</b> Åáì ÇáãÌáÏ /temp Ýí Ïáíá net2ftp.";
$net2ftp_messages["You did not provide any file to upload."] = "áã ÊÞã ÈÊÍÏíÏ Ãí ãáÝ áÑÝÚå !";

// ftp_transferfiles()
$net2ftp_messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "ÊÚÐÑ ÊÑÍíá ÇáãáÝ <b>%1\$s</b> Åáì ÓÑÝÑ FTP";
$net2ftp_messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "Êã ÊÑÍíá ÇáãáÝ <b>%1\$s</b> Åáì ÓÑÝÑ FTP ÈÇÓÊÎÏÇã äãØ FTP <b>%2\$s</b>";
$net2ftp_messages["Transferring files to the FTP server"] = "ÊÑÍíá ÇáãáÝÇÊ Åáì ÓÑÝÑ FTP";

// ftp_unziptransferfiles()
$net2ftp_messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "ãÚÇáÌÉ ÇáÃÑÔíÝ ÑÞã %1\$s » <b>%2\$s</b>";
$net2ftp_messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "ÊÚÐÑ ãÚÇáÌÉ ÇáÃÑÔíÝ <b>%1\$s</b> ÈÓÈÈ ÚÏã ÏÚã åÐÇ ÇáäæÚ . ÝÞØ ÃäæÇÚ ÇáÃÑÔíÝ zip, tar, tgz æ gz ãÏÚæãÉ ÍÇáíÇð .";
$net2ftp_messages["Unable to extract the files and directories from the archive"] = "ÊÚÐÑ ÇÓÊÎÑÇÌ ÇáãáÝÇÊ æ ÇáãÌáÏÇÊ ãä ÇáÃÑÔíÝ";
$net2ftp_messages["Archive contains filenames with ../ or ..\\ - aborting the extraction"] = "Archive contains filenames with ../ or ..\\ - aborting the extraction";
$net2ftp_messages["Could not unzip entry %1\$s (error code %2\$s)"] = "Could not unzip entry %1\$s (error code %2\$s)";
$net2ftp_messages["Created directory %1\$s"] = "Êã ÅäÔÇÁ ÇáÏáíá %1\$s";
$net2ftp_messages["Could not create directory %1\$s"] = "ÊÚÐÑ ÅäÔÇÁ ÇáÏáíá %1\$s";
$net2ftp_messages["Copied file %1\$s"] = "Êã äÓÎ %1\$s";
$net2ftp_messages["Could not copy file %1\$s"] = "ÊÚÐÑ äÓÎ ÇáãáÝ %1\$s";
$net2ftp_messages["Unable to delete the temporary directory"] = "ÊÚÐÑ ÍÐÝ ÇáÏáíá ÇáãÄÞÊ";
$net2ftp_messages["Unable to delete the temporary file %1\$s"] = "ÊÚÐÑ ÍÐÝ ÇáãáÝ ÇáãÄÞÊ %1\$s";

// ftp_mysite()
$net2ftp_messages["Unable to execute site command <b>%1\$s</b>"] = "ÊÚÐÑ ÊäÝíÐ ÇãÑ ÇáãæÞÚ <b>%1\$s</b>";

// shutdown()
$net2ftp_messages["Your task was stopped"] = "Êã ÅíÞÇÝ ÇáãåãÉ";
$net2ftp_messages["The task you wanted to perform with net2ftp took more time than the allowed %1\$s seconds, and therefor that task was stopped."] = "ÇáãåãÉ ÇáÊí ÊÑíÏ ÅäÌÇÒåÇ ÈæÇÓØÉ net2ftp ÇÓÊÛÑÞÊ æÞÊ ÃØæá ãä ÇáãÓãæÍ %1\$s ËÇäíÉ , æ áÐáß Êã ÅíÞÇÝ ÇáãåãÉ .";
$net2ftp_messages["This time limit guarantees the fair use of the web server for everyone."] = "åÐÇ ÇáæÞÊ ÇáãÍÏÏ áÖãÇä ÚÏÇáÉ ÇÓÊÎÏÇã ÇáÓÑÝÑ ááÌãíÚ .";
$net2ftp_messages["Try to split your task in smaller tasks: restrict your selection of files, and omit the biggest files."] = "ÌÑÈ ÊÌÒÆÉ ãåãÊß Åáì ãåãÇÊ ÃÕÛÑ » Þáá ãä ÚÏÏ ÇáãáÝÇÊ ÇáãÍÏÏÉ , æ ÇÍÐÝ ÇáãáÝÇÊ ÇáÃßÈÑ .";
$net2ftp_messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "ÅÐÇ ßäÊ ÊÑíÏ ÍÞÇð Êãßíä net2ftp ãä ÅäÌÇÒ ÇáãåÇã ÇáßÈíÑÉ ÇáÊí ÊÓÊÛÑÞ æÞÊ Øæíá , íãßäß ÇáÊÝßíÑ Ýí ÊÑßíÈ ÈÑäÇãÌ net2ftp Úáì ãæÞÚß ãÈÇÔÑÉ .";

// SendMail()
$net2ftp_messages["You did not provide any text to send by email!"] = "áã ÊÞÏã Ãí äÕ áÅÑÓÇáå ÈæÇÓØÉ ÇáÈÑíÏ ÇáÇáßÊÑæäí !";
$net2ftp_messages["You did not supply a From address."] = "íÑÌì ßÊÇÈÉ ÚäæÇä ÈÑíÏ ÇáãÑÓá !";
$net2ftp_messages["You did not supply a To address."] = "íÑÌì ßÊÇÈÉ ÚäæÇä ÈÑíÏ ÇáãÊáÞí !";
$net2ftp_messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "ÍÏË ÎØÃ ÊÞäí ÎáÇá ãÍÇæáÉ ÇáÅÑÓÇá Åáì <b>%1\$s</b> ÊÚÐÑ ÇáÅÑÓÇá .";

// tempdir2()
$net2ftp_messages["Unable to create a temporary directory because (unvalid parent directory)"] = "Unable to create a temporary directory because (unvalid parent directory)";
$net2ftp_messages["Unable to create a temporary directory because (parent directory is not writeable)"] = "Unable to create a temporary directory because (parent directory is not writeable)";
$net2ftp_messages["Unable to create a temporary directory (too many tries)"] = "Unable to create a temporary directory (too many tries)";

// -------------------------------------------------------------------------
// /includes/logging.inc.php
// -------------------------------------------------------------------------
// logAccess(), logLogin(), logError()
$net2ftp_messages["Unable to execute the SQL query."] = "ÊÚÐÑ ÊäÝíÐ ÇÓÊÚáÇã SQL .";
$net2ftp_messages["Unable to open the system log."] = "Unable to open the system log.";
$net2ftp_messages["Unable to write a message to the system log."] = "Unable to write a message to the system log.";

// getLogStatus(), putLogStatus()
$net2ftp_messages["Table net2ftp_log_status contains duplicate entries."] = "Table net2ftp_log_status contains duplicate entries.";
$net2ftp_messages["Table net2ftp_log_status could not be updated."] = "Table net2ftp_log_status could not be updated.";

// rotateLogs()
$net2ftp_messages["The log tables were renamed successfully."] = "The log tables were renamed successfully.";
$net2ftp_messages["The log tables could not be renamed."] = "The log tables could not be renamed.";
$net2ftp_messages["The log tables were copied successfully."] = "The log tables were copied successfully.";
$net2ftp_messages["The log tables could not be copied."] = "The log tables could not be copied.";
$net2ftp_messages["The oldest log table was dropped successfully."] = "The oldest log table was dropped successfully.";
$net2ftp_messages["The oldest log table could not be dropped."] = "The oldest log table could not be dropped.";


// -------------------------------------------------------------------------
// /includes/registerglobals.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Please enter your username and password for FTP server "] = "íÑÌì ÅÏÎÇá ÇÓã ÇáãÓÊÎÏã æ ßáãÉ ÇáãÑæÑ áÓÑÝÑ FTP ";
$net2ftp_messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "áã ÊÞã ÈßÊÇÈÉ ãÚáæãÇÊ ÇáÏÎæá Ýí äÇÝÐÉ ÇáÈæÈ ÇÈ .<br />ÇÖÛØ Úáì \"ÇáÐåÇÈ Åáì ÕÝÍÉ ÇáÏÎæá\" ÈÇáÃÓÝá .";
$net2ftp_messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "ÇáÏÎæá Åáì áæÍÉ ÇáÊÍßã ÛíÑ ãÊÇÍ , ÈÓÈÈ ÚÏã ÊÚííä ßáãÉ ãÑæÑ Ýí ÇáãáÝ settings.inc.php . ÃÏÎá ßáãÉ ÇáãÑæÑ Ýí ÇáãáÝ , Ëã ÃÚÏ ÊÍãíá åÐå ÇáÕÝÍÉ .";
$net2ftp_messages["Please enter your Admin username and password"] = "íÑÌì ÅÏÎÇá ÇÓã ÇáãÓÊÎÏã æ ßáãÉ ÇáãÑæÑ ÇáÅÏÇÑíÉ";
$net2ftp_messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "áã ÊÞã ÈßÊÇÈÉ ãÚáæãÇÊ ÇáÏÎæá Ýí äÇÝÐÉ ÇáÈæÈ ÇÈ .<br />ÇÖÛØ Úáì \"ÇáÐåÇÈ Åáì ÕÝÍÉ ÇáÏÎæá\" ÈÇáÃÓÝá .";
$net2ftp_messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "ÎØÃ Ýí ÇÓã ÇáãÓÊÎÏã Ãæ ßáãÉ ÇáãÑæÑ ááæÍÉ ÇáÊÍßã . ÇÓã ÇáãÓÊÎÏã æ ßáãÉ ÇáãÑæÑ íãßä ÊÚííäåÇ Ýí ÇáãáÝ settings.inc.php .";


// -------------------------------------------------------------------------
// /skins/skins.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Blue"] = "Blue";
$net2ftp_messages["Grey"] = "Grey";
$net2ftp_messages["Black"] = "Black";
$net2ftp_messages["Yellow"] = "Yellow";
$net2ftp_messages["Pastel"] = "Pastel";

// getMime()
$net2ftp_messages["Directory"] = "ÇáÏáíá";
$net2ftp_messages["Symlink"] = "Symlink";
$net2ftp_messages["ASP script"] = "ãáÝ ASP";
$net2ftp_messages["Cascading Style Sheet"] = "æÑÞÉ ÃäãÇØ ãÊÊÇáíÉ";
$net2ftp_messages["HTML file"] = "ãáÝ HTML";
$net2ftp_messages["Java source file"] = "ãáÝ ãÕÏÑ Java";
$net2ftp_messages["JavaScript file"] = "ãáÝ JavaScript";
$net2ftp_messages["PHP Source"] = "ãÕÏÑ PHP";
$net2ftp_messages["PHP script"] = "ãáÝ PHP";
$net2ftp_messages["Text file"] = "ãáÝ äÕí";
$net2ftp_messages["Bitmap file"] = "ÕæÑÉ äÞØíÉ Bitmap";
$net2ftp_messages["GIF file"] = "ÕæÑÉ GIF";
$net2ftp_messages["JPEG file"] = "ÕæÑÉ JPEG";
$net2ftp_messages["PNG file"] = "ÕæÑÉ PNG";
$net2ftp_messages["TIF file"] = "ÕæÑÉ TIF";
$net2ftp_messages["GIMP file"] = "ãáÝ GIMP";
$net2ftp_messages["Executable"] = "ãáÝ ÊäÝíÐí";
$net2ftp_messages["Shell script"] = "ãáÝ Shell";
$net2ftp_messages["MS Office - Word document"] = "MS Office - ãÓÊäÏ Word";
$net2ftp_messages["MS Office - Excel spreadsheet"] = "MS Office - ÌÏæá Excel";
$net2ftp_messages["MS Office - PowerPoint presentation"] = "MS Office - ÚÑÖ ÊÞÏíãí PowerPoint";
$net2ftp_messages["MS Office - Access database"] = "MS Office - ÞÇÚÏÉ ÈíÇäÇÊ Access";
$net2ftp_messages["MS Office - Visio drawing"] = "MS Office - ãÎØØ Visio";
$net2ftp_messages["MS Office - Project file"] = "MS Office - ãáÝ ãÔÑæÚ";
$net2ftp_messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - ãÓÊäÏ Writer 6.0";
$net2ftp_messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - ÞÇáÈ Writer 6.0";
$net2ftp_messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - ÌÏæá Calc 6.0";
$net2ftp_messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - ÞÇáÈ Calc 6.0";
$net2ftp_messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - ãÓÊäÏ Draw 6.0";
$net2ftp_messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - ÞÇáÈ Draw 6.0";
$net2ftp_messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - ÚÑÖ ÊÞÏíãí Impress 6.0";
$net2ftp_messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - ÞÇáÈ Impress 6.0";
$net2ftp_messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - ÞÇáÈ ÚÇã Writer 6.0";
$net2ftp_messages["OpenOffice - Math 6.0 document"] = "OpenOffice - ãÓÊäÏ Math 6.0";
$net2ftp_messages["StarOffice - StarWriter 5.x document"] = "StarOffice - ãÓÊäÏ StarWriter 5.x";
$net2ftp_messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - ãÓÊäÏ ÚÇã StarWriter 5.x";
$net2ftp_messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - ÌÏæá StarCalc 5.x";
$net2ftp_messages["StarOffice - StarDraw 5.x document"] = "StarOffice - ãÓÊäÏ StarDraw 5.x";
$net2ftp_messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - ÚÑÖ ÊÞÏíãí StarImpress 5.x";
$net2ftp_messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - ãáÝ StarImpress Packed 5.x";
$net2ftp_messages["StarOffice - StarMath 5.x document"] = "StarOffice - ãÓÊäÏ StarMath 5.x";
$net2ftp_messages["StarOffice - StarChart 5.x document"] = "StarOffice - ãÓÊäÏ StarChart 5.x";
$net2ftp_messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - ãáÝ ÈÑíÏ StarMail 5.x";
$net2ftp_messages["Adobe Acrobat document"] = "ãÓÊäÏ Adobe Acrobat";
$net2ftp_messages["ARC archive"] = "ÃÑÔíÝ ARC";
$net2ftp_messages["ARJ archive"] = "ÃÑÔíÝ ARJ";
$net2ftp_messages["RPM"] = "RPM";
$net2ftp_messages["GZ archive"] = "ÃÑÔíÝ GZ";
$net2ftp_messages["TAR archive"] = "ÃÑÔíÝ TAR";
$net2ftp_messages["Zip archive"] = "ÃÑÔíÝ Zip";
$net2ftp_messages["MOV movie file"] = "ãáÝ ÝíÏíæ MOV";
$net2ftp_messages["MPEG movie file"] = "ãáÝ ÝíÏíæ MPEG movie file";
$net2ftp_messages["Real movie file"] = "ãáÝ ÝíÏíæ Real";
$net2ftp_messages["Quicktime movie file"] = "ãáÝ ÝíÏíæ Quicktime";
$net2ftp_messages["Shockwave flash file"] = "ãáÝ ÝáÇÔ Shockwave";
$net2ftp_messages["Shockwave file"] = "ãáÝ Shockwave";
$net2ftp_messages["WAV sound file"] = "ãáÝ ãæÌÉ ÕæÊíÉ";
$net2ftp_messages["Font file"] = "ãáÝ ÎØ";
$net2ftp_messages["%1\$s File"] = "ãáÝ %1\$s";
$net2ftp_messages["File"] = "ãáÝ";

// getAction()
$net2ftp_messages["Back"] = "ÎØæÉ ááÎáÝ";
$net2ftp_messages["Submit"] = "ÇÚÊãÏ ÇáÈíÇäÇÊ";
$net2ftp_messages["Refresh"] = "ÊÍÏíË ÇáÕÝÍÉ";
$net2ftp_messages["Details"] = "ÇáÊÝÇÕíá";
$net2ftp_messages["Icons"] = "ÇáÑãæÒ";
$net2ftp_messages["List"] = "ÇáÞÇÆãÉ";
$net2ftp_messages["Logout"] = "ÊÓÌíá ÇáÎÑæÌ";
$net2ftp_messages["Help"] = "ãÓÇÚÏÉ";
$net2ftp_messages["Bookmark"] = "ÃÖÝ Åáì ÇáãÝÖáÉ";
$net2ftp_messages["Save"] = "ÍÝÙ";
$net2ftp_messages["Default"] = "ÇáÇÝÊÑÇÖí";


// -------------------------------------------------------------------------
// /skins/[skin]/header.template.php and footer.template.php
// -------------------------------------------------------------------------
$net2ftp_messages["Help Guide"] = "Ïáíá ÇáãÓÇÚÏÉ";
$net2ftp_messages["Forums"] = "ÇáãäÊÏíÇÊ";
$net2ftp_messages["License"] = "ÇáÊÑÎíÕ";
$net2ftp_messages["Powered by"] = "Powered by";
$net2ftp_messages["You are now taken to the net2ftp forums. These forums are for net2ftp related topics only - not for generic webhosting questions."] = "ÓíÊã äÞáß ÇáÂä Åáì ãäÊÏíÇÊ net2ftp . åÐå ÇáãäÊÏíÇÊ ãÊÎÕÕÉ ÈãæÇÖíÚ ÈÑäÇãÌ net2ftp ÝÞØ  - æ áíÓ áÃÓÆáÉ ÇáÇÓÊÖÇÝÉ ÇáÚÇãÉ .";
$net2ftp_messages["Standard"] = "Standard";
$net2ftp_messages["Mobile"] = "Mobile";

// -------------------------------------------------------------------------
// Admin module
if ($net2ftp_globals["state"] == "admin") {
// -------------------------------------------------------------------------

// /modules/admin/admin.inc.php
$net2ftp_messages["Admin functions"] = "ÇáÎíÇÑÇÊ ÇáÅÏÇÑíÉ";

// /skins/[skin]/admin1.template.php
$net2ftp_messages["Version information"] = "ãÚáæãÇÊ ÇáÅÕÏÇÑ";
$net2ftp_messages["This version of net2ftp is up-to-date."] = "åÐÇ ÇáÅÕÏÇÑ ãä net2ftp ÞÇÈá ááÊÍÏíË .";
$net2ftp_messages["The latest version information could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "ÊÚÐÑ ÌáÈ ÂÎÑ ãÚáæãÇÊ ÇáÅÕÏÇÑ ãä ÓÑÝÑ net2ftp . ÊÝÍÕ ÅÚÏÇÏÇÊ ÇáÃãÇä Ýí ãÓÊÚÑÖß , ÍíË ÊãäÚ ÊÍãíá ãáÝ ÕÛíÑ ãä ÓÑÝÑ net2ftp.com .";
$net2ftp_messages["Logging"] = "ÇáÏÎæá";
$net2ftp_messages["Date from:"] = "ÇáÊÇÑíÎ ãä »";
$net2ftp_messages["to:"] = "Åáì »";
$net2ftp_messages["Empty logs"] = "ÅÝÑÇÛ ÇáÓÌá";
$net2ftp_messages["View logs"] = "ÚÑÖ ÇáÓÌá";
$net2ftp_messages["Go"] = "ÇÐåÈ";
$net2ftp_messages["Setup MySQL tables"] = "ÅÚÏÇÏ ÌÏÇæá MySQL";
$net2ftp_messages["Create the MySQL database tables"] = "ÅäÔÇÁ ÌÏÇæá ÞÇÚÏÉ ÇáÈíÇäÇÊ MySQL";

} // end admin

// -------------------------------------------------------------------------
// Admin_createtables module
if ($net2ftp_globals["state"] == "admin_createtables") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_createtables.inc.php
$net2ftp_messages["Admin functions"] = "ÇáÎíÇÑÇÊ ÇáÅÏÇÑíÉ";
$net2ftp_messages["The handle of file %1\$s could not be opened."] = "ÇÓã ÇáãáÝ %1\$s áÇ íãßä ÝÊÍå .";
$net2ftp_messages["The file %1\$s could not be opened."] = "ÊÚÐÑ ÝÊÍ ÇáãáÝ %1\$s .";
$net2ftp_messages["The handle of file %1\$s could not be closed."] = "ÇÓã ÇáãáÝ %1\$s áÇ íãßä ÝÊÍå .";
$net2ftp_messages["The connection to the server <b>%1\$s</b> could not be set up. Please check the database settings you've entered."] = "ÊÚÐÑ ÅÚÏÇÏ ÇáÇÊÕÇá Åáì ÇáÓÑÝÑ <b>%1\$s</b> . íÑÌì ÇáÊÃßÏ ãä ãÚáæãÇÊ ÞÇÚÏÉ ÇáÈíÇäÇÊ ÇáÊí ÇÏÎáÊåÇ .";
$net2ftp_messages["Unable to select the database <b>%1\$s</b>."] = "ÊÚÐÑ ÊÍÏíÏ ÞÇÚÏÉ ÇáÈíÇäÇÊ <b>%1\$s</b>.";
$net2ftp_messages["The SQL query nr <b>%1\$s</b> could not be executed."] = "ÊÚÐÑ ÊäÝíÐ ÇÓÊÚáÇã SQL  nr <b>%1\$s</b> .";
$net2ftp_messages["The SQL query nr <b>%1\$s</b> was executed successfully."] = "Êã ÊäÝíÐ ÇÓÊÚáÇã SQL nr <b>%1\$s</b> ÈäÌÇÍ .";

// /skins/[skin]/admin_createtables1.template.php
$net2ftp_messages["Please enter your MySQL settings:"] = "íÑÌì ÅÏÎÇá ÅÚÏÇÏÇÊ ÞÇÚÏÉ ÇáÈíÇäÇÊ MySQL »";
$net2ftp_messages["MySQL username"] = "ÇÓã ÇáãÓÊÎÏã MySQL";
$net2ftp_messages["MySQL password"] = "ßáãÉ ÇáãÑæÑ MySQL";
$net2ftp_messages["MySQL database"] = "ÞÇÚÏÉ ÇáÈíÇäÇÊ MySQL";
$net2ftp_messages["MySQL server"] = "ÓÑÝÑ MySQL";
$net2ftp_messages["This SQL query is going to be executed:"] = "ÇÓÊÚáÇã SQL ÌÇåÒ ááÊäÝíÐ »";
$net2ftp_messages["Execute"] = "ÊäÝíÐ ÇáÇÓÊÚáÇã";

// /skins/[skin]/admin_createtables2.template.php
$net2ftp_messages["Settings used:"] = "ÇáÅÚÏÇÏÇÊ ÇáãÓÊÎÏãÉ »";
$net2ftp_messages["MySQL password length"] = "ÚãÞ ßáãÉ ãÑæÑ MySQL";
$net2ftp_messages["Results:"] = "ÇáäÊÇÆÌ »";

} // end admin_createtables


// -------------------------------------------------------------------------
// Admin_viewlogs module
if ($net2ftp_globals["state"] == "admin_viewlogs") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_viewlogs.inc.php
$net2ftp_messages["Admin functions"] = "ÇáÎíÇÑÇÊ ÇáÅÏÇÑíÉ";
$net2ftp_messages["Unable to execute the SQL query <b>%1\$s</b>."] = "ÊÚÐÑ ÊäÝíÐ ÇÓÊÚáÇã SQL <b>%1\$s</b>.";
$net2ftp_messages["No data"] = "áÇ íæÌÏ ÈíÇäÇÊ";

} // end admin_viewlogs


// -------------------------------------------------------------------------
// Admin_emptylogs module
if ($net2ftp_globals["state"] == "admin_emptylogs") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_emptylogs.inc.php
$net2ftp_messages["Admin functions"] = "ÇáÎíÇÑÇÊ ÇáÅÏÇÑíÉ";
$net2ftp_messages["The table <b>%1\$s</b> was emptied successfully."] = "Êã ÅÝÑÇÛ ÇáÌÏæá <b>%1\$s</b> ÈäÌÇÍ !";
$net2ftp_messages["The table <b>%1\$s</b> could not be emptied."] = "ÊÚÐÑ ÅÝÑÇÛ ÇáÌÏæá <b>%1\$s</b> !";
$net2ftp_messages["The table <b>%1\$s</b> was optimized successfully."] = "Êã ÅÕáÇÍ ÇáÌÏæá <b>%1\$s</b> ÈäÌÇÍ !";
$net2ftp_messages["The table <b>%1\$s</b> could not be optimized."] = "ÊÚÐÑ ÅÕáÇÍ ÇáÌÏæá <b>%1\$s</b> !";

} // end admin_emptylogs


// -------------------------------------------------------------------------
// Advanced module
if ($net2ftp_globals["state"] == "advanced") {
// -------------------------------------------------------------------------

// /modules/advanced/advanced.inc.php
$net2ftp_messages["Advanced functions"] = "ÇáÎíÇÑÇÊ ÇáÅÏÇÑíÉ";

// /skins/[skin]/advanced1.template.php
$net2ftp_messages["Go"] = "ÇÐåÈ";
$net2ftp_messages["Disabled"] = "ãÚØá";
$net2ftp_messages["Advanced FTP functions"] = "æÙÇÆÝ FTP ÇáãÊÞÏãÉ";
$net2ftp_messages["Send arbitrary FTP commands to the FTP server"] = "ÅÑÓÇá ÃãÑ FTP ÊÍßãí Åáì ÓÑÝÑ FTP";
$net2ftp_messages["This function is available on PHP 5 only"] = "åÐå ÇáæÙíÝÉ ãÊæÝÑÉ ÝÞØ Úáì PHP 5";
$net2ftp_messages["Troubleshooting functions"] = "æÙÇÆÝ ÊÊÈÚ ÇáÃÎØÇÁ";
$net2ftp_messages["Troubleshoot net2ftp on this webserver"] = "ÊÊÈÚ ÃÎØÇÁ net2ftp Úáì ÓÑÝ ÇáæíÈ åÐÇ";
$net2ftp_messages["Troubleshoot an FTP server"] = "ÊÊÈÚ ÃÎØÇÁ ÓÑÝÑ FTP";
$net2ftp_messages["Test the net2ftp list parsing rules"] = "ÇÎÊÈÇÑ ÞÇÆãÉ ÞæÇäíä ÊÚÇÈíÑ net2ftp";
$net2ftp_messages["Translation functions"] = "æÙÇÆÝ ÇáÊÑÌãÉ";
$net2ftp_messages["Introduction to the translation functions"] = "ãÞÏãÉ Åáì æÙÇÆÝ ÇáÊÑÌãÉ";
$net2ftp_messages["Extract messages to translate from code files"] = "ÇÓÊÎÑÇÌ ÇáÑÓÇÆá áÊÑÌãÊåÇ ãä ãáÝÇÊ ÇáßæÏ";
$net2ftp_messages["Check if there are new or obsolete messages"] = "ÇáÊÝÍÕ Úä æÌæÏ ÑÓÇÆá ÌÏíÏÉ Ãæ ÈÇØáÉ";

$net2ftp_messages["Beta functions"] = "æÙÇÆÝ ÊÌÑíÈíÉ";
$net2ftp_messages["Send a site command to the FTP server"] = "ÅÑÓÇá ÃãÑ ÇáãæÞÚ ÅáÉ ÓÑÝÑ FTP";
$net2ftp_messages["Apache: password-protect a directory, create custom error pages"] = "Apache » ÍãÇíÉ Ïáíá ÈßáãÉ ãÑæÑ , ÅäÔÇÁ ÕÝÍÇÊ ÃÎØÇÁ ãÎÕÕÉ";
$net2ftp_messages["MySQL: execute an SQL query"] = "MySQL » ÊäÝíÐ ÇÓÊÚáÇã SQL";


// advanced()
$net2ftp_messages["The site command functions are not available on this webserver."] = "æÙÇÆÝ ÃãÑÇ áãæÞÚ ÛíÑ ãÊÇÍÉ Úáì åÐÇ ÇáæíÈ ÓÑÝÑ .";
$net2ftp_messages["The Apache functions are not available on this webserver."] = "æÙÇÆÝ ÃÈÇÊÔí ÛíÑ ãÊÇÍÉ Úáì åÐÇ ÇáæíÈ ÓÑÝÑ .";
$net2ftp_messages["The MySQL functions are not available on this webserver."] = "æÙÇÆÝ MySQL ÛíÑ ãÊÇÍÉ Úáì åÐÇ ÇáæíÈ ÓÑÝÑ .";
$net2ftp_messages["Unexpected state2 string. Exiting."] = "ÍÇáÉ 2 ÛíÑ ãÞÈæáÉ . ãæÌæÏ .";

} // end advanced


// -------------------------------------------------------------------------
// Advanced_ftpserver module
if ($net2ftp_globals["state"] == "advanced_ftpserver") {
// -------------------------------------------------------------------------

// /modules/advanced_ftpserver/advanced_ftpserver.inc.php
$net2ftp_messages["Troubleshoot an FTP server"] = "ÊÊÈÚ ÃÎØÇÁ ÓÑÝÑ FTP";

// /skins/[skin]/advanced_ftpserver1.template.php
$net2ftp_messages["Connection settings:"] = "ÅÚÏÇÏÇÊ ÇáÇÊÕÇá »";
$net2ftp_messages["FTP server"] = "ÓÑÝÑ FTP";
$net2ftp_messages["FTP server port"] = "ãäÝÐ ÓÑÝÑ FTP";
$net2ftp_messages["Username"] = "ÇÓã ÇáãÓÊÎÏã";
$net2ftp_messages["Password"] = "ßáãÉ ÇáãÑæÑ";
$net2ftp_messages["Password length"] = "Øæá ßáãÉ ÇáãÑæÑ";
$net2ftp_messages["Passive mode"] = "äãØ Passive ÇáÎãæá";
$net2ftp_messages["Directory"] = "ÇáÏáíá";
$net2ftp_messages["Printing the result"] = "ØÈÇÚÉ ÇáäÊíÌÉ";

// /skins/[skin]/advanced_ftpserver2.template.php
$net2ftp_messages["Connecting to the FTP server: "] = "ÇáÇÊÕÇá ÈÓÑÝÑ FTP » ";
$net2ftp_messages["Logging into the FTP server: "] = "ÇáÏÎæá Åáì ÓÑÝÑ FTP » ";
$net2ftp_messages["Setting the passive mode: "] = "ÅÚÏÇÏ äãØ passive ÇáÎãæá » ";
$net2ftp_messages["Getting the FTP server system type: "] = "ÏÎæá äãØ äÙÇã ÓÑÝÑ FTP » ";
$net2ftp_messages["Changing to the directory %1\$s: "] = "ÇáÊÛííÑ Åáì ÇáÏáíá %1\$s » ";
$net2ftp_messages["The directory from the FTP server is: %1\$s "] = "ÇáÏáíá Ýí ÓÑÝÑ FTP åæ » %1\$s ";
$net2ftp_messages["Getting the raw list of directories and files: "] = "ÇáÍÕæá Úáì ÞÇÆãÉ ÇáÃÏáÉ æ ÇáãáÝÇÊ » ";
$net2ftp_messages["Trying a second time to get the raw list of directories and files: "] = "ãÍÇæáÉ ËÇäíÉ ááÍÕæá Úáì ÞÇÆãÉ ÇáÃÏáÉ æ ÇáãáÝÇÊ » ";
$net2ftp_messages["Closing the connection: "] = "ÅÛáÇÞ ÇáÇÊÕÇá » ";
$net2ftp_messages["Raw list of directories and files:"] = "ÞÇÆãÉ ÇáÃÏáÉ æ ÇáãáÝÇÊ »";
$net2ftp_messages["Parsed list of directories and files:"] = "ÞÇÆãÉ ÊÚÇÈíÑ ÇáÃÏáÉ æ ÇáãáÝÇÊ »";

$net2ftp_messages["OK"] = "äÌÇÍ";
$net2ftp_messages["not OK"] = "ÝÔá";

} // end advanced_ftpserver


// -------------------------------------------------------------------------
// Advanced_parsing module
if ($net2ftp_globals["state"] == "advanced_parsing") {
// -------------------------------------------------------------------------

$net2ftp_messages["Test the net2ftp list parsing rules"] = "ÇÎÊÈÇÑ ÞÇÆãÉ ÞæÇäíä ÊÚÇÈíÑ net2ftp";
$net2ftp_messages["Sample input"] = "ÇÎÊÈÇÑ ÇáÏÎá";
$net2ftp_messages["Parsed output"] = "ÊÚÈíÑ ÇáÎÑÌ";

} // end advanced_parsing


// -------------------------------------------------------------------------
// Advanced_webserver module
if ($net2ftp_globals["state"] == "advanced_webserver") {
// -------------------------------------------------------------------------

$net2ftp_messages["Troubleshoot your net2ftp installation"] = "ÊÊÈÚ ÃÎØÇÁ ÊÑßíÈ net2ftp";
$net2ftp_messages["Printing the result"] = "ØÈÇÚÉ ÇáäÊíÌÉ";

$net2ftp_messages["Checking if the FTP module of PHP is installed: "] = "ÇáÊÍÞÞ ãä ÊÑßíÈ æÙíÝÉ FTP Ýí PHP » ";
$net2ftp_messages["yes"] = "äÚã";
$net2ftp_messages["no - please install it!"] = "áÇ - íÑÌì ÊÑßíÈåÇ !";

$net2ftp_messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "ÇáÊÍÞÞ ãä ÕáÇÍíÇÊ ÇáÏáíá Úáì ÓÑÞÑ ÇáæíÈ » ÓíÊã ßÊÇÈÉ ãáÝ ÕÛíÑ Åáì ÇáãÌáÏ /temp Ëã ÍÐÝå .";
$net2ftp_messages["Creating filename: "] = "ÅäÔÇÁ ÇÓã ÇáãáÝ » ";
$net2ftp_messages["OK. Filename: %1\$s"] = "äÌÇÍ . ÇÓã ÇáãáÝ » %1\$s";
$net2ftp_messages["not OK"] = "ÝÔá";
$net2ftp_messages["OK"] = "äÌÇÍ";
$net2ftp_messages["not OK. Check the permissions of the %1\$s directory"] = "ÝÔá . ÊÃßÏ ãä ÕáÇÍíÇÊ ÇáÏáíá %1\$s ";
$net2ftp_messages["Opening the file in write mode: "] = "ÝÊÍ ÇáãáÝ Ýí äãØ ÇáßÊÇÈÉ » ";
$net2ftp_messages["Writing some text to the file: "] = "ßÊÇÈÉ ÈÚÖ ÇáäÕ Ýí ÇáãáÝ » ";
$net2ftp_messages["Closing the file: "] = "ÅÛáÇÞ ÇáãáÝ » ";
$net2ftp_messages["Deleting the file: "] = "ÍÐÝ ÇáãáÝ » ";

$net2ftp_messages["Testing the FTP functions"] = "ÇÎÊÈÇÑ æÙÇÆÝ FTP";
$net2ftp_messages["Connecting to a test FTP server: "] = "ÇáÇÊÕÇá áÇÎÊÈÇÑ ÓÑÝÑ FTP » ";
$net2ftp_messages["Connecting to the FTP server: "] = "ÇáÇÊÕÇá ÈÓÑÝÑ FTP » ";
$net2ftp_messages["Logging into the FTP server: "] = "ÇáÏÎæá Åáì ÓÑÝÑ FTP » ";
$net2ftp_messages["Setting the passive mode: "] = "ÅÚÏÇÏ äãØ passive ÇáÎãæá » ";
$net2ftp_messages["Getting the FTP server system type: "] = "ÏÎæá äãØ äÙÇã ÓÑÝÑ FTP » ";
$net2ftp_messages["Changing to the directory %1\$s: "] = "ÇáÊÛííÑ Åáì ÇáÏáíá %1\$s » ";
$net2ftp_messages["The directory from the FTP server is: %1\$s "] = "ÇáÏáíá Ýí ÓÑÝÑ FTP åæ » %1\$s ";
$net2ftp_messages["Getting the raw list of directories and files: "] = "ÇáÍÕæá Úáì ÞÇÆãÉ ÇáÃÏáÉ æ ÇáãáÝÇÊ » ";
$net2ftp_messages["Trying a second time to get the raw list of directories and files: "] = "ãÍÇæáÉ ËÇäíÉ ááÍÕæá Úáì ÞÇÆãÉ ÇáÃÏáÉ æ ÇáãáÝÇÊ » ";
$net2ftp_messages["Closing the connection: "] = "ÅÛáÇÞ ÇáÇÊÕÇá » ";
$net2ftp_messages["Raw list of directories and files:"] = "ÞÇÆãÉ ÇáÃÏáÉ æ ÇáãáÝÇÊ »";
$net2ftp_messages["Parsed list of directories and files:"] = "ÞÇÆãÉ ÊÚÇÈíÑ ÇáÃÏáÉ æ ÇáãáÝÇÊ »";
$net2ftp_messages["OK"] = "äÌÇÍ";
$net2ftp_messages["not OK"] = "ÝÔá";

} // end advanced_webserver


// -------------------------------------------------------------------------
// Bookmark module
if ($net2ftp_globals["state"] == "bookmark") {
// -------------------------------------------------------------------------

$net2ftp_messages["Drag and drop one of the links below to the bookmarks bar"] = "Drag and drop one of the links below to the bookmarks bar";
$net2ftp_messages["Right-click on one of the links below and choose \"Add to Favorites...\""] = "Right-click on one of the links below and choose \"Add to Favorites...\"";
$net2ftp_messages["Right-click on one the links below and choose \"Add Link to Bookmarks...\""] = "Right-click on one the links below and choose \"Add Link to Bookmarks...\"";
$net2ftp_messages["Right-click on one of the links below and choose \"Bookmark link...\""] = "Right-click on one of the links below and choose \"Bookmark link...\"";
$net2ftp_messages["Right-click on one of the links below and choose \"Bookmark This Link...\""] = "Right-click on one of the links below and choose \"Bookmark This Link...\"";
$net2ftp_messages["One click access (net2ftp won't ask for a password - less safe)"] = "One click access (net2ftp won't ask for a password - less safe)";
$net2ftp_messages["Two click access (net2ftp will ask for a password - safer)"] = "Two click access (net2ftp will ask for a password - safer)";
$net2ftp_messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "ãáÇÍÙÉ » ÚäÏ ÇÓÊÎÏÇã ÇáÇÎÊÕÇÑ ãä ÇáãÝÖáÉ , ÓíØáÈ ãäß ÈæÇÓØÉ äÇÝÐÉ ÈæÈ ÇÈ ÅÏÎÇá ÇÓã ÇáãÓÊÎÏã æ ßáãÉ ÇáãÑæÑ .";

} // end bookmark


// -------------------------------------------------------------------------
// Browse module
if ($net2ftp_globals["state"] == "browse") {
// -------------------------------------------------------------------------

// /modules/browse/browse.inc.php
$net2ftp_messages["Choose a directory"] = "ÇÎÊÑ Ïáíá";
$net2ftp_messages["Please wait..."] = "íÑÌì ÇáÇäÊÙÇÑ ...";

// browse()
$net2ftp_messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "ÇáÃÏáÉ ÇáÊí ÊÍÊæí ÇÓãÇÆåÇ Úáì \' áÇ íãßä ÚÑÖåÇ ÈÔßá ÕÍíÍ . íãßä ÝÞØ ÍÐÝåÇ . íÑÌì ÇáÚæÏÉ ááÎáÝ æ ÇÎÊíÇÑ Ïáíá ÝÑÚí ÂÎÑ .";

$net2ftp_messages["Daily limit reached: you will not be able to transfer data"] = "ÇáÍÕÉ ÇáíæãíÉ ÇäÊåÊ » áÇ íãßäß ãÊÇÈÚÉ ÊÑÍíá ÇáÈíÇäÇÊ .";
$net2ftp_messages["In order to guarantee the fair use of the web server for everyone, the data transfer volume and script execution time are limited per user, and per day. Once this limit is reached, you can still browse the FTP server but not transfer data to/from it."] = "áÖãÇä ÇÓÊÎÏÇã ÇáÓÑÝÑ æíÈ ááÌãíÚ , Êã ÊÍÏíÏ ÍÕÉ íæãíÉ áÊÑÍíá ÇáÈíÇäÇÊ æ ÇáãáÝÇÊ áßá ãÓÊÎÏã . ÚäÏ ÇÓÊåáÇßß áåÐå ÇáÍÕÉ , ÊÓØíÚ ÇÓÊÚÑÇÖ ÓÑÝÑ FTP æ áßä áÇ íãßäß ãÊÇÈÚÉ äÞá ÇáÈíÇäÇÊ ãä æ Åáì .";
$net2ftp_messages["If you need unlimited usage, please install net2ftp on your own web server."] = "ÅÐÇ ßäÊ ÊÑíÏ ÇÓÊÎÏÇã åÐå ÇÎÏãÉ ÈÏæä ÍÏæÏ , íãßäß ÊÑßíÈ net2ftp Úáì ÓÑÝÑß ÇáÎÇÕ .";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$net2ftp_messages["New dir"] = "Ïáíá ÌÏíÏ";
$net2ftp_messages["New file"] = "ãáÝ ÌÏíÏ";
$net2ftp_messages["HTML templates"] = "ÞæÇáÈ HTML";
$net2ftp_messages["Upload"] = "ÇáÑÝÚ";
$net2ftp_messages["Java Upload"] = "ÇáÑÝÚ ÈÜ Java";
$net2ftp_messages["Flash Upload"] = "ÑÝÚ ÈæÇÓØÉ ÇáÝáÇÔ";
$net2ftp_messages["Install"] = "ÇáÊÑßíÈ";
$net2ftp_messages["Advanced"] = "ãÊÞÏã";
$net2ftp_messages["Copy"] = "äÓÎ";
$net2ftp_messages["Move"] = "äÞá";
$net2ftp_messages["Delete"] = "ÍÐÝ";
$net2ftp_messages["Rename"] = "ÅÚÇÏÉ ÊÓãíÉ";
$net2ftp_messages["Chmod"] = "ÊÕÑíÍ";
$net2ftp_messages["Download"] = "ÊÍãíá";
$net2ftp_messages["Unzip"] = "ÇÓÊÎÑÇÌ";
$net2ftp_messages["Zip"] = "Zip";
$net2ftp_messages["Size"] = "ÇáÍÌã";
$net2ftp_messages["Search"] = "ÈÍË";
$net2ftp_messages["Go to the parent directory"] = "ÇáÐåÇÈ Åáì ÇáãÌáÏ ÇáÃÕá";
$net2ftp_messages["Go"] = "ÇÐåÈ";
$net2ftp_messages["Transform selected entries: "] = "ÊÍæíá ÇáÚäÇÕÑ ÇáãÍÏÏÉ » ";
$net2ftp_messages["Transform selected entry: "] = "ÊÍæíá ÇáÚäÕÑ ÇáãÍÏÏ » ";
$net2ftp_messages["Make a new subdirectory in directory %1\$s"] = "ÅäÔÇÁ Ïáíá ÝÑÚí ÌÏíÏ Ýí ÇáÏáíá %1\$s";
$net2ftp_messages["Create a new file in directory %1\$s"] = "ÅäÔÇÁ ãáÝ ÌÏíÏ Ýí ÇáÏáíá %1\$s";
$net2ftp_messages["Create a website easily using ready-made templates"] = "ÅäÔÇÁ ÇáãæÇÞÚ Óåá ÈÇÓÊÎÏÇã ÇáÞæÇáÈ ÇáÌÇåÒÉ";
$net2ftp_messages["Upload new files in directory %1\$s"] = "ÑÝÚ ãáÝÇÊ ÌÏíÏ Åáì ÇáÏáíá %1\$s";
$net2ftp_messages["Upload directories and files using a Java applet"] = "ÑÝÚ ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ ÈæÇÓØÉ Java applet";
$net2ftp_messages["Upload files using a Flash applet"] = "ÑÝÚ ÇáãáÝÇÊ ÈæÇÓØÉ Flash applet";
$net2ftp_messages["Install software packages (requires PHP on web server)"] = "ÊÑßíÈ ÍÒãÉ ÇáÈÑäÇãÌ ( íÊØáÈ ÓÑÝÑ PHP Úáì ÇáãæÞÚ )";
$net2ftp_messages["Go to the advanced functions"] = "ÇáÐåÇÈ Åáì ÇáæÙÇÆÝ ÇáãÊÞÏãÉ";
$net2ftp_messages["Copy the selected entries"] = "äÓÎ ÇáÚäÇÕÑ ÇáãÍÏÏÉ";
$net2ftp_messages["Move the selected entries"] = "äÞá ÇáÚäÇÕÑ ÇáãÍÏÏÉ";
$net2ftp_messages["Delete the selected entries"] = "ÍÐÝ ÇáÚäÇÕÑ ÇáãÍÏÏÉ";
$net2ftp_messages["Rename the selected entries"] = "ÅÚÇÏÉ ÊÓãíÉ ÇáÚäÇÕÑ ÇáãÍÏÏÉ";
$net2ftp_messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "ÊÕÑíÍ ÇáÚäÇÕÑ ÇáãÍÏÏÉ (íÚãá ÝÞØ Úáì ÓÑÝÑÇÊ Unix/Linux/BSD)";
$net2ftp_messages["Download a zip file containing all selected entries"] = "ÊÍãíá ãáÝ zip íÍÊæí Úáì ÌãíÚ ÇáÚäÇÕÑ ÇáãÍÏÏÉ";
$net2ftp_messages["Unzip the selected archives on the FTP server"] = "Ýß ÖÛØ ÇáÃÑÇÔíÝ ÇáãÍÏÏÉ Úáì ÓÑÝÑ FTP";
$net2ftp_messages["Zip the selected entries to save or email them"] = "ÖÛØ Zip ÇáÚäÇÕÑ ÇáãÍÏÏÉ áÍÝÙåÇ Ãæ ÅÑÓÇáåÇ ÈÇáÈÑíÏ";
$net2ftp_messages["Calculate the size of the selected entries"] = "ÍÓÇÈ ÍÌã ÇáÚäÇÕÑ ÇáãÍÏÏÉ";
$net2ftp_messages["Find files which contain a particular word"] = "ÅíÌÇÏ ÇáãáÝÇÊ ÇáÊí ÊÊÖãä ÇáßáãÉ ÌÒÆíÇð";
$net2ftp_messages["Click to sort by %1\$s in descending order"] = "ÇÖÛØ áÝÑÒ %1\$s ÈÊÑÊíÈ ÊäÇÒáí";
$net2ftp_messages["Click to sort by %1\$s in ascending order"] = "ÇÖÛØ áÝÑÒ %1\$s ÈÊÑÊíÈ ÊÕÇÚÏí";
$net2ftp_messages["Ascending order"] = "ÊÑÊíÈ ÊÕÇÚÏí";
$net2ftp_messages["Descending order"] = "ÊÑÊíÈ ÊäÇÒáí";
$net2ftp_messages["Upload files"] = "ÑÝÚ ÇáãáÝÇÊ";
$net2ftp_messages["Up"] = "ÎØæÉ Åáì ÇáÃÚáì";
$net2ftp_messages["Click to check or uncheck all rows"] = "ÇÖÛØ áÊÍÏíÏ Ãæ ÅáÛÇÁ ÊÍÏíÏ ÌãíÚ ÇáÕÝæÝ";
$net2ftp_messages["All"] = "Çáßá";
$net2ftp_messages["Name"] = "ÇáÇÓã";
$net2ftp_messages["Type"] = "ÇáäæÚ";
//$net2ftp_messages["Size"] = "Size";
$net2ftp_messages["Owner"] = "ÇáãÇáß";
$net2ftp_messages["Group"] = "ÇáãÌãæÚÉ";
$net2ftp_messages["Perms"] = "ÇáÕáÇÍíÉ";
$net2ftp_messages["Mod Time"] = "äãØ ÇáæÞÊ";
$net2ftp_messages["Actions"] = "ÇáÅÌÑÇÁÇÊ";
$net2ftp_messages["Select the directory %1\$s"] = "ÍÏÏ ÇáÏáíá %1\$s";
$net2ftp_messages["Select the file %1\$s"] = "ÍÏÏ ÇáãáÝ %1\$s";
$net2ftp_messages["Select the symlink %1\$s"] = "ÍÏÏ symlink %1\$s";
$net2ftp_messages["Go to the subdirectory %1\$s"] = "ÇáÐåÇÈ Åáì ÇáÏáíá ÇáÝÑÚí %1\$s";
$net2ftp_messages["Download the file %1\$s"] = "ÊÍãíá ÇáãáÝ %1\$s";
$net2ftp_messages["Follow symlink %1\$s"] = "ÇÊÈÚ ÇáÑÇÈØ %1\$s";
$net2ftp_messages["View"] = "ÚÑÖ";
$net2ftp_messages["Edit"] = "ÊÍÑíÑ";
$net2ftp_messages["Update"] = "ÊÍÏíË";
$net2ftp_messages["Open"] = "ÝÊÍ";
$net2ftp_messages["View the highlighted source code of file %1\$s"] = "ÚÑÖ ßæÏ ÇáãÕÏÑ ÇáããíÒ ááãáÝ %1\$s";
$net2ftp_messages["Edit the source code of file %1\$s"] = "ÊÍÑíÑ ßæÏ ÇáãÕÏÑ ááãáÝ %1\$s";
$net2ftp_messages["Upload a new version of the file %1\$s and merge the changes"] = "ÑÝÚ äÓÎÉ ÌÏíÏÉ ãä ÇáãáÝ %1\$s æ ÏãÌ ÇáÊÚÏíáÇÊ";
$net2ftp_messages["View image %1\$s"] = "ÚÑÖ ÇáÕæÑÉ %1\$s";
$net2ftp_messages["View the file %1\$s from your HTTP web server"] = "ÚÑÖ ÇáãáÝ %1\$s ÈæÇÓØÉ ÓÑÝÑ ÇáæíÈ HTTP";
$net2ftp_messages["(Note: This link may not work if you don't have your own domain name.)"] = "(ãáÇÍÙÉ » ÞÏ áÇ íÚãá åÐÇ ÇáÑÇÈØ Åä áã íßä áÏíß Ïæãíä ÎÇÕ .)";
$net2ftp_messages["This folder is empty"] = "åÐÇ ÇáãÌáÏ ÝÇÑÛ";

// printSeparatorRow()
$net2ftp_messages["Directories"] = "ÇáãÌáÏÇÊ";
$net2ftp_messages["Files"] = "ÇáãáÝÇÊ";
$net2ftp_messages["Symlinks"] = "Symlinks";
$net2ftp_messages["Unrecognized FTP output"] = "ÎÑÌ FTP ÛíÑ ãÚÑæÝ";
$net2ftp_messages["Number"] = "ÇáÚÏÏ";
$net2ftp_messages["Size"] = "ÇáÍÌã";
$net2ftp_messages["Skipped"] = "Êã ÊÎØíå";
$net2ftp_messages["Data transferred from this IP address today"] = "ÇáÈíÇäÇÊ ÇáÊí Êã ÊÑÍíáåÇ ÈæÇÓØÉ åÐÇ ÇáÃí Èí Çáíæã";
$net2ftp_messages["Data transferred to this FTP server today"] = "ÇáÈíÇäÇÊ ÇáÊí Êã ÊÑÍíáåÇ ÈæÇÓØÉ ÓÝÑ FTP åÐÇ Çáíæã";

// printLocationActions()
$net2ftp_messages["Language:"] = "ÇááÛÉ »";
$net2ftp_messages["Skin:"] = "ÇáÔßá »";
$net2ftp_messages["View mode:"] = "ØÑíÞÉ ÇáÚÑÖ »";
$net2ftp_messages["Directory Tree"] = "ÔÌÑÉ ÇáÏáíá";

// ftp2http()
$net2ftp_messages["Execute %1\$s in a new window"] = "ÊäÝíÐ %1\$s Ýí äÇÝÐÉ ÌÏíÏÉ";
$net2ftp_messages["This file is not accessible from the web"] = "áÇ íãßä ÇáæÕæá Åáì åÐÇ ÇáãáÝ ãä ÇáæíÈ";

// printDirectorySelect()
$net2ftp_messages["Double-click to go to a subdirectory:"] = "ÖÛØ ãÒÐæÌ ááÐåÇÈ Åáì ÇáÏáíá ÇáÝÑÚí";
$net2ftp_messages["Choose"] = "ÇÎÊíÇÑ";
$net2ftp_messages["Up"] = "ÎØæÉ Åáì ÇáÃÚáì";

} // end browse


// -------------------------------------------------------------------------
// Calculate size module
if ($net2ftp_globals["state"] == "calculatesize") {
// -------------------------------------------------------------------------
$net2ftp_messages["Size of selected directories and files"] = "ÍÌã ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ ÇáãÍÏÏÉ";
$net2ftp_messages["The total size taken by the selected directories and files is:"] = "ãÌãæÚ ÍÌã ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ ÇáãÍÏÏÉ åæ »";
$net2ftp_messages["The number of files which were skipped is:"] = "ÚÏÏ ÇáãáÝÇÊ ÇáÊí Êã ÊÎØíåÇ åæ »";

} // end calculatesize


// -------------------------------------------------------------------------
// Chmod module
if ($net2ftp_globals["state"] == "chmod") {
// -------------------------------------------------------------------------
$net2ftp_messages["Chmod directories and files"] = "ÊÕÑíÍ ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ";
$net2ftp_messages["Set all permissions"] = "ÊÚííä ÌãíÚ ÇáÕáÇÍíÇÊ";
$net2ftp_messages["Read"] = "ÞÑÇÁÉ";
$net2ftp_messages["Write"] = "ßÊÇÈÉ";
$net2ftp_messages["Execute"] = "ÊäÝíÐ ÇáÇÓÊÚáÇã";
$net2ftp_messages["Owner"] = "ÇáãÇáß";
$net2ftp_messages["Group"] = "ÇáãÌãæÚÉ";
$net2ftp_messages["Everyone"] = "Ãí ÔÎÕ";
$net2ftp_messages["To set all permissions to the same values, enter those permissions and click on the button \"Set all permissions\""] = "áÊÚííä ÌãíÚ ÇáÕáÇÍíÇÊ Åáì äÝÓ ÇáÞíãÉ , ÍÏÏ ÇáÕáÇÍíÇÊ Ëã ÇÖÛØ ÒÑ \"ÊÚííä ÌãíÚ ÇáÕáÇÍíÇÊ\"";
$net2ftp_messages["Set the permissions of directory <b>%1\$s</b> to: "] = "ÊÚííä ÕáÇÍíÇÊ ÇáãÌáÏ <b>%1\$s</b> Åáì » ";
$net2ftp_messages["Set the permissions of file <b>%1\$s</b> to: "] = "ÊÚííä ÕáÇÍíÇÊ ÇáãáÝ <b>%1\$s</b> Åáì » ";
$net2ftp_messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "ÊÚííä ÕáÇÍíÇÊ symlink <b>%1\$s</b> Åáì » ";
$net2ftp_messages["Chmod value"] = "ÞíãÉ ÇáÊÕÑíÍ";
$net2ftp_messages["Chmod also the subdirectories within this directory"] = "ÊØÈíÞ ÇáÊÕÑíÍ Úáì ÇáãÌáÏÇÊ ÇáÝÑÚíÉ Ýí åÐÇ ÇáãÌáÏ";
$net2ftp_messages["Chmod also the files within this directory"] = "ÊØÈíÞ ÇáÊÕÑíÍ Úáì ÇáãáÝÇÊ ÏÇÎá åÐÇ ÇáãÌáÏ";
$net2ftp_messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "ÇáÊÕÑíÍ nr <b>%1\$s</b> ÎÇÑÌ äØÇÞ 000-777. íÑÌì ÇáãÍÇæáÉ ãä ÌÏíÏ .";

} // end chmod


// -------------------------------------------------------------------------
// Clear cookies module
// -------------------------------------------------------------------------
// No messages


// -------------------------------------------------------------------------
// Copy/Move/Delete module
if ($net2ftp_globals["state"] == "copymovedelete") {
// -------------------------------------------------------------------------
$net2ftp_messages["Choose a directory"] = "ÇÎÊÑ Ïáíá";
$net2ftp_messages["Copy directories and files"] = "äÓÎ ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ";
$net2ftp_messages["Move directories and files"] = "äÞá ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ";
$net2ftp_messages["Delete directories and files"] = "ÍÐÝ ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ";
$net2ftp_messages["Are you sure you want to delete these directories and files?"] = "åá ÇäÊ ãÊÃßÏ ãä Ãäß ÊÑíÏ ÍÐÝ åÐå ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ ¿";
$net2ftp_messages["All the subdirectories and files of the selected directories will also be deleted!"] = "ÌãíÚ ÇáãÌáÏÇÊ ÇáÝÑÚíÉ æ ÇáãáÝÇÊ Ýí ÇáãÌáÏÇÊ ÇáãÍÏÏÉ ÓæÝ ÊÍÐÝ !";
$net2ftp_messages["Set all targetdirectories"] = "ÊÚííä ÌãíÚ ÇáÃÏáÉ ÇáåÏÝ";
$net2ftp_messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "áÊÚííä Ïáíá åÏÝ ãÔÊÑß , ÃÏÎá ÇáÏáíá ÇáåÏÝ Ýí ÇáÍÞá ÇáäÕí ÇáÓÇÈÞ Ëã ÇÖÛØ ÒÑ \"ÊÚííä ÌãíÚ ÇáÃÏáÉ ÇáåÏÝ\".";
$net2ftp_messages["Note: the target directory must already exist before anything can be copied into it."] = "ãáÇÍÙÉ » ÇáÏáíá ÇáåÏÝ íÌÈ Ãä íßæä ãæÌæÏ ÃæáÇð .";
$net2ftp_messages["Different target FTP server:"] = "ÓÑÝÑ FTP ÇáÂÎÑ ÇáåÏÝ »";
$net2ftp_messages["Username"] = "ÇÓã ÇáãÓÊÎÏã";
$net2ftp_messages["Password"] = "ßáãÉ ÇáãÑæÑ";
$net2ftp_messages["Leave empty if you want to copy the files to the same FTP server."] = "ÇÊÑßå ÝÇÑÛ ÅÐÇ ßäÊ ÊÑíÏ äÓÎ ÇáãáÝÇÊ Åáì äÝÓ ÓÑÝÑ FTP .";
$net2ftp_messages["If you want to copy the files to another FTP server, enter your login data."] = "ÅÐÇ ßäÊ ÊÑíÏ äÓÎ ÇáãáÝÇÊ Åáì ÓÑÝÑ FTP ÂÎÑ , ÃÏÎá ÈíÇäÇÊ ÇáÏÎæá .";
$net2ftp_messages["Leave empty if you want to move the files to the same FTP server."] = "ÇÊÑßå ÝÇÑÛ ÅÐÇ ßäÊ ÊÑíÏ äÞá ÇáãáÝÇÊ Åáì äÝÓ ÓÑÝÑ FTP .";
$net2ftp_messages["If you want to move the files to another FTP server, enter your login data."] = "ÅÐÇ ßäÊ ÊÑíÏ äÞá ÇáãáÝÇÊ Åáì ÓÑÝÑ FTP ÂÎÑ , ÃÏÎá ÈíÇäÇÊ ÇáÏÎæá .";
$net2ftp_messages["Copy directory <b>%1\$s</b> to:"] = "äÓÎ ÇáãÌáÏ <b>%1\$s</b> Åáì »";
$net2ftp_messages["Move directory <b>%1\$s</b> to:"] = "äÞá ÇáãÌáÏ <b>%1\$s</b> Åáì »";
$net2ftp_messages["Directory <b>%1\$s</b>"] = "ÇáãÌáÏ <b>%1\$s</b>";
$net2ftp_messages["Copy file <b>%1\$s</b> to:"] = "äÓÎ ÇáãáÝ <b>%1\$s</b> Åáì »";
$net2ftp_messages["Move file <b>%1\$s</b> to:"] = "äÞá ÇáãáÝ <b>%1\$s</b> Åáì »";
$net2ftp_messages["File <b>%1\$s</b>"] = "ÇáãáÝ <b>%1\$s</b>";
$net2ftp_messages["Copy symlink <b>%1\$s</b> to:"] = "äÓÎ symlink <b>%1\$s</b> Åáì »";
$net2ftp_messages["Move symlink <b>%1\$s</b> to:"] = "äÞá symlink <b>%1\$s</b> Åáì »";
$net2ftp_messages["Symlink <b>%1\$s</b>"] = "Symlink <b>%1\$s</b>";
$net2ftp_messages["Target directory:"] = "ÇáãÌáÏ ÇáåÏÝ »";
$net2ftp_messages["Target name:"] = "ÇÓã ÇáåÏÝ »";
$net2ftp_messages["Processing the entries:"] = "ãÚÇáÌÉ ÇáÚäÇÕÑ »";

} // end copymovedelete


// -------------------------------------------------------------------------
// Download file module
// -------------------------------------------------------------------------
// No messages


// -------------------------------------------------------------------------
// EasyWebsite module
if ($net2ftp_globals["state"] == "easyWebsite") {
// -------------------------------------------------------------------------
$net2ftp_messages["Create a website in 4 easy steps"] = "ÅäÔÇÁ ãæÞÚ Ýí 4 ÎØæÇÊ ÓåáÉ";
$net2ftp_messages["Template overview"] = "ÎáÇÕÉ ÇáÞÇáÈ";
$net2ftp_messages["Template details"] = "ÊÝÇÕíá ÇáÞÇáÈ";
$net2ftp_messages["Files are copied"] = "Êã äÓÎ ÇáãáÝÇÊ";
$net2ftp_messages["Edit your pages"] = "ÊÍÑíÑ ÕÝÍÇÊß";

// Screen 1 - printTemplateOverview
$net2ftp_messages["Click on the image to view the details of a template."] = "ÇÖÛØ Úáì ÇáÕæÑÉ áÚÑÖ ÊÝÇÕíá ÇáÞÇáÈ .";
$net2ftp_messages["Back to the Browse screen"] = "ÇáÚæÏÉ Åáì ÔÇÔÉ ÇáãÓÊÚÑÖ";
$net2ftp_messages["Template"] = "ÇáÞÇáÈ";
$net2ftp_messages["Copyright"] = "ÍÞæÞ ÇáäÔÑ";
$net2ftp_messages["Click on the image to view the details of this template"] = "ÇÖÛØ Úáì ÇáÕæÑÉ áÚÑÖ ÊÝÇÕíá ÇáÞÇáÈ .";

// Screen 2 - printTemplateDetails
$net2ftp_messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "ÓíÊã äÓÎ ãáÝÇÊ ÇáÞÇáÈ Åáì ÓÑÝÑß FTP .ÇáãáÝÇÊ ÇáÊí ÊÍãá äÝÓ ÇáÇÓã ÓíÊã ÇáßÊÇÈÉ ÝæÞåÇ . åá ÊÑÛÈ ÈÇáãÊÇÈÚÉ ¿";
$net2ftp_messages["Install template to directory: "] = "ÊÑßíÈ ÇáÞÇáÈ Ýí ÇáÏáíá » ";
$net2ftp_messages["Install"] = "ÇáÊÑßíÈ";
$net2ftp_messages["Size"] = "ÇáÍÌã";
$net2ftp_messages["Preview page"] = "ãÚÇíäÉ ÇáÕÝÍÉ";
$net2ftp_messages["opens in a new window"] = "Ýí Ýí äÇÝÐÉ ÌÏíÏÉ";

// Screen 3
$net2ftp_messages["Please wait while the template files are being transferred to your server: "] = "íÑÌì ÇáÇäÊÙÇÑ ÈíäãÇ íÊã äÓÎ ãáÝÇÊ ÇáÞÇáÈ Åáì ÓÑÝÑß » ";
$net2ftp_messages["Done."] = "ÊÜã .";
$net2ftp_messages["Continue"] = "ÇáãÊÇÈÚÉ";

// Screen 4 - printEasyAdminPanel
$net2ftp_messages["Edit page"] = "ÊÍÑíÑ ÇáÕÝÍÉ";
$net2ftp_messages["Browse the FTP server"] = "ÇÓÊÚÑÇÖ ÓÑÝÑ FTP";
$net2ftp_messages["Add this link to your favorites to return to this page later on!"] = "ÅÖÇÝÉ åÐÇ ÇáÑÇÈØ Åáì ãÝÖáÊß ááÚæÏÉ Åáì åÐå ÇáÕÝÎÉ ÝíãÇ ÈÚÏ !";
$net2ftp_messages["Edit website at %1\$s"] = "ÊÍÑíÑ ãæÞÚ ÇáæíÈ Ýí %1\$s";
$net2ftp_messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer » ÇÖÛØ ÈÇáÒÑ ÇáÃíãä ÝæÞ ÇáÑÇÈØ æ ÇÎÊÑ \"ÅÖÇÝÉ Åáì ÇáãÝÖáÉ...\"";
$net2ftp_messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox » ÇÖÛØ ÈÇáÒÑ ÇáÃíãä ÝæÞ ÇáÑÇÈØ æ ÇÎÊÑ \"ÃÖÝ åÐÇ ÇáÑÇÈØ Åáì ÇáãÝÖáÉ...\"";

// ftp_copy_local2ftp
$net2ftp_messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "ÊÍÐíÑ » ÊÚÐÑ ÅäÔÇÁ ÇáÏáíá ÇáÝÑÚí <b>%1\$s</b> . ÑÈãÇ íßæä ãæÌæÏ ãä ÞÈá . ÇáãÊÇÈÚÉ...";
$net2ftp_messages["Created target subdirectory <b>%1\$s</b>"] = "ÅäÔÇÁ ÇáÏáíá ÇáÝÑÚí ÇáåÏÝ <b>%1\$s</b>";
$net2ftp_messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "ÊÍÐíÑ » ÊÚÐÑ äÓÎ ÇáãáÝ <b>%1\$s</b> . ÇáãÊÇÈÚÉ ...";
$net2ftp_messages["Copied file <b>%1\$s</b>"] = "Êã äÓÎ ÇáãáÝ <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// Edit module
if ($net2ftp_globals["state"] == "edit") {
// -------------------------------------------------------------------------

// /modules/edit/edit.inc.php
$net2ftp_messages["Unable to open the template file"] = "ÊÚÐÑ ÝÊÍ ãáÝ ÇáÞÇáÈ";
$net2ftp_messages["Unable to read the template file"] = "ÊÚÐÑ ÞÑÇÁÉ ãáÝ ÇáÞÇáÈ";
$net2ftp_messages["Please specify a filename"] = "íÑÌì ÊÍÏíÏ ÇÓã ÇáãáÝ";
$net2ftp_messages["Status: This file has not yet been saved"] = "ÇáÍÇáÉ » áã íÊã ÍÝÙ åÐÇ ÇáãáÝ ÈÚÏ";
$net2ftp_messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "ÇáÍÇáÉ » Êã ÇáÍÝÙ Ýí <b>%1\$s</b> ÈÇÓÊÎÏÇã ÇáäãØ %2\$s";
$net2ftp_messages["Status: <b>This file could not be saved</b>"] = "ÇáÍÇáÉ » <b>ÊÚÐÑ ÍÝÙ åÐÇ ÇáãáÝ</b>";
$net2ftp_messages["Not yet saved"] = "Not yet saved";
$net2ftp_messages["Could not be saved"] = "Could not be saved";
$net2ftp_messages["Saved at %1\$s"] = "Saved at %1\$s";

// /skins/[skin]/edit.template.php
$net2ftp_messages["Directory: "] = "ÇáãÌáÏ » ";
$net2ftp_messages["File: "] = "ÇáãáÝ » ";
$net2ftp_messages["New file name: "] = "ÇÓã ÇáãáÝ ÇáÌÏíÏ » ";
$net2ftp_messages["Character encoding: "] = "ÕíÛÉ ÇáÊÑãíÒ » ";
$net2ftp_messages["Note: changing the textarea type will save the changes"] = "ãáÇÍÙÉ » ÊÛííÑ äæÚ ÕäÏæÞ ÇáäÕ ÓæÝ íÍÝÙ åÐå ÇáÊÚÏíáÇÊ";
$net2ftp_messages["Copy up"] = "äÓÎ Åáì";
$net2ftp_messages["Copy down"] = "äÓÎ ãä";

} // end if edit


// -------------------------------------------------------------------------
// Find string module
if ($net2ftp_globals["state"] == "findstring") {
// -------------------------------------------------------------------------

// /modules/findstring/findstring.inc.php 
$net2ftp_messages["Search directories and files"] = "ÈÍË Ýí ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ";
$net2ftp_messages["Search again"] = "ÈÍË ÌÏíÏ";
$net2ftp_messages["Search results"] = "äÊÇÆÌ ÇáÈÍË";
$net2ftp_messages["Please enter a valid search word or phrase."] = "íÑÌì ÅÏÎÇá ßáãÉ Ãæ ÊÚÈíÑ ãÞÈæá ááÈÍË .";
$net2ftp_messages["Please enter a valid filename."] = "íÑÌì ÅÏÎÇá ÇÓã ãáÝ ãÞÈæá .";
$net2ftp_messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "íÑÌì ÅÏÎÇá ÍÌã ãáÝ ãÞÈæá Ýí ÕäÏæÞ ÇáäÕ \"ãä\" , ãËÇá 0.";
$net2ftp_messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "íÑÌì ÅÏÎÇá ÍÌã ãáÝ ãÞÈæá Ýí ÕäÏæÞ ÇáäÕ \"Åáì\" , ãËÇá 500000.";
$net2ftp_messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "íÑÌì ÅÏÎÇá ÊÇÑíÎ ãÞÈæá Ýí ÇáÍÞá \"ãä\" ÈÊäÓíÞ Y-m-d .";
$net2ftp_messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "íÑÌì ÅÏÎÇá ÊÇÑíÎ ãÞÈæá Ýí ÇáÍÞá \"Åáì\" ÈÊäÓíÞ Y-m-d .";
$net2ftp_messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "áã íÊã ÇáÚËæÑ Úáì ÇáßáãÉ <b>%1\$s</b> Ýí ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ ÇáãÍÏÏÉ .";
$net2ftp_messages["The word <b>%1\$s</b> was found in the following files:"] = "Êã ÇáÚËæÑ Úáì ÇáßáãÉ <b>%1\$s</b> Ýí ÇáãáÝÇÊ ÇáÊÇáíÉ »";

// /skins/[skin]/findstring1.template.php
$net2ftp_messages["Search for a word or phrase"] = "ÈÍË Úä ßáãÉ Ãæ ÊÚÈíÑ";
$net2ftp_messages["Case sensitive search"] = "ÈÍË ãØÇÈÞ áÍÇáÉ ÇáÃÍÑÝ";
$net2ftp_messages["Restrict the search to:"] = "ÇÞÊÕÇÑ ÇáÈÍË Úáì »";
$net2ftp_messages["files with a filename like"] = "ÇáãáÝÇÊ ÐÇÊ ÇÓã ÇáãáÝ ããÇËá";
$net2ftp_messages["(wildcard character is *)"] = "(ãÍÑÝ ÊÚãíã ÇáÈÍË åæ *)";
$net2ftp_messages["files with a size"] = "ÇáãáÝÇÊ ÐÇÊ ÇáÍÌã";
$net2ftp_messages["files which were last modified"] = "ÇáãáÝÇÊ ÐÇÊ ÂÎÑ ÊÚÏíá ßÇä";
$net2ftp_messages["from"] = "ãä";
$net2ftp_messages["to"] = "Åáì";

$net2ftp_messages["Directory"] = "ÇáÏáíá";
$net2ftp_messages["File"] = "ãáÝ";
$net2ftp_messages["Line"] = "ÇáÓØÑ";
$net2ftp_messages["Action"] = "ÇáÅÌÑÇÁ";
$net2ftp_messages["View"] = "ÚÑÖ";
$net2ftp_messages["Edit"] = "ÊÍÑíÑ";
$net2ftp_messages["View the highlighted source code of file %1\$s"] = "ÚÑÖ ßæÏ ÇáãÕÏÑ ÇáããíÒ ááãáÝ %1\$s";
$net2ftp_messages["Edit the source code of file %1\$s"] = "ÊÍÑíÑ ßæÏ ÇáãÕÏÑ ááãáÝ %1\$s";

} // end findstring


// -------------------------------------------------------------------------
// Help module
// -------------------------------------------------------------------------
// No messages yet


// -------------------------------------------------------------------------
// Install size module
if ($net2ftp_globals["state"] == "install") {
// -------------------------------------------------------------------------

// /modules/install/install.inc.php
$net2ftp_messages["Install software packages"] = "ÊËÈíÊ ÍÒãÉ ÇáÈÑäÇãÌ";
$net2ftp_messages["Unable to open the template file"] = "ÊÚÐÑ ÝÊÍ ãáÝ ÇáÞÇáÈ";
$net2ftp_messages["Unable to read the template file"] = "ÊÚÐÑ ÞÑÇÁÉ ãáÝ ÇáÞÇáÈ";
$net2ftp_messages["Unable to get the list of packages"] = "ÊÚÐÑ ÌáÈ ÞÇÆãÉ ÇáÍÒãÉ";

// /skins/blue/install1.template.php
$net2ftp_messages["The net2ftp installer script has been copied to the FTP server."] = "Êã äÓÎ ãÚÇáÌ ÊÑíßÈ net2ftp Åáì ÓÑÝÑ FTP .";
$net2ftp_messages["This script runs on your web server and requires PHP to be installed."] = "åÐÇ ÇáãÚÇáÌ íÚãá Úáì ÓÑÝÑ ãæÞÚ æ íÍÊÇÌ Åáì PHP áíÊã ÊÑßíÈå .";
$net2ftp_messages["In order to run it, click on the link below."] = "áÊÔÛíáå ¡ ÇÖÛØ ÇáÑÇÈØ ÇáÊÇáí .";
$net2ftp_messages["net2ftp has tried to determine the directory mapping between the FTP server and the web server."] = "ÍÇæá net2ftp ÇáãÞÇÑäÉ Èíä ÓÑÝÑ FTP æ ÓÑÝÑá ãæÞÚß .";
$net2ftp_messages["Should this link not be correct, enter the URL manually in your web browser."] = "ÑÈãÇ áÇ íßæä åÐÇ ÇáÑÇÈØ ÕÍíÍ ¡ ÃÏÎá ÇáÑÇÈØ URL Ýí ãÓÊÚÑÖß íÏæíÇð .";

} // end install


// -------------------------------------------------------------------------
// Java upload module
if ($net2ftp_globals["state"] == "jupload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Upload directories and files using a Java applet"] = "ÑÝÚ ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ ÈæÇÓØÉ Java applet";
$net2ftp_messages["Your browser does not support applets, or you have disabled applets in your browser settings."] = "Your browser does not support applets, or you have disabled applets in your browser settings.";
$net2ftp_messages["To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now."] = "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.";
$net2ftp_messages["The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment)."] = "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).";
$net2ftp_messages["Alternatively, use net2ftp's normal upload or upload-and-unzip functionality."] = "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.";

} // end jupload



// -------------------------------------------------------------------------
// Login module
if ($net2ftp_globals["state"] == "login") {
// -------------------------------------------------------------------------
$net2ftp_messages["Login!"] = "ÊÓÌíá ÇáÏÎæá !";
$net2ftp_messages["Once you are logged in, you will be able to:"] = "Once you are logged in, you will be able to:";
$net2ftp_messages["Navigate the FTP server"] = "ÇÓÊÚÑÇÖ ÓÑÝÑ FTP";
$net2ftp_messages["Once you have logged in, you can browse from directory to directory and see all the subdirectories and files."] = "ÇáÊäÞá ãä ãÌáÏ Åáì ãÌáÏ æ ÇÓÊÚÑÇÖ ÌãíÚ ÇáãÌáÏÇÊ ÇáÝÑÚíÉ æ ÇáãáÝÇÊ .";
$net2ftp_messages["Upload files"] = "ÑÝÚ ÇáãáÝÇÊ";
$net2ftp_messages["There are 3 different ways to upload files: the standard upload form, the upload-and-unzip functionality, and the Java Applet."] = "íæÌÏ 3 ØÑÞ ãÎÊáÝÉ áÑÝÚ ÇáãáÝÇÊ » 1 - ÇáØÑíÞÉ ÇáÚÇÏíÉ ÇáãÚÑæÝÉ . 2 - ØÑíÞÉ ÑÝÚ ãáÝ ãÖÛæØ Ëã Ýß ÇáÖÛØ ÊáÞÇÆíÇð . 3 - ØÑíÞÉ ÇáÌÇÝÇ ÃÈáíÊ .";
$net2ftp_messages["Download files"] = "ÊÍãíá ÇáãáÝÇÊ";
$net2ftp_messages["Click on a filename to quickly download one file.<br />Select multiple files and click on Download; the selected files will be downloaded in a zip archive."] = "ÇÖÛØ Úáì ÇÓã ÇáãáÝ ááÊÍãíá ÇáÝÑÏí ÇáÓÑíÚ .<br />ÍÏÏ ãáÝÇÊ ãÊÚÏÏÉ Ëã ÇÖÛØ Úáì ÊÍãíá , íÊã ÊÍãíá ÇáãáÝÇÊ ÇáãÍÏÏÉ Öãä ãáÝ ãÖÛæØ zip .";
$net2ftp_messages["Zip files"] = "ÖÛØ Zip ÇáãáÝÇÊ";
$net2ftp_messages["... and save the zip archive on the FTP server, or email it to someone."] = "... æ ÍÝÙ ÇáãáÝ zip Úáì ÓÑÝÑ FTP , Ãæ ÅÑÓÇáå ÈæÇÓØÉ ÇáÈÑíÏ ÇáÇáßÊÑæäí .";
$net2ftp_messages["Unzip files"] = "ÇÓÊÎÑÇÌ ÇáãáÝÇÊ";
$net2ftp_messages["Different formats are supported: .zip, .tar, .tgz and .gz."] = "ÇáÕíÛ ÇáãÏÚæãÉ » .zip, .tar, .tgz æ .gz.";
$net2ftp_messages["Install software"] = "ÊÑßíÈ ÇáÈÑäÇãÌ";
$net2ftp_messages["Choose from a list of popular applications (PHP required)."] = "ÇÎÊÑ ãä ÞÇÆãÉ ÇáÊØÈíÞÇÊ ÇáÔÇÆÚÉ ( ÊÊØáÈ PHP ) .";
$net2ftp_messages["Copy, move and delete"] = "äÓÎ , äÞá , æ ÍÐÝ";
$net2ftp_messages["Directories are handled recursively, meaning that their content (subdirectories and files) will also be copied, moved or deleted."] = "ÇáãÌáÏÇÊ æ ãÍÊæíÇÊåÇ (ÇáãÌáÏÇÊ ÇáÝÑÚíÉ æ ÇáãáÝÇÊ) .";
$net2ftp_messages["Copy or move to a 2nd FTP server"] = "äÓÎ Ãæ äÞá ãä æ Åáì ÓÑÝÑ FTP";
$net2ftp_messages["Handy to import files to your FTP server, or to export files from your FTP server to another FTP server."] = "ÇÓÊíÑÇÏ ÇáãáÝÇÊ Åáì ÓÑÝÑ FTP , Ãæ ÊÕÏíÑ ÇáãáÝÇÊ ãä ÓÑÝÑß Åáì ÓÑÝÑ FTP ÂÎÑ .";
$net2ftp_messages["Rename and chmod"] = "ÅÚÇÏÉ ÇáÊÓãíÉ æ ÇáÊÕÇÑíÍ";
$net2ftp_messages["Chmod handles directories recursively."] = "ÊÛíÑ ÃÓãÇÁ ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ æ ÊÛííÑ ÇáÊÕÇÑíÍ .";
$net2ftp_messages["View code with syntax highlighting"] = "ÚÑÖ ÇáßæÏ ãÚ ÊãííÒ ÇáãÕÏÑ";
$net2ftp_messages["PHP functions are linked to the documentation on php.net."] = "ÇÑÊÈÇØÇÊ áæËÇÆÞ æÙÇÆÝ PHP Úáì php.net.";
$net2ftp_messages["Plain text editor"] = "ãÍÑÑ äÕæÕ ÚÇÏíÉ";
$net2ftp_messages["Edit text right from your browser; every time you save the changes the new file is transferred to the FTP server."] = "ÊÍÑíÑ ÇáäÕ ÈæÇÓØÉ ÇáãÓÊÚÑÖ .";
$net2ftp_messages["HTML editors"] = "ãÍÑÑ HTML";
$net2ftp_messages["Edit HTML a What-You-See-Is-What-You-Get (WYSIWYG) form; there are 2 different editors to choose from."] = "ãÍÑÑ HTML ãÊÞÏã (WYSIWYG) , ãÇ ÊÔÇåÏå ÊÍÕá Úáíå , íãßäß ÇáÇÎÊíÇÑ Èíä ãÍÑÑíä .";
$net2ftp_messages["Code editor"] = "ãÍÑÑ ÇáßæÏ";
$net2ftp_messages["Edit HTML and PHP in an editor with syntax highlighting."] = "ÊÍÑíÑ ßæÏ HTML æ PHP ãÚ ÇáÊãííÒ .";
$net2ftp_messages["Search for words or phrases"] = "ÈÍË Úä ßáãÇÊ Ãæ ÊÚÈíÑ ÈÑãÌí";
$net2ftp_messages["Filter out files based on the filename, last modification time and filesize."] = "ÝáÊÑÉ Úáì ÃÓÇÓ ÇÓã ÇáãáÝ , æÞÊ ÂÎÑ ÊÍÑíÑ æ ÍÌã ÇáãáÝ .";
$net2ftp_messages["Calculate size"] = "ÍÓÇÈ ÇáÍÌã";
$net2ftp_messages["Calculate the size of directories and files."] = "ÍÓÇÈ ÍÌã ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ .";

$net2ftp_messages["FTP server"] = "ÓÑÝÑ FTP";
$net2ftp_messages["Example"] = "ãËÇá";
$net2ftp_messages["Port"] = "ÇáãäÝÐ";
$net2ftp_messages["Protocol"] = "Protocol";
$net2ftp_messages["Username"] = "ÇÓã ÇáãÓÊÎÏã";
$net2ftp_messages["Password"] = "ßáãÉ ÇáãÑæÑ";
$net2ftp_messages["Anonymous"] = "Anonymous";
$net2ftp_messages["Passive mode"] = "äãØ Passive ÇáÎãæá";
$net2ftp_messages["Initial directory"] = "ÇáÏáíá ÇáÃæáí";
$net2ftp_messages["Language"] = "ÇááÛÉ";
$net2ftp_messages["Skin"] = "ÇáÔßá";
$net2ftp_messages["FTP mode"] = "äãØ FTP";
$net2ftp_messages["Automatic"] = "ÊáÞÇÆí";
$net2ftp_messages["Login"] = "ÊÓÌíá ÇáÏÎæá";
$net2ftp_messages["Clear cookies"] = "ãÓÍ ÇáßæßíÒ";
$net2ftp_messages["Admin"] = "ÇáÅÏÇÑÉ";
$net2ftp_messages["Please enter an FTP server."] = "íÑÌì ÅÏÎÇá ÓÑÝÑ FTP.";
$net2ftp_messages["Please enter a username."] = "íÑÌì ÅÏÎÇá ÇÓã ÇáãÓÊÎÏã .";
$net2ftp_messages["Please enter a password."] = "íÑÌì ÅÏÎÇá ßáãÉ ÇáãÑæÑ .";

} // end login


// -------------------------------------------------------------------------
// Login module
if ($net2ftp_globals["state"] == "login_small") {
// -------------------------------------------------------------------------

$net2ftp_messages["Please enter your Administrator username and password."] = "íÑÌì ÅÏÎÇá ÇÓã ÇáãÓÊÎÏã æ ßáãÉ ÇáãÑæÑ ÇáÎÇÕÉ ÈÇáÅÏÇÑÉ .";
$net2ftp_messages["Please enter your username and password for FTP server <b>%1\$s</b>."] = "íÑÌì ÅÏÎÇá ÇÓã ÇáãÓÊÎÏã æ ßáãÉ ÇáãÑæÑ áÓÑÝÑ FTP <b>%1\$s</b> .";
$net2ftp_messages["Username"] = "ÇÓã ÇáãÓÊÎÏã";
$net2ftp_messages["Your session has expired; please enter your password for FTP server <b>%1\$s</b> to continue."] = "ÇäÊåÊ ãÏÉ ÌáÓÉ ÇáÚãá ¡ íÑÌì ÅÚÇÏÉ ßÊÇÈÉ ÇÓã ÇáãÓÊÎÏã æ ßáãÉ ÇáãÑæÑ áÓÑÝÑ FTP <b>%1\$s</b> ááãÊÇÈÚÉ .";
$net2ftp_messages["Your IP address has changed; please enter your password for FTP server <b>%1\$s</b> to continue."] = "Êã ÊÛííÑ ÚäæÇä IP ÇáÎÇÕ Èß ¡ íÑÌì ÅÚÇÏÉ ßÊÇÈÉ ßáãÉ ÇáãÑæÑ áÓÑÝÑ FTP <b>%1\$s</b> ááãÊÚÇÈÚÉ .";
$net2ftp_messages["Password"] = "ßáãÉ ÇáãÑæÑ";
$net2ftp_messages["Login"] = "ÊÓÌíá ÇáÏÎæá";
$net2ftp_messages["Continue"] = "ÇáãÊÇÈÚÉ";

} // end login_small


// -------------------------------------------------------------------------
// Logout module
if ($net2ftp_globals["state"] == "logout") {
// -------------------------------------------------------------------------

// logout.inc.php
$net2ftp_messages["Login page"] = "ÕÝÍÉ ÇáÏÎæá";

// logout.template.php
$net2ftp_messages["You have logged out from the FTP server. To log back in, <a href=\"%1\$s\" title=\"Login page (accesskey l)\" accesskey=\"l\">follow this link</a>."] = "Êã ÊÓÌíá ÎÑæÌß ãä ÓÑÝÑ FTP . áÊÓÌíá ÇáÏÎæá ãä ÌÏíÏ , <a href=\"%1\$s\" title=\"ÕÝÍÉ ÇáÏÎæá (accesskey l)\" accesskey=\"l\">ÇÊÈÚ ÇáÑÇÈØ ÇáÊÇáí</a>.";
$net2ftp_messages["Note: other users of this computer could click on the browser's Back button and access the FTP server."] = "ãáÇÍÙÉ » íãßä áÃí ãÓÊÎÏã ÂÎÑ áåÐÇ ÇáÌåÇÒ Ãä íÖÛØ ÒÑ ááÎáÝ Ýí ÇáãÓÊÚÑÖ æ ÇáæÕæá Åáì ÓÑÝÑ FTP .";
$net2ftp_messages["To prevent this, you must close all browser windows."] = "áãäÚ ÍÕæá Ðáß , íÊæÌÈ Úáíß ÅÛáÇÞ ÌãíÚ ÕÝÍÇÊ ÇáãÓÊÚÑÖ ÇáÂä .";
$net2ftp_messages["Close"] = "ÅÛáÇÞ";
$net2ftp_messages["Click here to close this window"] = "ÇÖÛØ åäÇ áÅÛáÇÞ åÐå ÇáäÇÝÐÉ";

} // end logout


// -------------------------------------------------------------------------
// New directory module
if ($net2ftp_globals["state"] == "newdir") {
// -------------------------------------------------------------------------
$net2ftp_messages["Create new directories"] = "ÅäÔÇÁ ãÌáÏÇÊ ÌÏíÏÉ";
$net2ftp_messages["The new directories will be created in <b>%1\$s</b>."] = "ÇáãÌáÏÇÊ ÇáÌÏíÏÉ ÓíÊã ÅäÔÇÆåÇ Ýí <b>%1\$s</b>.";
$net2ftp_messages["New directory name:"] = "New directory name:";
$net2ftp_messages["Directory <b>%1\$s</b> was successfully created."] = "Êã ÅäÔÇÁ ÇáãÌáÏ <b>%1\$s</b> ÈäÌÇÍ !";
$net2ftp_messages["Directory <b>%1\$s</b> could not be created."] = "ÊÚÐÑ ÅäÔÇÁ ÇáãÌáÏ <b>%1\$s</b> !";

} // end newdir


// -------------------------------------------------------------------------
// Raw module
if ($net2ftp_globals["state"] == "raw") {
// -------------------------------------------------------------------------

// /modules/raw/raw.inc.php
$net2ftp_messages["Send arbitrary FTP commands"] = "ÅÑÓÇá ÃãÑ FTP ÊÍßãí";


// /skins/[skin]/raw1.template.php
$net2ftp_messages["List of commands:"] = "ÞÇÆãÉ ÇáÃæÇãÑ »";
$net2ftp_messages["FTP server response:"] = "ÅÌÇÈÉ ÓÑÝÑ FTP »";

} // end raw


// -------------------------------------------------------------------------
// Rename module
if ($net2ftp_globals["state"] == "rename") {
// -------------------------------------------------------------------------
$net2ftp_messages["Rename directories and files"] = "ÅÚÇÏÉ ÊÓãíÉ ÇáãÌáÏÇÊ æ ÇáãáÝÇÊ";
$net2ftp_messages["Old name: "] = "ÇáÇÓã ÇáÞÏíã » ";
$net2ftp_messages["New name: "] = "ÇáÇÓã ÇáÌÏíÏ » ";
$net2ftp_messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "ÇáÇÓã ÇáÌÏíÏ íÌÈ Ãä áÇ íÊÖãä äÞÇØ . áã ÊÊã ÅÚÇÏÉ ÊÓãíÉ åÐÇ ÇáÚäÕÑ Åáì <b>%1\$s</b>";
$net2ftp_messages["The new name may not contain any banned keywords. This entry was not renamed to <b>%1\$s</b>"] = "ÇáÇÓã ÇáÌÏíÏ áÇ íãßä Ãä íÊÖãä ßáãÇÊ ãÝÊÇÍíÉ ãÍÙæÑÉ .  áã ÊÊÊã ÅÚÇÏÉ ÇáÊÓãíÉ Åáì <b>%1\$s</b>";
$net2ftp_messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "Êã ÅÚÇÏÉ ÊÓãíÉ <b>%1\$s</b> Åáì <b>%2\$s</b> ÈäÌÇÍ !";
$net2ftp_messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "ÊÚÐÑ ÅÚÇÏÉ ÊÓãíÉ <b>%1\$s</b> Åáì <b>%2\$s</b> !";

} // end rename


// -------------------------------------------------------------------------
// Unzip module
if ($net2ftp_globals["state"] == "unzip") {
// -------------------------------------------------------------------------

// /modules/unzip/unzip.inc.php
$net2ftp_messages["Unzip archives"] = "ÇÓÊÎÑÇÌ Çáßá";
$net2ftp_messages["Getting archive %1\$s of %2\$s from the FTP server"] = "ÌáÈ ÃÑÔíÝ %1\$s ãä %2\$s ãä ÓÑÝÑ FTP";
$net2ftp_messages["Unable to get the archive <b>%1\$s</b> from the FTP server"] = "ÊÚÐÑ ÌáÈ ÇáÃÑÔíÝ <b>%1\$s</b> ãä ÓÑÝÑ FTP";

// /skins/[skin]/unzip1.template.php
$net2ftp_messages["Set all targetdirectories"] = "ÊÚííä ÌãíÚ ÇáÃÏáÉ ÇáåÏÝ";
$net2ftp_messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "áÊÚííä Ïáíá åÏÝ ãÔÊÑß , ÃÏÎá ÇáÏáíá ÇáåÏÝ Ýí ÇáÍÞá ÇáäÕí ÇáÓÇÈÞ Ëã ÇÖÛØ ÒÑ \"ÊÚííä ÌãíÚ ÇáÃÏáÉ ÇáåÏÝ\".";
$net2ftp_messages["Note: the target directory must already exist before anything can be copied into it."] = "ãáÇÍÙÉ » ÇáÏáíá ÇáåÏÝ íÌÈ Ãä íßæä ãæÌæÏ ÃæáÇð .";
$net2ftp_messages["Unzip archive <b>%1\$s</b> to:"] = "Ýß ÇáÃÑÔíÝ <b>%1\$s</b> Åáì »";
$net2ftp_messages["Target directory:"] = "ÇáãÌáÏ ÇáåÏÝ »";
$net2ftp_messages["Use folder names (creates subdirectories automatically)"] = "ÇÓÊÎÏÇã äÝÓ ÃÓãÇÁ ÇáãÌáÏÇÊ (ÅäÔÇÁ ÇáãÌáÏÇÊ ÇáÝÑÚíÉ ÊáÞÇÆíÇð)";

} // end unzip


// -------------------------------------------------------------------------
// Upload module
if ($net2ftp_globals["state"] == "upload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Upload to directory:"] = "ÑÝÚ Åáì ÇáÏáíá »";
$net2ftp_messages["Files"] = "ÇáãáÝÇÊ";
$net2ftp_messages["Archives"] = "ÇáÃÑÇÔíÝ";
$net2ftp_messages["Files entered here will be transferred to the FTP server."] = "ÇáãáÝÇÊ ÇáÊí ÊÖÇÝ åäÇ ÓÊÑÍá Åáì ÓÑÝÑ FTP .";
$net2ftp_messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "ÇáÃÑÇÔíÝ ÇáÊí ÊÖÇÝ åäÇ íÊã Ýß ÖÛØåÇ æ ÊÑÍíá ÇáãáÝÇÊ ÇáÊí ÈÏÇÎáåÇ Åáì ÓÑÝÑ FTP .";
$net2ftp_messages["Add another"] = "ÅÖÇÝÉ ÂÎÑ";
$net2ftp_messages["Use folder names (creates subdirectories automatically)"] = "ÇÓÊÎÏÇã äÝÓ ÃÓãÇÁ ÇáãÌáÏÇÊ (ÅäÔÇÁ ÇáãÌáÏÇÊ ÇáÝÑÚíÉ ÊáÞÇÆíÇð)";

$net2ftp_messages["Choose a directory"] = "ÇÎÊÑ Ïáíá";
$net2ftp_messages["Please wait..."] = "íÑÌì ÇáÇäÊÙÇÑ ...";
$net2ftp_messages["Uploading... please wait..."] = "ÌÇÑ ÇáÑÝÚ ... íÑÌì ÇáÇäÊÙÇÑ ...";
$net2ftp_messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "ÅÐÇ ÇÓÊÛÑÞ ÇáÑÝÚ æÞÊ ÃØæá ãä ÇáãÓãæÍ <b>%1\$s ËÇäíÉ<\/b> , ÓÊÍÇÊÌ Åáì ÅÚÇÏÉ ÇáãÍÇæáÉ ãÚ ÚÏÏ ãáÝÇÊ ÃÞá / ÃÕÛÑ .";
$net2ftp_messages["This window will close automatically in a few seconds."] = "åÐå ÇáäÇÝÐÉ ÓÊÛáÞ ÊáÞÇÆíÇð ÎáÇá ËæÇä ÞáíáÉ .";
$net2ftp_messages["Close window now"] = "ÅÛáÇÞ ÇáäÇÝÐÉ ÇáÂä";

$net2ftp_messages["Upload files and archives"] = "ÑÝÚ ÇáãáÝÇÊ æ ÇáÃÑÇÔíÝ";
$net2ftp_messages["Upload results"] = "äÊÇÆÌ ÇáÑÝÚ";
$net2ftp_messages["Checking files:"] = "ÊÝÍÕ ÇáãáÝÇÊ »";
$net2ftp_messages["Transferring files to the FTP server:"] = "ÊÑÍíá ÇáãáÝÇÊ Åáì ÇáÓÑÝÑ FTP »";
$net2ftp_messages["Decompressing archives and transferring files to the FTP server:"] = "Ýß ÇáÖÛØ æ ÊÑÍíá ÇáãáÝÇÊ Åáì ÓÑÝÑ FTP »";
$net2ftp_messages["Upload more files and archives"] = "ÑÝÚ ÇáãÒíÏ ãä ÇáãáÝÇÊ æ ÇáÃÑÇÔíÝ";

} // end upload


// -------------------------------------------------------------------------
// Messages which are shared by upload and jupload
if ($net2ftp_globals["state"] == "upload" || $net2ftp_globals["state"] == "jupload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Restrictions:"] = "ÇáÊÍÏíÏ »";
$net2ftp_messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s</b> and by PHP to <b>%2\$s</b>"] = "ÇáÍÌã ÇáÃÞÕì ááãáÝ ÇáæÇÍÏ ãÍÏÏ ÈæÇÓØÉ ÇáÈÑäÇãÌ Åáì <b>%1\$s</b> æ ÈæÇÓØÉ PHP Åáì <b>%2\$s</b>";
$net2ftp_messages["The maximum execution time is <b>%1\$s seconds</b>"] = "ãÏÉ ÇáÊäÝíÐ ÇáÞÕæì åí <b>%1\$s ËÇäíÉ</b>";
$net2ftp_messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "äãØ ÊÑÍíá FTP Åä ßÇä (ASCII Ãæ BINARY) íÊã ÊÍÏíÏå ÊáÞÇÆíÇð , ÈÇáÃÚÊãÇÏ Úáì áÇÍÞÉ ÇÓã ÇáãáÝ";
$net2ftp_messages["If the destination file already exists, it will be overwritten"] = "ÅÐÇ ßÇä ÇáãáÝ ÇáæÌåÉ ãæÌæÏ , ÓíÊã ÇÓÊÈÏÇáå";

} // end upload or jupload


// -------------------------------------------------------------------------
// View module
if ($net2ftp_globals["state"] == "view") {
// -------------------------------------------------------------------------

// /modules/view/view.inc.php
$net2ftp_messages["View file %1\$s"] = "ÚÑÖ ÇáãáÝ %1\$s";
$net2ftp_messages["View image %1\$s"] = "ÚÑÖ ÇáÕæÑÉ %1\$s";
$net2ftp_messages["View Macromedia ShockWave Flash movie %1\$s"] = "ÚÑÖ Macromedia ShockWave Ýáã ÝáÇÔ %1\$s";
$net2ftp_messages["Image"] = "ÇáÕæÑÉ";

// /skins/[skin]/view1.template.php
$net2ftp_messages["Syntax highlighting powered by <a href=\"http://luminous.asgaard.co.uk\">Luminous</a>"] = "Syntax highlighting powered by <a href=\"http://luminous.asgaard.co.uk\">Luminous</a>";
$net2ftp_messages["To save the image, right-click on it and choose 'Save picture as...'"] = "áÍÝÙ ÇáÕæÑÉ , ÇÖÛØ ÈÇáÒÑ ÇáÃíãä ÝæÞåÇ æ ÇÎÊÑ 'ÍÝÙ ÇáÕæÑÉ ÈÇÓã...'";

} // end view


// -------------------------------------------------------------------------
// Zip module
if ($net2ftp_globals["state"] == "zip") {
// -------------------------------------------------------------------------

// /modules/zip/zip.inc.php
$net2ftp_messages["Zip entries"] = "ÚäÇÕÑ Zip";

// /skins/[skin]/zip1.template.php
$net2ftp_messages["Save the zip file on the FTP server as:"] = "ÍÝÙ ãáÝ zip Úáì ÓÑÝÑ FTP ßÜ »";
$net2ftp_messages["Email the zip file in attachment to:"] = "ÅÑÓÇá ãáÝ zip ÈÇáÈÑíÏ ßãÑÝÞ Åáì »";
$net2ftp_messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "áÇÍÙ Çä ÅÑÓÇá ÇáãáÝÇÊ áÇ íÊÌÇåá » ÚäæÇäß IP ãËá ÅÖÇÝÉ æÞÊ ÇáÅÑÓÇá Åáì ÇáÑÓÇáÉ .";
$net2ftp_messages["Some additional comments to add in the email:"] = "ÅÖÇÝÉ ÈÚÖ ÇáÊÚáíÞÇÊ ÇáÅÖÇÝíÉ Åáì ÇáÑÓÇáÉ »";

$net2ftp_messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "áã ÊÏÎá ÇÓã ÇáãáÝ zip . ÇÑÌÚ ááÎáÝ æ ÃÏÎá ÇáÇÓã .";
$net2ftp_messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "ÚäæÇä ÇáÈÑíÏ ÇáÇáßÊÑæäí ÇáÐí ÃÏÎáÊå (%1\$s) ÛíÑ ãÞÈæá .<br />íÑÌì ÅÏÎÇá ÚäæÇä ÇáÈÑíÏ ÇáÇáßÊÑæäí ÈÇáÊäÓíÞ <b>username@domain.com</b>";

} // end zip

?>